package com.example.data.seed

import com.example.data.model.Artist
import com.example.data.model.Genre
import com.example.data.model.SongEntity

object CatalogSeed {
    val genres = listOf(
        Genre("pop", "Pop", "✨", "Grandes melodías y ritmos pegadizos"),
        Genre("rock", "Rock / Indie", "🎸", "Guitarras eléctricas, indie y energía pura"),
        Genre("reggaeton", "Reggaetón", "🔥", "Ritmos urbanos y dembow latino"),
        Genre("electronica", "Electrónica", "⚡", "Beats futuristas, sintetizadores y club"),
        Genre("hiphop", "Hip-Hop", "🎤", "Flows, líricas y rimas contundentes"),
        Genre("jazz", "Jazz", "🎷", "Improvisación, swing y armonías suaves"),
        Genre("clasica", "Clásica", "🎻", "Obras maestras instrumentales y orquesta"),
        Genre("rnb", "R&B / Soul", "🌙", "Soul moderno, vocales seductores y groove")
    )

    val artists = listOf(
        // Pop / R&B
        Artist("the_weeknd", "The Weeknd", "pop", "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400&q=80", "110M oyentes"),
        Artist("two_feet", "Two Feet", "rock", "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=400&q=80", "18M oyentes"),
        Artist("dua_lipa", "Dua Lipa", "pop", "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=400&q=80", "48M oyentes"),
        Artist("taylor_swift", "Taylor Swift", "pop", "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&q=80", "95M oyentes"),
        Artist("bruno_mars", "Bruno Mars", "pop", "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=400&q=80", "65M oyentes"),

        // Rock / Indie
        Artist("arctic_monkeys", "Arctic Monkeys", "rock", "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400&q=80", "42M oyentes"),
        Artist("queen", "Queen", "rock", "https://images.unsplash.com/photo-1464375117522-1311d6a5b81f?w=400&q=80", "52M oyentes"),
        Artist("imagine_dragons", "Imagine Dragons", "rock", "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=400&q=80", "58M oyentes"),
        Artist("coldplay", "Coldplay", "rock", "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=400&q=80", "80M oyentes"),

        // Reggaeton
        Artist("bad_bunny", "Bad Bunny", "reggaeton", "https://images.unsplash.com/photo-1520523839898-50712825e3a7?w=400&q=80", "85M oyentes"),
        Artist("feid", "Feid", "reggaeton", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80", "45M oyentes"),
        Artist("karol_g", "Karol G", "reggaeton", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&q=80", "60M oyentes"),
        Artist("j_balvin", "J Balvin", "reggaeton", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&q=80", "50M oyentes"),

        // Electronica
        Artist("avicii", "Avicii", "electronica", "https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=400&q=80", "38M oyentes"),
        Artist("daft_punk", "Daft Punk", "electronica", "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=400&q=80", "30M oyentes"),
        Artist("calvin_harris", "Calvin Harris", "electronica", "https://images.unsplash.com/photo-1571266028243-3716f02d2d2e?w=400&q=80", "62M oyentes"),

        // Hip-Hop
        Artist("drake", "Drake", "hiphop", "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&q=80", "88M oyentes"),
        Artist("kendrick_lamar", "Kendrick Lamar", "hiphop", "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=400&q=80", "64M oyentes"),
        Artist("travis_scott", "Travis Scott", "hiphop", "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&q=80", "59M oyentes")
    )

    val defaultSongs = listOf(
        // Two Feet & The Weeknd (Indie / Alternative / Pop Hits)
        SongEntity(
            id = "k6GsL6b7XfI",
            title = "Love Is a Bitch",
            artist = "Two Feet",
            genre = "rock",
            album = "First Steps",
            coverUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=k6GsL6b7XfI",
            durationSeconds = 176
        ),
        SongEntity(
            id = "b_KfnOSkg1U",
            title = "I Feel Like I'm Drowning",
            artist = "Two Feet",
            genre = "rock",
            album = "A Twenty Something",
            coverUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=b_KfnOSkg1U",
            durationSeconds = 185
        ),
        SongEntity(
            id = "4NRXx6U8ABQ",
            title = "Blinding Lights",
            artist = "The Weeknd",
            genre = "pop",
            album = "After Hours",
            coverUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=4NRXx6U8ABQ",
            durationSeconds = 200
        ),
        SongEntity(
            id = "34Na4j8AVgA",
            title = "Starboy",
            artist = "The Weeknd",
            genre = "pop",
            album = "Starboy",
            coverUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=34Na4j8AVgA",
            durationSeconds = 230
        ),
        SongEntity(
            id = "bpOSxM0rNPM",
            title = "Do I Wanna Know?",
            artist = "Arctic Monkeys",
            genre = "rock",
            album = "AM",
            coverUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=bpOSxM0rNPM",
            durationSeconds = 272
        ),
        SongEntity(
            id = "k2qgadSvNyU",
            title = "Levitating",
            artist = "Dua Lipa",
            genre = "pop",
            album = "Future Nostalgia",
            coverUrl = "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=k2qgadSvNyU",
            durationSeconds = 203
        ),
        SongEntity(
            id = "ic8j13piAhQ",
            title = "Cruel Summer",
            artist = "Taylor Swift",
            genre = "pop",
            album = "Lover",
            coverUrl = "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=ic8j13piAhQ",
            durationSeconds = 178
        ),
        SongEntity(
            id = "UqyT8IEBkvY",
            title = "24K Magic",
            artist = "Bruno Mars",
            genre = "pop",
            album = "24K Magic",
            coverUrl = "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=UqyT8IEBkvY",
            durationSeconds = 226
        ),

        // Rock
        SongEntity(
            id = "fJ9rUzIMcZQ",
            title = "Bohemian Rhapsody",
            artist = "Queen",
            genre = "rock",
            album = "A Night at the Opera",
            coverUrl = "https://images.unsplash.com/photo-1464375117522-1311d6a5b81f?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=fJ9rUzIMcZQ",
            durationSeconds = 359
        ),
        SongEntity(
            id = "7wtfhZwyrcc",
            title = "Believer",
            artist = "Imagine Dragons",
            genre = "rock",
            album = "Evolve",
            coverUrl = "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=7wtfhZwyrcc",
            durationSeconds = 204
        ),
        SongEntity(
            id = "dvgZkm1xWPE",
            title = "Viva La Vida",
            artist = "Coldplay",
            genre = "rock",
            album = "Viva la Vida",
            coverUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=dvgZkm1xWPE",
            durationSeconds = 242
        ),

        // Reggaeton
        SongEntity(
            id = "_knd_q1f808",
            title = "MONACO",
            artist = "Bad Bunny",
            genre = "reggaeton",
            album = "nadie sabe lo que va a pasar mañana",
            coverUrl = "https://images.unsplash.com/photo-1520523839898-50712825e3a7?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=_knd_q1f808",
            durationSeconds = 267
        ),
        SongEntity(
            id = "ca48oMV5GwE",
            title = "PROVENZA",
            artist = "Karol G",
            genre = "reggaeton",
            album = "MAÑANA SERÁ BONITO",
            coverUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=ca48oMV5GwE",
            durationSeconds = 210
        ),
        SongEntity(
            id = "rM6W3g0Jq-A",
            title = "Ferxxo 100",
            artist = "Feid",
            genre = "reggaeton",
            album = "FELIZ CUMPLEAÑOS FERXXO",
            coverUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=rM6W3g0Jq-A",
            durationSeconds = 175
        ),
        SongEntity(
            id = "wnJ6LuUFpMo",
            title = "Mi Gente",
            artist = "J Balvin",
            genre = "reggaeton",
            album = "Vibras",
            coverUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=wnJ6LuUFpMo",
            durationSeconds = 185
        ),

        // Electronica
        SongEntity(
            id = "IcrbM1l_BoI",
            title = "Wake Me Up",
            artist = "Avicii",
            genre = "electronica",
            album = "True",
            coverUrl = "https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=IcrbM1l_BoI",
            durationSeconds = 247
        ),
        SongEntity(
            id = "gAjR4_CbPpQ",
            title = "Harder, Better, Faster, Stronger",
            artist = "Daft Punk",
            genre = "electronica",
            album = "Discovery",
            coverUrl = "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=gAjR4_CbPpQ",
            durationSeconds = 224
        ),
        SongEntity(
            id = "ebXbLfLACGM",
            title = "Summer",
            artist = "Calvin Harris",
            genre = "electronica",
            album = "Motion",
            coverUrl = "https://images.unsplash.com/photo-1571266028243-3716f02d2d2e?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=ebXbLfLACGM",
            durationSeconds = 222
        ),

        // Hip-Hop
        SongEntity(
            id = "xpVfcZ0ZcFM",
            title = "God's Plan",
            artist = "Drake",
            genre = "hiphop",
            album = "Scorpion",
            coverUrl = "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=xpVfcZ0ZcFM",
            durationSeconds = 199
        ),
        SongEntity(
            id = "tvTRZJ-4EyI",
            title = "HUMBLE.",
            artist = "Kendrick Lamar",
            genre = "hiphop",
            album = "DAMN.",
            coverUrl = "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=tvTRZJ-4EyI",
            durationSeconds = 177
        ),
        SongEntity(
            id = "6ONRf7h3Mdk",
            title = "SICKO MODE",
            artist = "Travis Scott",
            genre = "hiphop",
            album = "ASTROWORLD",
            coverUrl = "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=6ONRf7h3Mdk",
            durationSeconds = 312
        ),

        // R&B / Chill
        SongEntity(
            id = "MSRcC626prw",
            title = "Kill Bill",
            artist = "SZA",
            genre = "rnb",
            album = "SOS",
            coverUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=MSRcC626prw",
            durationSeconds = 153
        ),
        SongEntity(
            id = "uzS3WG6__G4",
            title = "Pink + White",
            artist = "Frank Ocean",
            genre = "rnb",
            album = "Blonde",
            coverUrl = "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=uzS3WG6__G4",
            durationSeconds = 184
        ),

        // --- Sad / Melancholy Hits (Requested by User) ---
        SongEntity(
            id = "6Ysh1v85c14",
            title = "Mr Loverman",
            artist = "Ricky Montgomery",
            genre = "rock",
            album = "Montgomery Ricky",
            coverUrl = "https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=6Ysh1v85c14",
            durationSeconds = 217
        ),
        SongEntity(
            id = "FAucVNRx_m4",
            title = "Jocelyn Flores",
            artist = "XXXTENTACION",
            genre = "hiphop",
            album = "17",
            coverUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=FAucVNRx_m4",
            durationSeconds = 119
        ),
        SongEntity(
            id = "iAeYPfrXwk4",
            title = "Sad!",
            artist = "XXXTENTACION",
            genre = "hiphop",
            album = "?",
            coverUrl = "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=iAeYPfrXwk4",
            durationSeconds = 166
        ),
        SongEntity(
            id = "V1Pl8CzNzCw",
            title = "Lovely",
            artist = "Billie Eilish & Khalid",
            genre = "pop",
            album = "13 Reasons Why",
            coverUrl = "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=V1Pl8CzNzCw",
            durationSeconds = 200
        ),
        SongEntity(
            id = "pbMwTqkKSps",
            title = "when the party's over",
            artist = "Billie Eilish",
            genre = "pop",
            album = "WHEN WE ALL FALL ASLEEP",
            coverUrl = "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=pbMwTqkKSps",
            durationSeconds = 196
        ),
        SongEntity(
            id = "c3t_4A6Kz-Y",
            title = "Tu Falta De Querer",
            artist = "Mon Laferte",
            genre = "rock",
            album = "Mon Laferte Vol. 1",
            coverUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=c3t_4A6Kz-Y",
            durationSeconds = 278
        ),

        // --- Molesto / Rage / Intense ---
        SongEntity(
            id = "B9synWjqBn8",
            title = "FE!N",
            artist = "Travis Scott ft. Playboi Carti",
            genre = "hiphop",
            album = "UTOPIA",
            coverUrl = "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=B9synWjqBn8",
            durationSeconds = 191
        ),
        SongEntity(
            id = "eVTXPUF4Oz4",
            title = "In The End",
            artist = "Linkin Park",
            genre = "rock",
            album = "Hybrid Theory",
            coverUrl = "https://images.unsplash.com/photo-1464375117522-1311d6a5b81f?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=eVTXPUF4Oz4",
            durationSeconds = 216
        ),

        // --- Motivado / Workout / High Energy ---
        SongEntity(
            id = "7wtfhZwyrcc",
            title = "Believer",
            artist = "Imagine Dragons",
            genre = "rock",
            album = "Evolve",
            coverUrl = "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=7wtfhZwyrcc",
            durationSeconds = 204
        ),
        SongEntity(
            id = "2zToEPpFEN8",
            title = "Can't Hold Us",
            artist = "Macklemore & Ryan Lewis",
            genre = "hiphop",
            album = "The Heist",
            coverUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=2zToEPpFEN8",
            durationSeconds = 258
        ),

        // --- Pensativo / Deep / Atmospheric ---
        SongEntity(
            id = "KtlgYxa6BMU",
            title = "The Night We Met",
            artist = "Lord Huron",
            genre = "rock",
            album = "Strange Trails",
            coverUrl = "https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=KtlgYxa6BMU",
            durationSeconds = 208
        ),
        SongEntity(
            id = "sElE_BfQ67s",
            title = "Apocalypse",
            artist = "Cigarettes After Sex",
            genre = "rock",
            album = "Cigarettes After Sex",
            coverUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=sElE_BfQ67s",
            durationSeconds = 290
        ),

        // --- Relajado / Chill / Peace ---
        SongEntity(
            id = "wuCK-oiE3rA",
            title = "Sunset Lover",
            artist = "Petit Biscuit",
            genre = "electronica",
            album = "Presence",
            coverUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=500&q=80",
            audioUrl = "https://www.youtube.com/watch?v=wuCK-oiE3rA",
            durationSeconds = 237
        )
    )
}
