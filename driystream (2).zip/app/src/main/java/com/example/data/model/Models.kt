package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String, // Unique user ID
    val displayName: String,
    val email: String = "",
    val photoUrl: String = "",
    val favoriteGenres: List<String> = emptyList(),
    val favoriteArtists: List<String> = emptyList(),
    val isOnboarded: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val firstName: String = "",
    val lastName: String = "",
    val username: String = "",
    val passwordHash: String = "",
    val phoneNumber: String = ""
)

@Entity(tableName = "songs")
data class SongEntity(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String,
    val genre: String,
    val album: String,
    val coverUrl: String,
    val audioUrl: String,
    val durationSeconds: Int,
    val isFavorite: Boolean = false,
    val isDownloaded: Boolean = false,
    val localFilePath: String? = null,
    val playCount: Int = 0,
    val lastPlayedAt: Long = 0L
)

data class Genre(
    val id: String,
    val name: String,
    val emoji: String,
    val subtitle: String
)

data class Artist(
    val id: String,
    val name: String,
    val genre: String,
    val imageUrl: String,
    val followers: String
)

@Entity(tableName = "folders")
data class FolderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val isDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "folder_songs",
    primaryKeys = ["folderId", "songId"]
)
data class FolderSongCrossRef(
    val folderId: String,
    val songId: String,
    val addedAt: Long = System.currentTimeMillis()
)

data class FolderWithStats(
    val folder: FolderEntity,
    val songCount: Int,
    val coverUrl: String? = null
)

@Entity(tableName = "uploaded_songs")
data class UploadedSongEntity(
    @PrimaryKey val id: String, // UUID
    val title: String, // Título de la obra
    val composer: String, // Nombre del autor o compositor
    val authorshipPercentage: String, // Porcentajes de autoría (ej: 100%, 50% compositor / 50% productor)
    val artist: String, // Nombre del artista o banda
    val genre: String, // Género musical
    val approxDuration: String, // Duración aproximada (ej: 03:45)
    val releaseDate: String, // Año o fecha de lanzamiento (ej: 2026)
    val audioFilePath: String, // Archivo o canción en formato digital (WAV / MP3 / ZIP)
    val audioFileName: String, // Nombre del archivo original
    val audioFormatBadge: String, // WAV, MP3, ZIP
    val pdfDocPath: String? = null, // Documento en PDF con letra y/o partitura musical (registro legal de PI)
    val pdfDocName: String? = null,
    val coverUrl: String? = null,
    val isCopyrightDeclared: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

class Converters {
    private val moshi = Moshi.Builder().build()
    private val listType = Types.newParameterizedType(List::class.java, String::class.java)
    private val adapter = moshi.adapter<List<String>>(listType)

    @TypeConverter
    fun fromStringList(list: List<String>?): String {
        return adapter.toJson(list ?: emptyList())
    }

    @TypeConverter
    fun toStringList(json: String?): List<String> {
        return if (json.isNullOrEmpty()) emptyList() else adapter.fromJson(json) ?: emptyList()
    }
}
