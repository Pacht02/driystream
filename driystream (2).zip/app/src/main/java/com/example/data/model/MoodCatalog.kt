package com.example.data.model

data class MoodItem(
    val id: String,
    val name: String,
    val emoji: String,
    val description: String,
    val colorHex: Long,
    val songIds: List<String>,
    val searchTerms: String
)

object MoodCatalog {
    val moods = listOf(
        MoodItem(
            id = "feliz",
            name = "Feliz",
            emoji = "😄",
            description = "Energía positiva, fiesta y buen rollo",
            colorHex = 0xFFFFD54F, // Golden Yellow
            songIds = listOf("4NRXx6U8ABQ", "34Na4j8AVgA", "TUVcZfQe-Kw", "2zToEPpFEN8"),
            searchTerms = "happy upbeat dance latin hits"
        ),
        MoodItem(
            id = "triste",
            name = "Triste",
            emoji = "🌧️",
            description = "Melancolía, desamor y calma para el corazón",
            colorHex = 0xFF64B5F6, // Soft Blue
            songIds = listOf("6Ysh1v85c14", "FAucVNRx_m4", "iAeYPfrXwk4", "V1Pl8CzNzCw", "pbMwTqkKSps", "c3t_4A6Kz-Y"),
            searchTerms = "sad xxxtentacion billie eilish loverman tu falta de querer"
        ),
        MoodItem(
            id = "molesto",
            name = "Molesto",
            emoji = "🔥",
            description = "Intensidad pura, furia y beats pesados",
            colorHex = 0xFFE57373, // Fiery Red
            songIds = listOf("B9synWjqBn8", "eVTXPUF4Oz4", "6ONRf7h3Mdk", "tvTRZJ-4EyI"),
            searchTerms = "rage trap aggressive hip hop rock metal"
        ),
        MoodItem(
            id = "motivado",
            name = "Motivado",
            emoji = "💪",
            description = "Fuerza, enfoque y energía para arrasar",
            colorHex = 0xFFFFB74D, // Energy Orange
            songIds = listOf("7wtfhZwyrcc", "2zToEPpFEN8", "4NRXx6U8ABQ", "bpOSxM0rNPM"),
            searchTerms = "workout gym motivation energy hip hop"
        ),
        MoodItem(
            id = "pensativo",
            name = "Pensativo",
            emoji = "🌙",
            description = "Reflexión profunda, noche y melodías envolventes",
            colorHex = 0xFFBA68C8, // Deep Purple
            songIds = listOf("KtlgYxa6BMU", "sElE_BfQ67s", "b_KfnOSkg1U", "k6GsL6b7XfI", "uzS3WG6__G4"),
            searchTerms = "indie acoustic deep atmospheric late night"
        ),
        MoodItem(
            id = "relajado",
            name = "Relajado",
            emoji = "☕",
            description = "Paz mental, suave brisa y desconexión total",
            colorHex = 0xFF81C784, // Relaxing Green
            songIds = listOf("wuCK-oiE3rA", "MSRcC626prw", "uzS3WG6__G4", "k6GsL6b7XfI"),
            searchTerms = "chill lofi ambient smooth relaxed peace"
        )
    )
}
