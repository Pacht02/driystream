package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Telephony
import android.telephony.SmsManager
import android.util.Log
import androidx.core.content.ContextCompat

object DriySmsVerificationManager {
    private const val TAG = "DriySmsVerification"

    /**
     * Attempts to send a real SMS text message with the verification code
     * to the user's phone number through the device's cellular SIM card.
     */
    fun sendVerificationSms(context: Context, phoneNumber: String, code: String): SmsSendResult {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPermission) {
            Log.w(TAG, "SEND_SMS permission not granted yet")
            return SmsSendResult.PermissionRequired
        }

        return try {
            val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java) ?: SmsManager.getDefault()
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }

            val messageText = "DriyStream: Tu código de verificación es $code. Válido por 10 minutos."
            smsManager.sendTextMessage(phoneNumber, null, messageText, null, null)
            Log.d(TAG, "SMS successfully dispatched to $phoneNumber")
            SmsSendResult.SentViaCarrier
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send SMS via carrier (no SIM or carrier error): ${e.message}")
            SmsSendResult.CarrierUnavailable(e.message ?: "Sin servicio de telefonía")
        }
    }

    /**
     * Creates an SMS BroadcastReceiver that listens for incoming SMS messages,
     * checks if they originate from DriyStream, and extracts the 6-digit code.
     */
    fun createIncomingSmsReceiver(onCodeDetected: (String) -> Unit): BroadcastReceiver {
        return object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
                    try {
                        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
                        for (sms in messages) {
                            val body = sms.displayMessageBody ?: sms.messageBody ?: ""
                            if (body.contains("DriyStream", ignoreCase = true) || body.contains("código", ignoreCase = true)) {
                                val match = Regex("\\b\\d{6}\\b").find(body)
                                if (match != null) {
                                    val code = match.value
                                    Log.d(TAG, "Auto-detected incoming SMS code: $code")
                                    onCodeDetected(code)
                                    break
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing incoming SMS: ${e.message}")
                    }
                }
            }
        }
    }

    fun registerSmsReceiver(context: Context, receiver: BroadcastReceiver) {
        try {
            val filter = IntentFilter(Telephony.Sms.Intents.SMS_RECEIVED_ACTION)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                context.registerReceiver(receiver, filter)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error registering SMS receiver: ${e.message}")
        }
    }

    fun unregisterSmsReceiver(context: Context, receiver: BroadcastReceiver) {
        try {
            context.unregisterReceiver(receiver)
        } catch (e: Exception) {
            // Already unregistered
        }
    }
}

sealed class SmsSendResult {
    data object SentViaCarrier : SmsSendResult()
    data object PermissionRequired : SmsSendResult()
    data class CarrierUnavailable(val reason: String) : SmsSendResult()
}
