package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Genre
import com.example.data.model.MoodCatalog
import com.example.data.model.MoodItem
import com.example.data.model.SongEntity
import com.example.service.PlayerState
import com.example.service.YouTubeService
import com.example.ui.components.SongItemRow
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriySurfaceVariant
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary
import kotlinx.coroutines.delay

@Composable
fun SearchScreen(
    allSongs: List<SongEntity>,
    genres: List<Genre>,
    playerState: PlayerState,
    downloadProgress: Map<String, Float>,
    onPlaySong: (SongEntity, List<SongEntity>) -> Unit,
    onToggleFavorite: (SongEntity) -> Unit,
    onDownloadSong: (SongEntity) -> Unit,
    onOpenSongOptions: (SongEntity) -> Unit = {}
) {
    var query by remember { mutableStateOf("") }
    var selectedMood by remember { mutableStateOf<MoodItem?>(null) }
    var youtubeResults by remember { mutableStateOf<List<SongEntity>>(emptyList()) }

    LaunchedEffect(query) {
        if (query.isNotBlank() && selectedMood == null) {
            delay(300)
            try {
                youtubeResults = YouTubeService.searchYouTube(query)
            } catch (e: Exception) {
                // ignore
            }
        } else {
            youtubeResults = emptyList()
        }
    }

    // When a mood is selected, fetch matching songs
    val moodSongs = remember(selectedMood, allSongs) {
        if (selectedMood == null) emptyList()
        else {
            val mood = selectedMood!!
            // 1. Explicitly curated songs for this mood
            val curated = allSongs.filter { song -> mood.songIds.contains(song.id) }

            // 2. Extra matches based on mood keywords or genre
            val keywords = when (mood.id) {
                "feliz" -> listOf("blinding", "starboy", "dance", "pop")
                "triste" -> listOf("loverman", "xxxtentacion", "billie", "tu falta de querer", "jocelyn", "sad", "lovely", "party's over")
                "molesto" -> listOf("fe!n", "in the end", "linkin", "sicko", "humble", "travis")
                "motivado" -> listOf("believer", "can't hold us", "imagine dragons", "macklemore", "do i wanna")
                "pensativo" -> listOf("the night we met", "apocalypse", "pink + white", "love is a bitch", "drowning")
                "relajado" -> listOf("sunset lover", "kill bill", "pink + white", "two feet")
                else -> emptyList()
            }
            val keywordMatches = allSongs.filter { song ->
                keywords.any { kw ->
                    song.title.contains(kw, ignoreCase = true) || song.artist.contains(kw, ignoreCase = true)
                }
            }

            (curated + keywordMatches).distinctBy { it.id }
        }
    }

    val searchResults = remember(query, allSongs, youtubeResults) {
        if (query.isBlank()) emptyList()
        else {
            val local = allSongs.filter { song ->
                song.title.contains(query, ignoreCase = true) ||
                song.artist.contains(query, ignoreCase = true) ||
                song.genre.contains(query, ignoreCase = true)
            }
            (local + youtubeResults).distinctBy { it.id }
        }
    }

    Surface(
        color = DriyBackground,
        modifier = Modifier
            .fillMaxSize()
            .testTag("search_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 16.dp)
        ) {
            // Screen Header
            Text(
                text = "Explorar",
                color = DriyTextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Search Bar
            OutlinedTextField(
                value = query,
                onValueChange = {
                    query = it
                    if (it.isNotBlank()) selectedMood = null
                },
                placeholder = {
                    Text("¿Qué te apetece escuchar hoy?", color = DriyTextSecondary, fontSize = 14.sp)
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Buscar",
                        tint = DriyGold,
                        modifier = Modifier.size(22.dp)
                    )
                },
                trailingIcon = {
                    if (query.isNotEmpty() || selectedMood != null) {
                        IconButton(onClick = {
                            query = ""
                            selectedMood = null
                        }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Limpiar búsqueda o estado de ánimo",
                                tint = DriyTextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DriySurface,
                    unfocusedContainerColor = DriySurface,
                    focusedBorderColor = DriyGold,
                    unfocusedBorderColor = DriyDivider,
                    focusedTextColor = DriyTextPrimary,
                    unfocusedTextColor = DriyTextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 1. FREE SEARCH ACTIVE
            if (query.isNotBlank()) {
                Text(
                    text = "Resultados para \"$query\"",
                    color = DriyGold,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )

                LazyColumn(
                    contentPadding = PaddingValues(bottom = 90.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(searchResults) { song ->
                        SongItemRow(
                            song = song,
                            isPlaying = playerState.isPlaying,
                            isCurrentSong = playerState.currentSong?.id == song.id,
                            downloadProgress = downloadProgress[song.id],
                            onPlay = { onPlaySong(song, searchResults) },
                            onToggleFavorite = { onToggleFavorite(song) },
                            onDownload = { onDownloadSong(song) },
                            onOptionsClick = { onOpenSongOptions(song) }
                        )
                    }
                }
            }
            // 2. MOOD SELECTED: SHOW MATCHING SONGS
            else if (selectedMood != null) {
                val mood = selectedMood!!
                val moodColor = Color(mood.colorHex)

                // Mood Banner Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = DriySurface),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .border(1.dp, moodColor.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = mood.emoji, fontSize = 32.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Estado: ${mood.name}",
                                        color = moodColor,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = mood.description,
                                        color = DriyTextSecondary,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            IconButton(
                                onClick = { selectedMood = null },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Volver a estados de ánimo",
                                    tint = DriyTextSecondary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Action Buttons: Play All & Shuffle All
                        if (moodSongs.isNotEmpty()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { onPlaySong(moodSongs.first(), moodSongs) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = moodColor,
                                        contentColor = DriyBackground
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = DriyBackground,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Escuchar ahora", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }

                                OutlinedButton(
                                    onClick = {
                                        val shuffled = moodSongs.shuffled()
                                        onPlaySong(shuffled.first(), shuffled)
                                    },
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = moodColor
                                    ),
                                    border = ButtonDefaults.outlinedButtonBorder.copy(
                                        brush = androidx.compose.ui.graphics.SolidColor(moodColor)
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Shuffle,
                                        contentDescription = null,
                                        tint = moodColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Aleatorio", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Canciones para sentirte ${mood.name.lowercase()} (${moodSongs.size})",
                    color = DriyTextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
                )

                LazyColumn(
                    contentPadding = PaddingValues(bottom = 90.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(moodSongs) { song ->
                        SongItemRow(
                            song = song,
                            isPlaying = playerState.isPlaying,
                            isCurrentSong = playerState.currentSong?.id == song.id,
                            downloadProgress = downloadProgress[song.id],
                            onPlay = { onPlaySong(song, moodSongs) },
                            onToggleFavorite = { onToggleFavorite(song) },
                            onDownload = { onDownloadSong(song) },
                            onOptionsClick = { onOpenSongOptions(song) }
                        )
                    }
                }
            }
            // 3. MOOD SELECTOR: "¿Cómo te sientes ahora?"
            else {
                Column(modifier = Modifier.fillMaxSize()) {
                    Text(
                        text = "¿Cómo te sientes ahora?",
                        color = DriyTextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                    Text(
                        text = "Elige tu estado de ánimo y encuentra la música perfecta para ti:",
                        color = DriyTextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 80.dp)
                    ) {
                        items(MoodCatalog.moods) { mood ->
                            val moodColor = Color(mood.colorHex)
                            Card(
                                colors = CardDefaults.cardColors(containerColor = DriySurface),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(115.dp)
                                    .border(1.dp, moodColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                                    .clickable { selectedMood = mood }
                                    .testTag("mood_card_${mood.id}")
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(14.dp),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = mood.emoji, fontSize = 28.sp)
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(RoundedCornerShape(5.dp))
                                                .background(moodColor)
                                        )
                                    }

                                    Column {
                                        Text(
                                            text = mood.name,
                                            color = DriyTextPrimary,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = mood.description,
                                            color = DriyTextSecondary,
                                            fontSize = 11.sp,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            lineHeight = 14.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
