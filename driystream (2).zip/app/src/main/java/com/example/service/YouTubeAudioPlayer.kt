package com.example.service

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

object YouTubeAudioPlayer {
    private var webView: WebView? = null
    private val handler = Handler(Looper.getMainLooper())
    var currentVideoId: String? = null
        private set
    var isPlaying: Boolean = false
        private set

    @SuppressLint("SetJavaScriptEnabled")
    fun init(context: Context) {
        if (webView != null) return
        handler.post {
            try {
                webView = WebView(context.applicationContext).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.cacheMode = WebSettings.LOAD_DEFAULT
                    webChromeClient = WebChromeClient()
                    webViewClient = WebViewClient()
                    addJavascriptInterface(object {
                        @JavascriptInterface
                        fun onPlayerReady() {
                            isPlaying = true
                        }
                        @JavascriptInterface
                        fun onStateChange(state: Int) {
                            // YT.PlayerState.ENDED = 0
                            if (state == 0) {
                                handler.post {
                                    DriyAudioPlayer.onSongCompleted()
                                }
                            }
                        }
                    }, "AndroidPlayer")
                }
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    fun play(videoId: String) {
        currentVideoId = videoId
        isPlaying = true
        handler.post {
            try {
                val wv = webView ?: return@post
                val html = """
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <style>body { margin: 0; background: #000; overflow: hidden; }</style>
                    </head>
                    <body>
                        <div id="player"></div>
                        <script>
                            var tag = document.createElement('script');
                            tag.src = "https://www.youtube.com/iframe_api";
                            var firstScriptTag = document.getElementsByTagName('script')[0];
                            firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
                            var player;
                            function onYouTubeIframeAPIReady() {
                                player = new YT.Player('player', {
                                    height: '100%',
                                    width: '100%',
                                    videoId: '$videoId',
                                    playerVars: {
                                        'autoplay': 1,
                                        'playsinline': 1,
                                        'controls': 0,
                                        'rel': 0,
                                        'modestbranding': 1
                                    },
                                    events: {
                                        'onReady': function(e) {
                                            e.target.playVideo();
                                            if (window.AndroidPlayer) window.AndroidPlayer.onPlayerReady();
                                        },
                                        'onStateChange': function(e) {
                                            if (window.AndroidPlayer) window.AndroidPlayer.onStateChange(e.data);
                                        }
                                    }
                                });
                            }
                        </script>
                    </body>
                    </html>
                """.trimIndent()
                wv.loadDataWithBaseURL("https://www.youtube-nocookie.com", html, "text/html", "UTF-8", null)
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    fun pause() {
        isPlaying = false
        handler.post {
            try {
                webView?.evaluateJavascript("if (player && player.pauseVideo) { player.pauseVideo(); }", null)
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    fun resume() {
        isPlaying = true
        handler.post {
            try {
                webView?.evaluateJavascript("if (player && player.playVideo) { player.playVideo(); }", null)
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    fun seekTo(seconds: Float) {
        handler.post {
            try {
                webView?.evaluateJavascript("if (player && player.seekTo) { player.seekTo($seconds, true); }", null)
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    fun stop() {
        isPlaying = false
        currentVideoId = null
        handler.post {
            try {
                webView?.loadUrl("about:blank")
            } catch (e: Exception) {
                // ignore
            }
        }
    }
}
