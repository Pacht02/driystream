package com.example

import android.app.Application
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.example.service.DriyAudioPlayer

class DriyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        DriyAudioPlayer.init(this)

        // Observe whole-app foreground/background lifecycle state
        ProcessLifecycleOwner.get().lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) {
                // App came to foreground -> Hide floating dynamic island
                DriyAudioPlayer.setAppForegroundState(isForeground = true)
            }

            override fun onStop(owner: LifecycleOwner) {
                // App went to background (user pressed home or switched apps) -> Show dynamic island if music active
                DriyAudioPlayer.setAppForegroundState(isForeground = false)
            }
        })
    }
}
