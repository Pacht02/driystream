package com.example.service

import android.content.Context
import android.util.Log
import com.example.data.db.DriyDatabase
import com.example.data.model.UserEntity
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class FirebaseUserManager(private val context: Context) {
    private val firestore by lazy { FirebaseFirestore.getInstance() }
    private val userDao = DriyDatabase.getInstance(context).userDao()
    private val prefs = context.getSharedPreferences("driystream_auth_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val TAG = "FirebaseUserManager"
        private const val USERS_COLLECTION = "driystream_users"
        private const val KEY_ACTIVE_USER_ID = "active_user_id"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
    }

    /**
     * Checks if a username is already taken across all devices in Firebase Firestore or locally.
     * Normalized to lowercase so 'Tupapa', 'TUPAPA' and 'tupapa' are identical.
     */
    suspend fun isUsernameTaken(username: String): Boolean = withContext(Dispatchers.IO) {
        val clean = username.trim().removePrefix("@").lowercase()
        if (clean.length < 3) return@withContext false

        // 1. Check local Room first for instant offline/online check
        val localMatch = userDao.getUserByUsername(clean)
        if (localMatch != null) {
            Log.d(TAG, "Username '$clean' found locally")
            return@withContext true
        }

        // 2. Check Global User Sync (works across all devices worldwide)
        if (GlobalUserSyncClient.isUsernameTakenGlobal(clean)) {
            Log.d(TAG, "Username '$clean' found globally via GlobalUserSyncClient")
            return@withContext true
        }

        // 3. Check Cloud Firestore across all devices with 2.5s timeout
        try {
            val takenInCloud = withTimeoutOrNull(2500L) {
                // Primary check by document ID (fastest O(1) in Firestore)
                val doc = firestore.collection(USERS_COLLECTION).document(clean).get().await()
                if (doc.exists()) {
                    Log.d(TAG, "Username '$clean' exists in Firestore document")
                    return@withTimeoutOrNull true
                }

                // Secondary query check by username field
                val querySnap = firestore.collection(USERS_COLLECTION)
                    .whereEqualTo("username", clean)
                    .limit(1)
                    .get()
                    .await()

                !querySnap.isEmpty
            }

            if (takenInCloud == true) {
                return@withContext true
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore username check fallback: ${e.message}")
        }

        false
    }

    /**
     * Checks if an account exists with the given username OR phone number across all devices.
     */
    suspend fun findExistingAccount(username: String, phoneNumber: String): UserEntity? = withContext(Dispatchers.IO) {
        val cleanUsername = username.trim().removePrefix("@").lowercase()
        val cleanPhone = phoneNumber.filter { it.isDigit() }

        // 1. Check local Room first
        if (cleanUsername.isNotBlank()) {
            val local = userDao.getUserByUsername(cleanUsername)
            if (local != null) return@withContext local
        }
        if (cleanPhone.isNotBlank()) {
            val localByPhone = userDao.getUserByPhoneNumber(cleanPhone)
            if (localByPhone != null) return@withContext localByPhone
        }

        // 2. Check Global User Sync (multi-device cloud)
        val globalUser = GlobalUserSyncClient.getUserGlobal(cleanUsername.ifBlank { cleanPhone })
        if (globalUser != null) {
            userDao.insertUser(globalUser)
            return@withContext globalUser
        }

        // 3. Check Firestore in cloud with 3s timeout
        try {
            val cloudUser = withTimeoutOrNull(3000L) {
                // By username document ID
                if (cleanUsername.isNotBlank()) {
                    val doc = firestore.collection(USERS_COLLECTION).document(cleanUsername).get().await()
                    if (doc.exists()) {
                        val user = mapDocToUser(doc)
                        if (user != null) return@withTimeoutOrNull user
                    }
                }

                // By phone number query
                if (cleanPhone.isNotBlank()) {
                    val phoneSnap = firestore.collection(USERS_COLLECTION)
                        .whereEqualTo("phoneNumber", cleanPhone)
                        .limit(1)
                        .get()
                        .await()

                    if (!phoneSnap.isEmpty) {
                        val user = mapDocToUser(phoneSnap.documents.first())
                        if (user != null) return@withTimeoutOrNull user
                    }
                }
                null
            }

            if (cloudUser != null) {
                // Cache into local Room
                userDao.insertUser(cloudUser)
                return@withContext cloudUser
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore search error: ${e.message}")
        }

        null
    }

    /**
     * Registers a new user. Persists in Room immediately AND pushes to Firebase Firestore.
     * Guaranteed never to freeze the UI.
     */
    suspend fun registerUser(
        firstName: String,
        lastName: String,
        username: String,
        password: String,
        phoneNumber: String
    ): UserEntity = withContext(Dispatchers.IO) {
        val cleanUsername = username.trim().removePrefix("@").lowercase()
        val cleanPhone = phoneNumber.filter { it.isDigit() }.ifBlank { phoneNumber.trim() }
        val fullName = "${firstName.trim()} ${lastName.trim()}".trim().ifBlank { cleanUsername }
        val userId = cleanUsername

        val newUser = UserEntity(
            id = userId,
            displayName = fullName,
            email = "$cleanUsername@driystream.com",
            photoUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80",
            favoriteGenres = emptyList(),
            favoriteArtists = emptyList(),
            isOnboarded = false,
            createdAt = System.currentTimeMillis(),
            firstName = firstName.trim(),
            lastName = lastName.trim(),
            username = cleanUsername,
            passwordHash = password,
            phoneNumber = cleanPhone
        )

        // 1. Save to local Room immediately
        userDao.insertUser(newUser)

        // 2. Persist local active session
        prefs.edit()
            .putString(KEY_ACTIVE_USER_ID, newUser.id)
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .apply()

        // 3. Publish to Global Multi-Device Cloud Store
        GlobalUserSyncClient.saveUserGlobal(newUser)

        // 4. Push to Firebase Firestore with non-blocking timeout
        try {
            val userMap = hashMapOf(
                "id" to newUser.id,
                "username" to newUser.username,
                "firstName" to newUser.firstName,
                "lastName" to newUser.lastName,
                "displayName" to newUser.displayName,
                "email" to newUser.email,
                "photoUrl" to newUser.photoUrl,
                "phoneNumber" to newUser.phoneNumber,
                "passwordHash" to newUser.passwordHash,
                "isOnboarded" to newUser.isOnboarded,
                "createdAt" to newUser.createdAt,
                "favoriteGenres" to newUser.favoriteGenres,
                "favoriteArtists" to newUser.favoriteArtists
            )

            // Try to sync with 1.8s timeout, then queue in background so UI NEVER hangs
            val success = withTimeoutOrNull(1800L) {
                firestore.collection(USERS_COLLECTION).document(cleanUsername).set(userMap).await()
                true
            }
            if (success == null) {
                // Continue in background task
                firestore.collection(USERS_COLLECTION).document(cleanUsername).set(userMap)
            }
            Log.d(TAG, "User '$cleanUsername' registered and synced to Firestore")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to persist user in Firestore: ${e.message}", e)
        }

        newUser
    }

    /**
     * Logs in with username, password, and phone number against Firebase Firestore and Room.
     */
    suspend fun loginUser(
        username: String,
        password: String,
        phoneNumber: String
    ): Result<UserEntity> = withContext(Dispatchers.IO) {
        val cleanUsername = username.trim().removePrefix("@").lowercase()
        val cleanPhone = phoneNumber.filter { it.isDigit() }.ifBlank { phoneNumber.trim() }

        var foundUser: UserEntity? = null

        // 1. Search in Global Multi-Device Cloud Store first
        foundUser = GlobalUserSyncClient.getUserGlobal(cleanUsername.ifBlank { cleanPhone })

        // 2. Search in Firebase Firestore
        if (foundUser == null) {
            try {
                foundUser = withTimeoutOrNull(3000L) {
                    val doc = firestore.collection(USERS_COLLECTION).document(cleanUsername).get().await()
                    if (doc.exists()) {
                        return@withTimeoutOrNull mapDocToUser(doc)
                    }

                    val queryUser = firestore.collection(USERS_COLLECTION)
                        .whereEqualTo("username", cleanUsername)
                        .limit(1)
                        .get()
                        .await()

                    if (!queryUser.isEmpty) {
                        return@withTimeoutOrNull mapDocToUser(queryUser.documents.first())
                    }

                    if (cleanPhone.isNotBlank()) {
                        val queryPhone = firestore.collection(USERS_COLLECTION)
                            .whereEqualTo("phoneNumber", cleanPhone)
                            .limit(1)
                            .get()
                            .await()
                        if (!queryPhone.isEmpty) {
                            return@withTimeoutOrNull mapDocToUser(queryPhone.documents.first())
                        }
                    }
                    null
                }
            } catch (e: Exception) {
                Log.w(TAG, "Firestore login search error: ${e.message}")
            }
        }

        // 3. If not found in Firestore, search local Room database
        if (foundUser == null) {
            foundUser = userDao.getUserByUsername(cleanUsername)
                ?: (if (cleanPhone.isNotBlank()) userDao.getUserByPhoneNumber(cleanPhone) else null)
                ?: userDao.getUserByPhoneNumber(phoneNumber.trim())
        }

        if (foundUser == null) {
            return@withContext Result.failure(
                Exception("No se encontró ninguna cuenta registrada con el usuario '$cleanUsername'. Por favor verifica o crea una nueva cuenta.")
            )
        }

        // 4. Validate password
        if (foundUser.passwordHash.isNotBlank() && foundUser.passwordHash != password) {
            return@withContext Result.failure(Exception("La contraseña ingresada no es correcta."))
        }

        // 5. Validate phone number with flexible digit matching
        val userPhoneClean = foundUser.phoneNumber.filter { it.isDigit() }.ifBlank { foundUser.phoneNumber.trim() }
        if (userPhoneClean.isNotBlank() && cleanPhone.isNotBlank()) {
            val matches = userPhoneClean.endsWith(cleanPhone.takeLast(7)) ||
                          cleanPhone.endsWith(userPhoneClean.takeLast(7)) ||
                          userPhoneClean == cleanPhone
            if (!matches) {
                return@withContext Result.failure(
                    Exception("El número telefónico no coincide con el registrado en tu cuenta.")
                )
            }
        }

        // 6. Update local Room database with cloud user data
        userDao.insertUser(foundUser)

        // 7. Persist local active session
        prefs.edit()
            .putString(KEY_ACTIVE_USER_ID, foundUser.id)
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .apply()

        Result.success(foundUser)
    }

    @Suppress("UNCHECKED_CAST")
    private fun mapDocToUser(doc: DocumentSnapshot): UserEntity? {
        return try {
            val username = doc.getString("username") ?: doc.id
            val firstName = doc.getString("firstName") ?: ""
            val lastName = doc.getString("lastName") ?: ""
            val displayName = doc.getString("displayName") ?: "$firstName $lastName".trim().ifBlank { username }
            val email = doc.getString("email") ?: "$username@driystream.com"
            val photoUrl = doc.getString("photoUrl") ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80"
            val phoneNumber = doc.getString("phoneNumber") ?: ""
            val passwordHash = doc.getString("passwordHash") ?: ""
            val isOnboarded = doc.getBoolean("isOnboarded") ?: false
            val createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
            val genres = (doc.get("favoriteGenres") as? List<String>) ?: emptyList()
            val artists = (doc.get("favoriteArtists") as? List<String>) ?: emptyList()

            UserEntity(
                id = username.lowercase(),
                displayName = displayName,
                email = email,
                photoUrl = photoUrl,
                favoriteGenres = genres,
                favoriteArtists = artists,
                isOnboarded = isOnboarded,
                createdAt = createdAt,
                firstName = firstName,
                lastName = lastName,
                username = username.lowercase(),
                passwordHash = passwordHash,
                phoneNumber = phoneNumber
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error mapping Firestore document to UserEntity: ${e.message}")
            null
        }
    }
}
