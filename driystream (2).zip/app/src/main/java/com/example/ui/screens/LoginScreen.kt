package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.SimCard
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.service.DriySmsVerificationManager
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class AuthStep {
    WELCOME_CHOICE,
    REGISTER_FORM,
    REGISTER_SMS_VERIFY,
    LOGIN_FORM,
    LOGIN_SMS_VERIFY
}

@Composable
fun LoginScreen(
    isAuthenticating: Boolean = false,
    onCheckUsernameTaken: suspend (String) -> Boolean,
    onCheckPhoneTaken: suspend (String) -> Boolean,
    onValidateLoginCredentials: suspend (username: String, password: String, phone: String) -> String?,
    onRegisterUser: (
        firstName: String,
        lastName: String,
        username: String,
        password: String,
        phoneNumber: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) -> Unit,
    onLoginUser: (
        username: String,
        password: String,
        phoneNumber: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var currentStep by remember { mutableStateOf(AuthStep.WELCOME_CHOICE) }

    // Register Form Fields
    var regFirstName by remember { mutableStateOf("") }
    var regLastName by remember { mutableStateOf("") }
    var regUsername by remember { mutableStateOf("") }
    var regPassword by remember { mutableStateOf("") }
    var regPhone by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }

    // Live global username check (works across Celular A and Celular B)
    var isUsernameAvailable by remember { mutableStateOf<Boolean?>(null) }
    var isCheckingUsername by remember { mutableStateOf(false) }

    // Login Form Fields
    var loginUsername by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var loginPhone by remember { mutableStateOf("") }
    var isLoginPasswordVisible by remember { mutableStateOf(false) }

    // SMS Verification State
    var generatedSmsCode by remember { mutableStateOf("123456") }
    var enteredSmsCode by remember { mutableStateOf("") }
    var smsTargetPhone by remember { mutableStateOf("") }
    var smsResendTimer by remember { mutableIntStateOf(30) }
    var showIncomingSmsNotification by remember { mutableStateOf(false) }
    var isCodeAutoDetectedFromSim by remember { mutableStateOf(false) }

    // Feedback & UI State
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSubmittingForm by remember { mutableStateOf(false) }

    // SMS Permissions Launcher
    val smsPermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    // Live BroadcastReceiver for incoming SMS (auto-reading from physical SIM chip)
    DisposableEffect(currentStep) {
        if (currentStep == AuthStep.REGISTER_SMS_VERIFY || currentStep == AuthStep.LOGIN_SMS_VERIFY) {
            val receiver = DriySmsVerificationManager.createIncomingSmsReceiver { detectedCode ->
                enteredSmsCode = detectedCode
                isCodeAutoDetectedFromSim = true
            }
            DriySmsVerificationManager.registerSmsReceiver(context, receiver)
            onDispose {
                DriySmsVerificationManager.unregisterSmsReceiver(context, receiver)
            }
        } else {
            onDispose { }
        }
    }

    // Live Debounce check for username availability across all devices in real-time
    LaunchedEffect(regUsername) {
        val trimmed = com.example.service.GlobalUserSyncClient.cleanKey(regUsername)
        if (trimmed.length < 3) {
            isUsernameAvailable = null
            isCheckingUsername = false
            return@LaunchedEffect
        }
        isCheckingUsername = true
        delay(250)
        val taken = onCheckUsernameTaken(trimmed)
        isUsernameAvailable = !taken
        isCheckingUsername = false
    }

    // Countdown timer for SMS resend
    LaunchedEffect(currentStep, smsResendTimer) {
        if ((currentStep == AuthStep.REGISTER_SMS_VERIFY || currentStep == AuthStep.LOGIN_SMS_VERIFY) && smsResendTimer > 0) {
            delay(1000)
            smsResendTimer--
        }
    }

    fun dispatchSmsAndOpenVerifyScreen(targetPhone: String, onCodeReady: () -> Unit) {
        val newCode = (100000..999999).random().toString()
        generatedSmsCode = newCode
        smsTargetPhone = targetPhone
        enteredSmsCode = ""
        isCodeAutoDetectedFromSim = false
        smsResendTimer = 30
        showIncomingSmsNotification = true

        // Request SMS permissions if not yet granted
        val sendSmsPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
        val receiveSmsPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.RECEIVE_SMS)
        if (sendSmsPermission != PackageManager.PERMISSION_GRANTED || receiveSmsPermission != PackageManager.PERMISSION_GRANTED) {
            smsPermissionsLauncher.launch(arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS))
        }

        // Send real SMS through phone's cellular SIM card
        DriySmsVerificationManager.sendVerificationSms(context, targetPhone, newCode)

        onCodeReady()
    }

    Surface(
        color = DriyBackground,
        modifier = Modifier
            .fillMaxSize()
            .testTag("login_screen")
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 28.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Bar with back navigation
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (currentStep != AuthStep.WELCOME_CHOICE) {
                        IconButton(
                            onClick = {
                                errorMessage = null
                                currentStep = when (currentStep) {
                                    AuthStep.REGISTER_SMS_VERIFY -> AuthStep.REGISTER_FORM
                                    AuthStep.LOGIN_SMS_VERIFY -> AuthStep.LOGIN_FORM
                                    else -> AuthStep.WELCOME_CHOICE
                                }
                            },
                            modifier = Modifier.testTag("auth_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Regresar",
                                tint = DriyGold
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.size(48.dp))
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    Text(
                        text = "DriyStream",
                        color = DriyGold,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Brand Logo Capsule
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(86.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(DriyGold.copy(alpha = 0.35f), Color.Transparent)
                                )
                            )
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(DriySurface)
                                .border(1.5.dp, DriyGold, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = "Logo",
                                tint = DriyGold,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "DriyStream",
                        color = DriyTextPrimary,
                        fontSize = 25.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.5.sp
                    )

                    Text(
                        text = "Música sin interrupciones y obras exclusivas",
                        color = DriyTextSecondary,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Error message banner
                if (errorMessage != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF2E1515)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                            .border(1.dp, Color(0xFFEF5350).copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = null,
                                tint = Color(0xFFEF5350),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = errorMessage ?: "",
                                color = Color(0xFFFFCDD2),
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                // ==================== STEP 1: WELCOME CHOICE ====================
                if (currentStep == AuthStep.WELCOME_CHOICE) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Bienvenido",
                            color = DriyTextPrimary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Elige una opción para ingresar a la plataforma",
                            color = DriyTextSecondary,
                            fontSize = 13.sp
                        )

                        Spacer(modifier = Modifier.height(30.dp))

                        Button(
                            onClick = {
                                errorMessage = null
                                currentStep = AuthStep.REGISTER_FORM
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DriyGold,
                                contentColor = DriyBackground
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("btn_choose_register")
                        ) {
                            Text(
                                text = "Crear cuenta",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedButton(
                            onClick = {
                                errorMessage = null
                                currentStep = AuthStep.LOGIN_FORM
                            },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = DriyGold
                            ),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = Brush.linearGradient(listOf(DriyGold, DriyGold.copy(alpha = 0.5f)))
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("btn_choose_login")
                        ) {
                            Text(
                                text = "Iniciar sesión",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // ==================== STEP 2: REGISTER FORM ====================
                else if (currentStep == AuthStep.REGISTER_FORM) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        Text(
                            text = "Crear cuenta",
                            color = DriyTextPrimary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Completa tus datos para enviarte tu código SMS de verificación a tu chip",
                            color = DriyTextSecondary,
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Nombre & Apellido
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = regFirstName,
                                onValueChange = { regFirstName = it; errorMessage = null },
                                placeholder = { Text("Nombre", color = DriyTextSecondary, fontSize = 13.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = inputColors(),
                                modifier = Modifier.weight(1f).testTag("reg_first_name_input")
                            )

                            OutlinedTextField(
                                value = regLastName,
                                onValueChange = { regLastName = it; errorMessage = null },
                                placeholder = { Text("Apellido", color = DriyTextSecondary, fontSize = 13.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = inputColors(),
                                modifier = Modifier.weight(1f).testTag("reg_last_name_input")
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Nombre de usuario con validación en vivo entre dispositivos
                        OutlinedTextField(
                            value = regUsername,
                            onValueChange = {
                                regUsername = it.replace(" ", "")
                                errorMessage = null
                            },
                            placeholder = { Text("Nombre de usuario (ej: tupapa)", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = DriyGold, modifier = Modifier.size(20.dp))
                            },
                            trailingIcon = {
                                if (isCheckingUsername) {
                                    CircularProgressIndicator(strokeWidth = 2.dp, color = DriyGold, modifier = Modifier.size(18.dp))
                                } else if (isUsernameAvailable == true) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = "Disponible", tint = Color(0xFF66BB6A), modifier = Modifier.size(20.dp))
                                } else if (isUsernameAvailable == false) {
                                    Icon(Icons.Default.Error, contentDescription = "No disponible", tint = Color(0xFFEF5350), modifier = Modifier.size(20.dp))
                                }
                            },
                            isError = isUsernameAvailable == false,
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("reg_username_input")
                        )

                        // Advertencia de usuario en tiempo real en todos los dispositivos
                        if (isUsernameAvailable == false) {
                            Text(
                                text = "⚠️ Este nombre de usuario ya está usado. Por favor elige otro.",
                                color = Color(0xFFEF5350),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 4.dp, start = 4.dp)
                            )
                        } else if (isUsernameAvailable == true) {
                            Text(
                                text = "✓ Nombre de usuario disponible",
                                color = Color(0xFF66BB6A),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(top = 4.dp, start = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Contraseña
                        OutlinedTextField(
                            value = regPassword,
                            onValueChange = { regPassword = it; errorMessage = null },
                            placeholder = { Text("Contraseña", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            leadingIcon = {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = DriyGold, modifier = Modifier.size(20.dp))
                            },
                            trailingIcon = {
                                IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "Ver contraseña",
                                        tint = DriyTextSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("reg_password_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Número telefónico
                        OutlinedTextField(
                            value = regPhone,
                            onValueChange = { regPhone = it; errorMessage = null },
                            placeholder = { Text("Número telefónico (ej: +51 987654321)", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            leadingIcon = {
                                Icon(Icons.Default.Phone, contentDescription = null, tint = DriyGold, modifier = Modifier.size(20.dp))
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("reg_phone_input")
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // Botón de Enviar SMS
                        Button(
                            onClick = {
                                if (regFirstName.isBlank()) {
                                    errorMessage = "Por favor ingresa tu nombre."
                                    return@Button
                                }
                                if (regLastName.isBlank()) {
                                    errorMessage = "Por favor ingresa tu apellido."
                                    return@Button
                                }
                                val cleanUsername = regUsername.trim().removePrefix("@").lowercase()
                                if (cleanUsername.length < 3) {
                                    errorMessage = "El nombre de usuario debe tener al menos 3 caracteres."
                                    return@Button
                                }
                                if (regPassword.length < 4) {
                                    errorMessage = "La contraseña debe tener al menos 4 caracteres."
                                    return@Button
                                }
                                if (regPhone.trim().length < 6) {
                                    errorMessage = "Por favor ingresa un número de teléfono válido."
                                    return@Button
                                }

                                isSubmittingForm = true
                                coroutineScope.launch {
                                    val isTaken = onCheckUsernameTaken(cleanUsername)
                                    if (isTaken) {
                                        isUsernameAvailable = false
                                        errorMessage = "⚠️ Este nombre de usuario ya está usado. Por favor elige otro."
                                        isSubmittingForm = false
                                        return@launch
                                    }

                                    val isPhoneUsed = onCheckPhoneTaken(regPhone.trim())
                                    if (isPhoneUsed) {
                                        errorMessage = "⚠️ Ya existe una cuenta asociada a este número telefónico. Por favor inicia sesión."
                                        isSubmittingForm = false
                                        return@launch
                                    }

                                    isSubmittingForm = false
                                    errorMessage = null
                                    dispatchSmsAndOpenVerifyScreen(regPhone.trim()) {
                                        currentStep = AuthStep.REGISTER_SMS_VERIFY
                                    }
                                }
                            },
                            enabled = !isSubmittingForm && isUsernameAvailable != false,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DriyGold,
                                contentColor = DriyBackground
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("btn_submit_register")
                        ) {
                            if (isSubmittingForm) {
                                CircularProgressIndicator(color = DriyBackground, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Verificando disponibilidad...", fontWeight = FontWeight.Bold)
                            } else {
                                Text("Continuar y Enviar SMS a mi Chip", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("¿Ya tienes una cuenta?", color = DriyTextSecondary, fontSize = 13.sp)
                            TextButton(
                                onClick = {
                                    errorMessage = null
                                    currentStep = AuthStep.LOGIN_FORM
                                }
                            ) {
                                Text("Inicia sesión", color = DriyGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // ==================== STEP 3: LOGIN FORM ====================
                else if (currentStep == AuthStep.LOGIN_FORM) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        Text(
                            text = "Iniciar sesión",
                            color = DriyTextPrimary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Ingresa tu usuario, contraseña y teléfono para validar tu chip con SMS",
                            color = DriyTextSecondary,
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        // Usuario
                        OutlinedTextField(
                            value = loginUsername,
                            onValueChange = { loginUsername = it; errorMessage = null },
                            placeholder = { Text("Nombre de usuario", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = DriyGold, modifier = Modifier.size(20.dp))
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("login_username_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Contraseña
                        OutlinedTextField(
                            value = loginPassword,
                            onValueChange = { loginPassword = it; errorMessage = null },
                            placeholder = { Text("Contraseña", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            visualTransformation = if (isLoginPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            leadingIcon = {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = DriyGold, modifier = Modifier.size(20.dp))
                            },
                            trailingIcon = {
                                IconButton(onClick = { isLoginPasswordVisible = !isLoginPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isLoginPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "Ver contraseña",
                                        tint = DriyTextSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("login_password_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Teléfono
                        OutlinedTextField(
                            value = loginPhone,
                            onValueChange = { loginPhone = it; errorMessage = null },
                            placeholder = { Text("Teléfono registrado", color = DriyTextSecondary, fontSize = 13.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            leadingIcon = {
                                Icon(Icons.Default.Phone, contentDescription = null, tint = DriyGold, modifier = Modifier.size(20.dp))
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = inputColors(),
                            modifier = Modifier.fillMaxWidth().testTag("login_phone_input")
                        )

                        Spacer(modifier = Modifier.height(22.dp))

                        Button(
                            onClick = {
                                if (loginUsername.isBlank()) {
                                    errorMessage = "Por favor ingresa tu nombre de usuario."
                                    return@Button
                                }
                                if (loginPassword.isBlank()) {
                                    errorMessage = "Por favor ingresa tu contraseña."
                                    return@Button
                                }
                                if (loginPhone.isBlank()) {
                                    errorMessage = "Por favor ingresa tu número telefónico."
                                    return@Button
                                }

                                isSubmittingForm = true
                                coroutineScope.launch {
                                    val validationError = onValidateLoginCredentials(
                                        loginUsername.trim(),
                                        loginPassword.trim(),
                                        loginPhone.trim()
                                    )
                                    isSubmittingForm = false

                                    if (validationError != null) {
                                        errorMessage = validationError
                                    } else {
                                        errorMessage = null
                                        dispatchSmsAndOpenVerifyScreen(loginPhone.trim()) {
                                            currentStep = AuthStep.LOGIN_SMS_VERIFY
                                        }
                                    }
                                }
                            },
                            enabled = !isSubmittingForm,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DriyGold,
                                contentColor = DriyBackground
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("btn_submit_login")
                        ) {
                            if (isSubmittingForm) {
                                CircularProgressIndicator(color = DriyBackground, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Verificando cuenta...", fontWeight = FontWeight.Bold)
                            } else {
                                Text("Verificar y Enviar SMS", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("¿No tienes cuenta?", color = DriyTextSecondary, fontSize = 13.sp)
                            TextButton(
                                onClick = {
                                    errorMessage = null
                                    currentStep = AuthStep.REGISTER_FORM
                                }
                            ) {
                                Text("Crear cuenta", color = DriyGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // ==================== STEP 4: SMS AUTO-RECOGNITION ====================
                else if (currentStep == AuthStep.REGISTER_SMS_VERIFY || currentStep == AuthStep.LOGIN_SMS_VERIFY) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .clip(CircleShape)
                                .background(DriyGold.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SimCard,
                                contentDescription = null,
                                tint = DriyGold,
                                modifier = Modifier.size(30.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Validación de Chip SIM",
                            color = DriyTextPrimary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Enviando SMS al número:\n$smsTargetPhone",
                            color = DriyTextSecondary,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Status Card: Listening to physical SIM card SMS
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isCodeAutoDetectedFromSim) Color(0xFF1B3820) else DriySurface
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    1.dp,
                                    if (isCodeAutoDetectedFromSim) Color(0xFF66BB6A) else DriyGold.copy(alpha = 0.4f),
                                    RoundedCornerShape(12.dp)
                                )
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isCodeAutoDetectedFromSim) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF66BB6A), modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text("¡Chip SIM reconocido con éxito!", color = Color(0xFF66BB6A), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text("El código SMS se leyó y completó automáticamente.", color = Color(0xFFC8E6C9), fontSize = 11.sp)
                                    }
                                } else {
                                    CircularProgressIndicator(strokeWidth = 2.dp, color = DriyGold, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text("Esperando SMS en tu chip...", color = DriyGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text("Al recibir el mensaje, la app lo reconocerá al instante.", color = DriyTextSecondary, fontSize = 11.sp)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // 6-digit Code Input
                        OutlinedTextField(
                            value = enteredSmsCode,
                            onValueChange = {
                                if (it.length <= 6) {
                                    enteredSmsCode = it.filter { char -> char.isDigit() }
                                    errorMessage = null
                                }
                            },
                            placeholder = { Text("000000", color = DriyTextSecondary, fontSize = 24.sp, letterSpacing = 8.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            textStyle = androidx.compose.ui.text.TextStyle(
                                color = DriyGold,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                letterSpacing = 8.sp
                            ),
                            shape = RoundedCornerShape(14.dp),
                            colors = inputColors(),
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .testTag("sms_code_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Resend timer or action
                        if (smsResendTimer > 0) {
                            Text(
                                text = "Reenviar SMS en ${smsResendTimer}s",
                                color = DriyTextSecondary,
                                fontSize = 12.sp
                            )
                        } else {
                            TextButton(
                                onClick = {
                                    dispatchSmsAndOpenVerifyScreen(smsTargetPhone) {}
                                }
                            ) {
                                Text("Reenviar mensaje SMS", color = DriyGold, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Verify & Confirm Button
                        Button(
                            onClick = {
                                if (enteredSmsCode.length != 6) {
                                    errorMessage = "Por favor ingresa el código completo de 6 dígitos recibido por SMS."
                                    return@Button
                                }
                                if (enteredSmsCode != generatedSmsCode) {
                                    errorMessage = "El código SMS es incorrecto. Verifica el mensaje recibido."
                                    return@Button
                                }

                                errorMessage = null

                                if (currentStep == AuthStep.REGISTER_SMS_VERIFY) {
                                    onRegisterUser(
                                        regFirstName,
                                        regLastName,
                                        regUsername,
                                        regPassword,
                                        regPhone,
                                        { /* Handled in ViewModel */ },
                                        { err -> errorMessage = err }
                                    )
                                } else {
                                    onLoginUser(
                                        loginUsername,
                                        loginPassword,
                                        loginPhone,
                                        { /* Handled in ViewModel */ },
                                        { err -> errorMessage = err }
                                    )
                                }
                            },
                            enabled = !isAuthenticating,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DriyGold,
                                contentColor = DriyBackground
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("btn_confirm_sms")
                        ) {
                            if (isAuthenticating) {
                                CircularProgressIndicator(color = DriyBackground, strokeWidth = 2.dp, modifier = Modifier.size(22.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Verificando identidad...", fontWeight = FontWeight.Bold)
                            } else {
                                Text(
                                    text = if (currentStep == AuthStep.REGISTER_SMS_VERIFY) "Verificar y Crear Cuenta" else "Verificar e Iniciar Sesión",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Footer
                Text(
                    text = "DriyStream • Todos los derechos reservados 2026",
                    color = DriyTextSecondary.copy(alpha = 0.5f),
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 16.dp)
                )
            }

            // SIMULATED INCOMING CARRIER BANNER (For emulator testing without a physical SIM card)
            AnimatedVisibility(
                visible = showIncomingSmsNotification && (currentStep == AuthStep.REGISTER_SMS_VERIFY || currentStep == AuthStep.LOGIN_SMS_VERIFY),
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp, start = 16.dp, end = 16.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DriySurface),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DriyGold, RoundedCornerShape(14.dp))
                        .testTag("simulated_sms_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(DriyGold),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Sms, contentDescription = null, tint = DriyBackground, modifier = Modifier.size(20.dp))
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text("SMS Carrier • DriyStream", color = DriyGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Código enviado a tu chip: $generatedSmsCode", color = DriyTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        Button(
                            onClick = {
                                enteredSmsCode = generatedSmsCode
                                isCodeAutoDetectedFromSim = true
                                showIncomingSmsNotification = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DriyGold, contentColor = DriyBackground),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("Auto-leer", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun inputColors() = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = DriySurface,
    unfocusedContainerColor = DriySurface,
    focusedBorderColor = DriyGold,
    unfocusedBorderColor = DriyDivider,
    focusedTextColor = DriyTextPrimary,
    unfocusedTextColor = DriyTextPrimary,
    cursorColor = DriyGold
)
