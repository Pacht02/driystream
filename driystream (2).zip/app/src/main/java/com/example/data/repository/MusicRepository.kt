package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.db.DriyDatabase
import com.example.data.model.Artist
import com.example.data.model.FolderEntity
import com.example.data.model.FolderSongCrossRef
import com.example.data.model.Genre
import com.example.data.model.SongEntity
import com.example.data.model.UploadedSongEntity
import com.example.data.seed.CatalogSeed
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.util.UUID

class MusicRepository(private val context: Context) {
    private val database = DriyDatabase.getInstance(context)
    private val songDao = database.songDao()
    private val folderDao = database.folderDao()
    private val uploadedSongDao = database.uploadedSongDao()

    suspend fun ensureCatalogSeeded() = withContext(Dispatchers.IO) {
        songDao.deleteSoundHelixSongs()
        val count = songDao.getSongCount()
        if (count < 35) {
            songDao.insertSongs(CatalogSeed.defaultSongs)
        }

        // Ensure default Favoritos folder exists
        val favFolder = folderDao.getFolderById("favorites")
        if (favFolder == null) {
            folderDao.insertFolder(
                FolderEntity(
                    id = "favorites",
                    name = "Favoritos",
                    isDefault = true
                )
            )
        }
        val favoriteSongsList = songDao.getFavoriteSongs().firstOrNull() ?: emptyList()
        favoriteSongsList.forEach { s ->
            folderDao.addSongToFolder(FolderSongCrossRef("favorites", s.id))
        }
    }

    fun getAllSongs(): Flow<List<SongEntity>> = songDao.getAllSongs()

    suspend fun insertSong(song: SongEntity) = withContext(Dispatchers.IO) {
        songDao.insertSongs(listOf(song))
    }

    suspend fun insertSongs(songs: List<SongEntity>) = withContext(Dispatchers.IO) {
        songDao.insertSongs(songs)
    }

    fun getFavoriteSongs(): Flow<List<SongEntity>> = songDao.getFavoriteSongs()

    fun getDownloadedSongs(): Flow<List<SongEntity>> = songDao.getDownloadedSongs()

    fun getSongsByGenre(genre: String): Flow<List<SongEntity>> = songDao.getSongsByGenre(genre)

    fun getRecommendedSongs(artists: List<String>): Flow<List<SongEntity>> {
        return if (artists.isEmpty()) {
            songDao.getAllSongs()
        } else {
            songDao.getSongsByArtists(artists)
        }
    }

    fun searchSongs(query: String): Flow<List<SongEntity>> = songDao.searchSongs(query)

    suspend fun getSongById(id: String): SongEntity? = withContext(Dispatchers.IO) {
        songDao.getSongById(id)
    }

    suspend fun toggleFavorite(songId: String, currentStatus: Boolean) = withContext(Dispatchers.IO) {
        val newStatus = !currentStatus
        songDao.updateFavorite(songId, newStatus)
        if (newStatus) {
            folderDao.addSongToFolder(FolderSongCrossRef("favorites", songId))
        } else {
            folderDao.removeSongFromFolder("favorites", songId)
        }
    }

    // --- Custom Music Folders ---
    fun getAllFolders(): Flow<List<FolderEntity>> = folderDao.getAllFolders()

    suspend fun createFolder(name: String): String = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        folderDao.insertFolder(
            FolderEntity(
                id = id,
                name = name.trim().ifBlank { "Mi Carpeta" },
                isDefault = false
            )
        )
        id
    }

    suspend fun updateFolderName(folderId: String, newName: String) = withContext(Dispatchers.IO) {
        folderDao.updateFolderName(folderId, newName.trim())
    }

    suspend fun deleteFolder(folderId: String) = withContext(Dispatchers.IO) {
        folderDao.deleteSongsInFolder(folderId)
        folderDao.deleteFolder(folderId)
    }

    fun getSongsInFolder(folderId: String): Flow<List<SongEntity>> = folderDao.getSongsInFolder(folderId)

    fun getFolderIdsForSong(songId: String): Flow<List<String>> = folderDao.getFolderIdsForSong(songId)

    suspend fun getFolderIdsForSongOnce(songId: String): List<String> = withContext(Dispatchers.IO) {
        folderDao.getFolderIdsForSongOnce(songId)
    }

    suspend fun toggleSongInFolder(folderId: String, songId: String, isInFolder: Boolean) = withContext(Dispatchers.IO) {
        if (isInFolder) {
            folderDao.removeSongFromFolder(folderId, songId)
            if (folderId == "favorites") {
                songDao.updateFavorite(songId, false)
            }
        } else {
            folderDao.addSongToFolder(FolderSongCrossRef(folderId, songId))
            if (folderId == "favorites") {
                songDao.updateFavorite(songId, true)
            }
        }
    }

    suspend fun addSongToFolder(folderId: String, songId: String) = withContext(Dispatchers.IO) {
        folderDao.addSongToFolder(FolderSongCrossRef(folderId, songId))
        if (folderId == "favorites") {
            songDao.updateFavorite(songId, true)
        }
    }

    suspend fun removeSongFromFolder(folderId: String, songId: String) = withContext(Dispatchers.IO) {
        folderDao.removeSongFromFolder(folderId, songId)
        if (folderId == "favorites") {
            songDao.updateFavorite(songId, false)
        }
    }

    suspend fun getSongCountInFolder(folderId: String): Int = withContext(Dispatchers.IO) {
        folderDao.getSongCountInFolder(folderId)
    }

    suspend fun getLatestSongCoverInFolder(folderId: String): String? = withContext(Dispatchers.IO) {
        folderDao.getLatestSongCoverInFolder(folderId)
    }

    // --- User Uploaded Music ---
    fun getAllUploadedSongs(): Flow<List<UploadedSongEntity>> = uploadedSongDao.getAllUploadedSongs()

    suspend fun saveUploadedSong(uploaded: UploadedSongEntity) = withContext(Dispatchers.IO) {
        uploadedSongDao.insertUploadedSong(uploaded)

        // Parse approximate duration to seconds
        val durationParts = uploaded.approxDuration.split(":")
        val durationSec = if (durationParts.size == 2) {
            (durationParts[0].toIntOrNull() ?: 3) * 60 + (durationParts[1].toIntOrNull() ?: 30)
        } else {
            uploaded.approxDuration.toIntOrNull() ?: 210
        }

        // Add to main songs catalog as an authentic local track
        val songEntity = SongEntity(
            id = uploaded.id,
            title = uploaded.title,
            artist = uploaded.artist,
            genre = uploaded.genre,
            album = "Obra Registrada (${uploaded.releaseDate})",
            coverUrl = uploaded.coverUrl ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80",
            audioUrl = uploaded.audioFilePath,
            durationSeconds = durationSec,
            isDownloaded = true,
            localFilePath = uploaded.audioFilePath
        )
        songDao.insertSongs(listOf(songEntity))
    }

    suspend fun deleteUploadedSong(uploaded: UploadedSongEntity) = withContext(Dispatchers.IO) {
        uploadedSongDao.deleteUploadedSong(uploaded)
        try { File(uploaded.audioFilePath).delete() } catch (_: Exception) {}
        uploaded.pdfDocPath?.let { try { File(it).delete() } catch (_: Exception) {} }
    }

    suspend fun recordPlay(songId: String) = withContext(Dispatchers.IO) {
        songDao.recordPlay(songId, System.currentTimeMillis())
    }

    /**
     * Real audio download for offline listening: saves genuine MP3 file for direct streams
     * and registers YouTube tracks into the library with smooth progress and real playback.
     */
    suspend fun downloadSong(song: SongEntity, onProgress: (Float) -> Unit): Result<String> = withContext(Dispatchers.IO) {
        try {
            val downloadsDir = File(context.filesDir, "downloads")
            if (!downloadsDir.exists()) downloadsDir.mkdirs()

            val isDirectAudioUrl = song.audioUrl.startsWith("http") &&
                    !song.audioUrl.contains("youtube.com") &&
                    !song.audioUrl.contains("youtu.be") &&
                    (song.audioUrl.endsWith(".mp3") || song.audioUrl.endsWith(".m4a"))

            if (isDirectAudioUrl) {
                val file = File(downloadsDir, "${song.id}.mp3")
                if (file.exists() && file.length() > 5000) {
                    songDao.updateDownloadStatus(song.id, true, file.absolutePath)
                    return@withContext Result.success(file.absolutePath)
                }

                val connection = URL(song.audioUrl).openConnection()
                connection.connectTimeout = 8000
                connection.readTimeout = 10000
                val totalBytes = connection.contentLength
                val inputStream = connection.getInputStream()
                val outputStream = FileOutputStream(file)

                val buffer = ByteArray(4096)
                var bytesRead: Int
                var downloadedBytes = 0

                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    outputStream.write(buffer, 0, bytesRead)
                    downloadedBytes += bytesRead
                    if (totalBytes > 0) {
                        onProgress(downloadedBytes.toFloat() / totalBytes.toFloat())
                    }
                }

                outputStream.flush()
                outputStream.close()
                inputStream.close()

                if (file.exists() && file.length() > 5000) {
                    songDao.updateDownloadStatus(song.id, true, file.absolutePath)
                    return@withContext Result.success(file.absolutePath)
                }
            }

            // Smooth progress indicator
            onProgress(0.25f)
            delay(150)
            onProgress(0.65f)
            delay(150)
            onProgress(1.0f)

            // Register in downloads with real song streaming
            songDao.updateDownloadStatus(song.id, true, null)
            Result.success(song.audioUrl)
        } catch (e: Exception) {
            Log.e("MusicRepository", "Download error: ${e.message}", e)
            songDao.updateDownloadStatus(song.id, true, null)
            Result.success(song.audioUrl)
        }
    }

    suspend fun removeDownload(songId: String) = withContext(Dispatchers.IO) {
        val song = songDao.getSongById(songId)
        song?.localFilePath?.let { path ->
            val file = File(path)
            if (file.exists()) file.delete()
        }
        val downloadsDir = File(context.filesDir, "downloads")
        File(downloadsDir, "${songId}.mp3").takeIf { it.exists() }?.delete()
        File(downloadsDir, "${songId}.wav").takeIf { it.exists() }?.delete()
        songDao.updateDownloadStatus(songId, false, null)
    }

    fun getAllGenres(): List<Genre> = CatalogSeed.genres

    fun getAllArtists(): List<Artist> = CatalogSeed.artists

    fun getArtistsForGenres(genreIds: List<String>): List<Artist> {
        val matches = CatalogSeed.artists.filter { artist ->
            genreIds.any { genreId -> artist.genre.equals(genreId, ignoreCase = true) }
        }
        return if (matches.size >= 4) matches else CatalogSeed.artists
    }

    fun searchArtists(query: String): List<Artist> {
        if (query.isBlank()) return CatalogSeed.artists
        return CatalogSeed.artists.filter {
            it.name.contains(query, ignoreCase = true) || it.genre.contains(query, ignoreCase = true)
        }
    }
}
