package com.example.service

import android.net.Uri
import android.util.Log
import com.example.data.model.SongEntity
import com.example.data.model.UploadedSongEntity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File

object FirebaseMusicSyncManager {
    private const val TAG = "FirebaseMusicSync"
    private const val COLLECTION_COMMUNITY_SONGS = "community_songs"

    private val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    private val storage: FirebaseStorage by lazy { FirebaseStorage.getInstance() }

    /**
     * Uploads the user's music file, legal PDF, and artwork to Firebase Cloud Storage,
     * then publishes the song metadata to Cloud Firestore so all users in the world
     * immediately see it in their Home feed.
     */
    suspend fun publishSongToGlobalCloud(
        uploadedSong: UploadedSongEntity,
        audioFile: File,
        pdfFile: File?,
        coverFile: File?,
        uploaderEmail: String?,
        uploaderName: String?,
        onProgress: (Float) -> Unit = {}
    ): Result<UploadedSongEntity> = withContext(Dispatchers.IO) {
        try {
            onProgress(0.1f)

            // 1. Upload Audio File to Firebase Storage
            val audioExtension = audioFile.extension.ifBlank { "mp3" }
            val audioStorageRef = storage.reference.child("community_music/${uploadedSong.id}.$audioExtension")
            
            val audioUploadTask = audioStorageRef.putFile(Uri.fromFile(audioFile))
            audioUploadTask.addOnProgressListener { taskSnapshot ->
                val progress = (taskSnapshot.bytesTransferred.toFloat() / taskSnapshot.totalByteCount.toFloat()) * 0.6f
                onProgress(0.1f + progress)
            }.await()

            val cloudAudioUrl = audioStorageRef.downloadUrl.await().toString()
            onProgress(0.7f)

            // 2. Upload Legal PDF (if present)
            var cloudPdfUrl: String? = null
            if (pdfFile != null && pdfFile.exists()) {
                val pdfStorageRef = storage.reference.child("community_legal_docs/${uploadedSong.id}_legal.pdf")
                pdfStorageRef.putFile(Uri.fromFile(pdfFile)).await()
                cloudPdfUrl = pdfStorageRef.downloadUrl.await().toString()
            }
            onProgress(0.85f)

            // 3. Upload Artwork Cover (if present)
            var cloudCoverUrl: String? = uploadedSong.coverUrl
            if (coverFile != null && coverFile.exists()) {
                val coverStorageRef = storage.reference.child("community_covers/${uploadedSong.id}_cover.jpg")
                coverStorageRef.putFile(Uri.fromFile(coverFile)).await()
                cloudCoverUrl = coverStorageRef.downloadUrl.await().toString()
            }
            onProgress(0.95f)

            // 4. Save metadata document in Firestore for global distribution
            val songDocument = hashMapOf(
                "id" to uploadedSong.id,
                "title" to uploadedSong.title,
                "composer" to uploadedSong.composer,
                "authorshipPercentage" to uploadedSong.authorshipPercentage,
                "artist" to uploadedSong.artist,
                "genre" to uploadedSong.genre,
                "approxDuration" to uploadedSong.approxDuration,
                "releaseDate" to uploadedSong.releaseDate,
                "audioUrl" to cloudAudioUrl,
                "audioFileName" to uploadedSong.audioFileName,
                "audioFormatBadge" to uploadedSong.audioFormatBadge,
                "coverUrl" to (cloudCoverUrl ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80"),
                "hasPdf" to (cloudPdfUrl != null),
                "pdfDocUrl" to cloudPdfUrl,
                "pdfDocName" to uploadedSong.pdfDocName,
                "uploaderEmail" to (uploaderEmail ?: "indie_artist@driystream.com"),
                "uploaderName" to (uploaderName ?: uploadedSong.artist),
                "isCopyrightDeclared" to true,
                "createdAt" to System.currentTimeMillis()
            )

            firestore.collection(COLLECTION_COMMUNITY_SONGS)
                .document(uploadedSong.id)
                .set(songDocument)
                .await()

            onProgress(1.0f)
            Log.d(TAG, "Song successfully published to global cloud: ${uploadedSong.title}")

            val updatedSong = uploadedSong.copy(
                audioFilePath = cloudAudioUrl,
                coverUrl = cloudCoverUrl,
                pdfDocPath = cloudPdfUrl
            )
            Result.success(updatedSong)
        } catch (e: Exception) {
            Log.e(TAG, "Error publishing song to cloud: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Real-time listener: Returns a Flow that updates whenever ANY user in the world
     * uploads a new song to Firebase.
     */
    fun getGlobalCommunitySongsFlow(): Flow<List<SongEntity>> = callbackFlow {
        val listenerRegistration = firestore.collection(COLLECTION_COMMUNITY_SONGS)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(50)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Firestore community songs listen failed: ${error.message}")
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    val songs = snapshot.documents.mapNotNull { doc ->
                        try {
                            val id = doc.getString("id") ?: doc.id
                            val title = doc.getString("title") ?: "Sin título"
                            val artist = doc.getString("artist") ?: "Artista Emergente"
                            val genre = doc.getString("genre") ?: "Original"
                            val approxDuration = doc.getString("approxDuration") ?: "03:30"
                            val releaseDate = doc.getString("releaseDate") ?: "2026"
                            val audioUrl = doc.getString("audioUrl") ?: return@mapNotNull null
                            val coverUrl = doc.getString("coverUrl")
                                ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80"

                            val durationParts = approxDuration.split(":")
                            val durationSec = if (durationParts.size == 2) {
                                (durationParts[0].toIntOrNull() ?: 3) * 60 + (durationParts[1].toIntOrNull() ?: 30)
                            } else {
                                approxDuration.toIntOrNull() ?: 210
                            }

                            SongEntity(
                                id = id,
                                title = title,
                                artist = artist,
                                genre = genre,
                                album = "Comunidad DriyStream ($releaseDate)",
                                coverUrl = coverUrl,
                                audioUrl = audioUrl,
                                durationSeconds = durationSec,
                                isDownloaded = false,
                                localFilePath = null
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    trySend(songs)
                }
            }

        awaitClose {
            listenerRegistration.remove()
        }
    }.flowOn(Dispatchers.IO)
}
