package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Artist
import com.example.data.model.FolderEntity
import com.example.data.model.FolderWithStats
import com.example.data.model.Genre
import com.example.data.model.SongEntity
import com.example.data.model.UploadedSongEntity
import com.example.data.model.UserEntity
import com.example.data.repository.MusicRepository
import com.example.data.repository.UserRepository
import com.example.service.DriyAudioPlayer
import com.example.service.DynamicIslandDetector
import com.example.service.FirebaseMusicSyncManager
import com.example.service.PlayerState
import com.example.service.YouTubeService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class Screen {
    data object Login : Screen()
    data object OnboardingGenre : Screen()
    data object OnboardingArtist : Screen()
    data object Home : Screen()
    data object Search : Screen()
    data object Library : Screen()
    data object UploadMusic : Screen()
    data object Profile : Screen()
}

class DriyViewModel(application: Application) : AndroidViewModel(application) {
    private val musicRepo = MusicRepository(application)
    private val userRepo = UserRepository(application)
    private val authManager = com.example.service.FirebaseAuthManager(application, userRepo)

    // Current navigation screen
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Login)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Authentication in progress indicator
    private val _isAuthenticating = MutableStateFlow(false)
    val isAuthenticating: StateFlow<Boolean> = _isAuthenticating.asStateFlow()

    // Full screen player modal visibility
    private val _isFullPlayerVisible = MutableStateFlow(false)
    val isFullPlayerVisible: StateFlow<Boolean> = _isFullPlayerVisible.asStateFlow()

    // Queue modal visibility
    private val _isQueueVisible = MutableStateFlow(false)
    val isQueueVisible: StateFlow<Boolean> = _isQueueVisible.asStateFlow()

    // Active song selected for the action options sheet
    private val _activeSongForOptions = MutableStateFlow<SongEntity?>(null)
    val activeSongForOptions: StateFlow<SongEntity?> = _activeSongForOptions.asStateFlow()

    // Queue snackbar feedback
    private val _queueNotification = MutableStateFlow<String?>(null)
    val queueNotification: StateFlow<String?> = _queueNotification.asStateFlow()

    // Active User
    val activeUser: StateFlow<UserEntity?> = userRepo.activeUserFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Player State from audio engine
    val playerState: StateFlow<PlayerState> = DriyAudioPlayer.playerState

    // All songs catalog
    val allSongs: StateFlow<List<SongEntity>> = musicRepo.getAllSongs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Downloaded songs
    val downloadedSongs: StateFlow<List<SongEntity>> = musicRepo.getDownloadedSongs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Favorite songs
    val favoriteSongs: StateFlow<List<SongEntity>> = musicRepo.getFavoriteSongs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Music Folders
    val allFolders: StateFlow<List<FolderEntity>> = musicRepo.getAllFolders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val foldersWithStats: StateFlow<List<FolderWithStats>> = combine(
        musicRepo.getAllFolders(),
        allSongs
    ) { folders, _ ->
        folders.map { folder ->
            val count = musicRepo.getSongCountInFolder(folder.id)
            val cover = musicRepo.getLatestSongCoverInFolder(folder.id)
            FolderWithStats(folder, count, cover)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Uploaded Music
    val uploadedSongs: StateFlow<List<UploadedSongEntity>> = musicRepo.getAllUploadedSongs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Global Community Songs uploaded by any user in the world via Firebase Firestore
    val globalCommunitySongs: StateFlow<List<SongEntity>> = FirebaseMusicSyncManager.getGlobalCommunitySongsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active song for Folder Selection Bottom Sheet (opened on heart click!)
    private val _activeSongForFolderSelection = MutableStateFlow<SongEntity?>(null)
    val activeSongForFolderSelection: StateFlow<SongEntity?> = _activeSongForFolderSelection.asStateFlow()

    private val _selectedSongFolderIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedSongFolderIds: StateFlow<Set<String>> = _selectedSongFolderIds.asStateFlow()

    // Currently opened folder for Folder Detail View in Library
    private val _activeFolder = MutableStateFlow<FolderEntity?>(null)
    val activeFolder: StateFlow<FolderEntity?> = _activeFolder.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeFolderSongs: StateFlow<List<SongEntity>> = _activeFolder
        .flatMapLatest { folder ->
            if (folder != null) {
                musicRepo.getSongsInFolder(folder.id)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Onboarding State
    private val _selectedGenres = MutableStateFlow<Set<String>>(emptySet())
    val selectedGenres: StateFlow<Set<String>> = _selectedGenres.asStateFlow()

    private val _selectedArtists = MutableStateFlow<Set<String>>(emptySet())
    val selectedArtists: StateFlow<Set<String>> = _selectedArtists.asStateFlow()

    private val _artistSearchQuery = MutableStateFlow("")
    val artistSearchQuery: StateFlow<String> = _artistSearchQuery.asStateFlow()

    // Predictive Search in Home / Search Tab
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Download progress map: songId -> progress (0.0 to 1.0)
    private val _downloadProgress = MutableStateFlow<Map<String, Float>>(emptyMap())
    val downloadProgress: StateFlow<Map<String, Float>> = _downloadProgress.asStateFlow()

    // Real songs of user's chosen favorite artists from YouTube
    private val _favoriteArtistsSongs = MutableStateFlow<List<SongEntity>>(emptyList())
    val favoriteArtistsSongs: StateFlow<List<SongEntity>> = _favoriteArtistsSongs.asStateFlow()

    private val _isLoadingArtistSongs = MutableStateFlow(false)
    val isLoadingArtistSongs: StateFlow<Boolean> = _isLoadingArtistSongs.asStateFlow()

    // Hardware dynamic island detection status
    val isNativeIslandDetected: Boolean = DynamicIslandDetector.isNativeDynamicIslandPresent(application)

    private val _islandMode = MutableStateFlow(DriyAudioPlayer.getCustomIslandMode())
    val islandMode: StateFlow<String> = _islandMode.asStateFlow()

    fun setIslandMode(mode: String) {
        _islandMode.value = mode
        DriyAudioPlayer.setCustomIslandMode(mode)
    }

    init {
        viewModelScope.launch {
            musicRepo.ensureCatalogSeeded()
            checkInitialAuth()
        }
    }

    private suspend fun checkInitialAuth() {
        val user = authManager.getPersistedUser()
        if (user != null) {
            if (user.favoriteArtists.isNotEmpty()) {
                loadFavoriteArtistsSongs(user.favoriteArtists)
            }
            if (user.isOnboarded) {
                _currentScreen.value = Screen.Home
            } else if (user.favoriteGenres.size >= 4) {
                _selectedGenres.value = user.favoriteGenres.toSet()
                _currentScreen.value = Screen.OnboardingArtist
            } else {
                _currentScreen.value = Screen.OnboardingGenre
            }
        } else {
            _currentScreen.value = Screen.Login
        }
    }

    fun loadFavoriteArtistsSongs(artists: List<String>) {
        if (artists.isEmpty()) return
        viewModelScope.launch {
            _isLoadingArtistSongs.value = true
            val gatheredSongs = mutableListOf<SongEntity>()
            for (artist in artists.take(6)) {
                try {
                    val results = YouTubeService.searchYouTube("$artist official video")
                        .ifEmpty { YouTubeService.searchYouTube("$artist audio oficial") }
                    val artistTopSongs = results
                        .filter { it.durationSeconds in 60..390 }
                        .take(4).map { song ->
                            song.copy(artist = artist)
                        }
                    gatheredSongs.addAll(artistTopSongs)
                } catch (e: Exception) {
                    // continue
                }
            }

            if (gatheredSongs.isNotEmpty()) {
                val distinctSongs = gatheredSongs.distinctBy { it.id }
                _favoriteArtistsSongs.value = distinctSongs
                musicRepo.insertSongs(distinctSongs)
            }
            _isLoadingArtistSongs.value = false
        }
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun setFullPlayerVisible(visible: Boolean) {
        _isFullPlayerVisible.value = visible
    }

    // --- Authentication ---
    suspend fun checkUsernameTaken(username: String): Boolean {
        return userRepo.isUsernameTaken(username)
    }

    suspend fun findExistingAccount(username: String, phoneNumber: String): UserEntity? {
        return userRepo.findExistingAccount(username, phoneNumber)
    }

    suspend fun validateLoginCredentials(username: String, password: String, phoneNumber: String): String? {
        val cleanUsername = username.trim().removePrefix("@").lowercase()
        val cleanPhoneDigits = phoneNumber.filter { it.isDigit() }

        val user = userRepo.findExistingAccount(cleanUsername, cleanPhoneDigits)
            ?: return "No se encontró ninguna cuenta registrada con el usuario '@$cleanUsername'. Por favor verifica o crea una nueva cuenta."

        if (user.passwordHash.isNotBlank() && user.passwordHash != password) {
            return "La contraseña ingresada no es correcta."
        }

        val userPhoneDigits = user.phoneNumber.filter { it.isDigit() }
        if (userPhoneDigits.isNotBlank() && cleanPhoneDigits.isNotBlank()) {
            val matches = userPhoneDigits.endsWith(cleanPhoneDigits.takeLast(7)) ||
                          cleanPhoneDigits.endsWith(userPhoneDigits.takeLast(7)) ||
                          userPhoneDigits == cleanPhoneDigits
            if (!matches) {
                return "El número telefónico no coincide con el registrado en tu cuenta."
            }
        }

        return null
    }

    fun registerUserWithPhone(
        firstName: String,
        lastName: String,
        username: String,
        password: String,
        phoneNumber: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            try {
                val cleanUsername = username.trim().removePrefix("@").lowercase()

                // Double check uniqueness
                val existing = userRepo.findExistingAccount(cleanUsername, phoneNumber)
                if (existing != null) {
                    _isAuthenticating.value = false
                    withContext(Dispatchers.Main) {
                        onError("Ya existe una cuenta con el usuario '@$cleanUsername'. Por favor inicia sesión.")
                    }
                    return@launch
                }

                val newUser = userRepo.registerUserWithPhone(
                    firstName = firstName,
                    lastName = lastName,
                    username = cleanUsername,
                    password = password,
                    phoneNumber = phoneNumber
                )

                _isAuthenticating.value = false
                showNotification("✓ Cuenta creada exitosamente. ¡Bienvenido!")
                withContext(Dispatchers.Main) {
                    onSuccess()
                    _currentScreen.value = Screen.OnboardingGenre
                }
            } catch (e: Exception) {
                _isAuthenticating.value = false
                withContext(Dispatchers.Main) {
                    onError(e.message ?: "Error al registrar la cuenta")
                }
            }
        }
    }

    fun loginWithUserAndPhone(
        username: String,
        password: String,
        phoneNumber: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            val result = userRepo.loginWithUserAndPhone(
                username = username,
                password = password,
                phoneNumber = phoneNumber
            )
            _isAuthenticating.value = false
            result.onSuccess { user ->
                showNotification("✓ ¡Bienvenido de nuevo, ${user.displayName}!")
                withContext(Dispatchers.Main) {
                    onSuccess()
                    if (user.isOnboarded) {
                        _currentScreen.value = Screen.Home
                    } else {
                        _currentScreen.value = Screen.OnboardingGenre
                    }
                }
            }.onFailure { err ->
                withContext(Dispatchers.Main) {
                    onError(err.message ?: "Credenciales incorrectas")
                }
            }
        }
    }

    fun loginWithGoogle(activityContext: Context, customName: String? = null) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            val result = authManager.signInWithGoogleCredentialManager(activityContext, customName = customName)
            _isAuthenticating.value = false
            result.onSuccess { user ->
                if (user.isOnboarded) {
                    _currentScreen.value = Screen.Home
                } else {
                    _currentScreen.value = Screen.OnboardingGenre
                }
            }
        }
    }

    fun updateDisplayName(newName: String) {
        val user = activeUser.value ?: return
        val cleanName = newName.trim()
        if (cleanName.isBlank()) return
        viewModelScope.launch {
            userRepo.updateDisplayName(user.id, cleanName)
        }
    }

    fun updatePhotoUrl(newPhotoUrl: String) {
        val user = activeUser.value ?: return
        viewModelScope.launch {
            userRepo.updatePhotoUrl(user.id, newPhotoUrl)
            showNotification("✓ Foto de perfil actualizada")
        }
    }

    fun saveAndSetProfileImage(uri: Uri) {
        val user = activeUser.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val context = getApplication<Application>()
                val inputStream = context.contentResolver.openInputStream(uri)
                val file = File(context.filesDir, "avatar_${user.id}_${System.currentTimeMillis()}.jpg")
                val outputStream = FileOutputStream(file)
                inputStream?.copyTo(outputStream)
                inputStream?.close()
                outputStream.close()

                val savedUri = file.absolutePath
                userRepo.updatePhotoUrl(user.id, savedUri)
                showNotification("✓ Foto de perfil actualizada con éxito")
            } catch (e: Exception) {
                userRepo.updatePhotoUrl(user.id, uri.toString())
                showNotification("✓ Foto de perfil actualizada")
            }
        }
    }

    fun signOut() {
        viewModelScope.launch {
            authManager.signOut()
            _selectedGenres.value = emptySet()
            _selectedArtists.value = emptySet()
            _currentScreen.value = Screen.Login
        }
    }

    // --- Onboarding Flow ---
    fun getGenres(): List<Genre> = musicRepo.getAllGenres()

    fun toggleGenreSelection(genreId: String) {
        val current = _selectedGenres.value.toMutableSet()
        if (current.contains(genreId)) {
            current.remove(genreId)
        } else {
            current.add(genreId)
        }
        _selectedGenres.value = current
    }

    fun submitGenres() {
        if (_selectedGenres.value.size >= 4) {
            val user = activeUser.value
            if (user != null) {
                viewModelScope.launch {
                    userRepo.saveSelectedGenres(user.id, _selectedGenres.value.toList())
                }
            }
            _currentScreen.value = Screen.OnboardingArtist
        }
    }

    fun setArtistSearchQuery(query: String) {
        _artistSearchQuery.value = query
    }

    fun getArtistsForOnboarding(): List<Artist> {
        val query = _artistSearchQuery.value
        return if (query.isNotBlank()) {
            // Universal search: find artists of ANY genre in database
            musicRepo.searchArtists(query)
        } else {
            // Initial list: filtered by selected genres
            musicRepo.getArtistsForGenres(_selectedGenres.value.toList())
        }
    }

    fun toggleArtistSelection(artistName: String) {
        val current = _selectedArtists.value.toMutableSet()
        if (current.contains(artistName)) {
            current.remove(artistName)
        } else {
            current.add(artistName)
        }
        _selectedArtists.value = current
    }

    fun completeOnboarding() {
        if (_selectedArtists.value.size >= 4) {
            val user = activeUser.value
            val artistsList = _selectedArtists.value.toList()
            if (user != null) {
                viewModelScope.launch {
                    userRepo.completeOnboarding(user.id, artistsList)
                }
            }
            loadFavoriteArtistsSongs(artistsList)
            _currentScreen.value = Screen.Home
        }
    }

    // --- Predictive Search (Local + YouTube) ---
    private val _youtubeResults = MutableStateFlow<List<SongEntity>>(emptyList())
    private var searchJob: Job? = null

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        searchJob?.cancel()
        if (query.isBlank()) {
            _youtubeResults.value = emptyList()
            return
        }

        searchJob = viewModelScope.launch {
            delay(250) // debounce typing
            try {
                val results = YouTubeService.searchYouTube(query)
                _youtubeResults.value = results
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    val searchAutocompleteSuggestions: StateFlow<List<SongEntity>> = combine(
        allSongs,
        _searchQuery,
        _youtubeResults
    ) { songs, query, ytResults ->
        if (query.isBlank()) {
            emptyList()
        } else {
            val localMatches = songs.filter {
                it.title.contains(query, ignoreCase = true) ||
                it.artist.contains(query, ignoreCase = true) ||
                it.genre.contains(query, ignoreCase = true)
            }.take(4)

            // Merge local and YouTube results cleanly
            val combined = (localMatches + ytResults).distinctBy { it.id }
            combined.take(12)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Playback Controls ---
    fun playSong(song: SongEntity, queue: List<SongEntity> = emptyList()) {
        val finalQueue = if (queue.isNotEmpty()) queue else listOf(song)
        DriyAudioPlayer.playSong(song, finalQueue)
        viewModelScope.launch {
            if (song.genre == "YouTube") {
                musicRepo.insertSong(song)
            }
            musicRepo.recordPlay(song.id)
        }
    }

    fun togglePlayPause() {
        DriyAudioPlayer.togglePlayPause()
    }

    fun playNext() {
        DriyAudioPlayer.playNext()
    }

    fun playPrevious() {
        DriyAudioPlayer.playPrevious()
    }

    fun seekTo(positionMs: Long) {
        DriyAudioPlayer.seekTo(positionMs)
    }

    fun toggleShuffle() {
        DriyAudioPlayer.toggleShuffle()
    }

    fun toggleRepeat() {
        DriyAudioPlayer.toggleRepeat()
    }

    fun setQueueVisible(visible: Boolean) {
        _isQueueVisible.value = visible
    }

    fun openSongOptions(song: SongEntity) {
        _activeSongForOptions.value = song
    }

    fun dismissSongOptions() {
        _activeSongForOptions.value = null
    }

    fun addToQueueNext(song: SongEntity) {
        DriyAudioPlayer.addToQueueNext(song)
        showNotification("⏭ '${song.title}' pasará a primera en la cola")
    }

    fun addToQueueEnd(song: SongEntity) {
        DriyAudioPlayer.addToQueueEnd(song)
        showNotification("➕ '${song.title}' agregada al final de la cola")
    }

    fun removeFromQueue(songId: String) {
        DriyAudioPlayer.removeFromQueue(songId)
    }

    fun clearQueue() {
        DriyAudioPlayer.clearQueue()
        showNotification("🗑 Cola de reproducción vaciada")
    }

    private fun showNotification(msg: String) {
        _queueNotification.value = msg
        viewModelScope.launch {
            kotlinx.coroutines.delay(2600)
            if (_queueNotification.value == msg) {
                _queueNotification.value = null
            }
        }
    }

    fun dismissQueueNotification() {
        _queueNotification.value = null
    }

    fun toggleFavorite(song: SongEntity) {
        openFolderSelector(song)
    }

    // --- Custom Folder Management ---
    fun openFolderSelector(song: SongEntity) {
        _activeSongForFolderSelection.value = song
        viewModelScope.launch {
            val folderIds = musicRepo.getFolderIdsForSongOnce(song.id)
            _selectedSongFolderIds.value = folderIds.toSet()
        }
    }

    fun dismissFolderSelector() {
        _activeSongForFolderSelection.value = null
    }

    fun toggleSongInFolder(folder: FolderEntity, song: SongEntity) {
        viewModelScope.launch {
            val current = _selectedSongFolderIds.value
            val isCurrentlyIn = current.contains(folder.id)
            musicRepo.toggleSongInFolder(folder.id, song.id, isCurrentlyIn)
            val updated = if (isCurrentlyIn) current - folder.id else current + folder.id
            _selectedSongFolderIds.value = updated

            val msg = if (isCurrentlyIn) {
                "✕ Removida de '${folder.name}'"
            } else {
                "✓ Guardada en '${folder.name}'"
            }
            showNotification(msg)
        }
    }

    fun createFolderAndAddSong(folderName: String, song: SongEntity?) {
        viewModelScope.launch {
            val trimmedName = folderName.trim().ifBlank { "Mi Carpeta" }
            val newFolderId = musicRepo.createFolder(trimmedName)
            if (song != null) {
                musicRepo.addSongToFolder(newFolderId, song.id)
                _selectedSongFolderIds.value = _selectedSongFolderIds.value + newFolderId
                showNotification("📁 Carpeta '$trimmedName' creada y canción agregada")
            } else {
                showNotification("📁 Carpeta '$trimmedName' creada")
            }
        }
    }

    fun renameFolder(folderId: String, newName: String) {
        viewModelScope.launch {
            val trimmed = newName.trim().ifBlank { return@launch }
            musicRepo.updateFolderName(folderId, trimmed)
            if (_activeFolder.value?.id == folderId) {
                _activeFolder.value = _activeFolder.value?.copy(name = trimmed)
            }
            showNotification("✏ Carpeta renombrada a '$trimmed'")
        }
    }

    fun deleteFolder(folder: FolderEntity) {
        viewModelScope.launch {
            if (folder.isDefault) return@launch
            musicRepo.deleteFolder(folder.id)
            if (_activeFolder.value?.id == folder.id) {
                _activeFolder.value = null
            }
            showNotification("🗑 Carpeta '${folder.name}' eliminada")
        }
    }

    fun openFolderDetail(folder: FolderEntity) {
        _activeFolder.value = folder
    }

    fun closeFolderDetail() {
        _activeFolder.value = null
    }

    fun removeSongFromCurrentFolder(folderId: String, songId: String) {
        viewModelScope.launch {
            musicRepo.removeSongFromFolder(folderId, songId)
            showNotification("✕ Canción removida de la carpeta")
        }
    }

    // --- Offline Downloads ---
    fun downloadSong(song: SongEntity) {
        if (song.isDownloaded) {
            // Already downloaded, toggle remove
            viewModelScope.launch {
                musicRepo.removeDownload(song.id)
            }
            return
        }

        viewModelScope.launch {
            _downloadProgress.value = _downloadProgress.value + (song.id to 0.05f)
            musicRepo.downloadSong(song) { progress ->
                _downloadProgress.value = _downloadProgress.value + (song.id to progress)
            }
            _downloadProgress.value = _downloadProgress.value - song.id
        }
    }

    // Overlay permission check
    fun canDrawOverlays(): Boolean {
        return Settings.canDrawOverlays(getApplication())
    }

    fun openOverlaySettings(context: Context) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    fun uploadMusicWork(
        title: String,
        composer: String,
        authorshipPercentage: String,
        artist: String,
        genre: String,
        approxDuration: String,
        releaseDate: String,
        audioUri: Uri,
        audioFileName: String,
        pdfUri: Uri?,
        pdfFileName: String?,
        coverUri: Uri?,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val context = getApplication<Application>()
                val uploadsDir = File(context.filesDir, "uploads")
                if (!uploadsDir.exists()) uploadsDir.mkdirs()

                val workId = "user_track_${UUID.randomUUID()}"

                // 1. Copy Audio File (WAV, MP3, ZIP)
                val audioExtension = when {
                    audioFileName.endsWith(".wav", ignoreCase = true) -> "wav"
                    audioFileName.endsWith(".zip", ignoreCase = true) -> "zip"
                    audioFileName.endsWith(".m4a", ignoreCase = true) -> "m4a"
                    else -> "mp3"
                }
                val localAudioFile = File(uploadsDir, "${workId}.$audioExtension")
                context.contentResolver.openInputStream(audioUri)?.use { input ->
                    FileOutputStream(localAudioFile).use { output ->
                        input.copyTo(output)
                    }
                }

                // 2. Copy PDF Document (Letra / Partitura / Registro de Propiedad Intelectual)
                var localPdfPath: String? = null
                if (pdfUri != null) {
                    val localPdfFile = File(uploadsDir, "${workId}_legal.pdf")
                    context.contentResolver.openInputStream(pdfUri)?.use { input ->
                        FileOutputStream(localPdfFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    localPdfPath = localPdfFile.absolutePath
                }

                // 3. Copy Cover Image if provided
                var localCoverPath: String? = null
                if (coverUri != null) {
                    val localCoverFile = File(uploadsDir, "${workId}_cover.jpg")
                    context.contentResolver.openInputStream(coverUri)?.use { input ->
                        FileOutputStream(localCoverFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    localCoverPath = localCoverFile.absolutePath
                }

                val formatBadge = when {
                    audioFileName.endsWith(".wav", ignoreCase = true) -> "WAV"
                    audioFileName.endsWith(".zip", ignoreCase = true) -> "ZIP"
                    else -> "MP3"
                }

                val uploadedEntity = UploadedSongEntity(
                    id = workId,
                    title = title.trim(),
                    composer = composer.trim(),
                    authorshipPercentage = authorshipPercentage.trim().ifBlank { "100%" },
                    artist = artist.trim(),
                    genre = genre.trim().ifBlank { "Original" },
                    approxDuration = approxDuration.trim().ifBlank { "03:30" },
                    releaseDate = releaseDate.trim().ifBlank { "2026" },
                    audioFilePath = localAudioFile.absolutePath,
                    audioFileName = audioFileName,
                    audioFormatBadge = formatBadge,
                    pdfDocPath = localPdfPath,
                    pdfDocName = pdfFileName,
                    coverUrl = localCoverPath ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80",
                    isCopyrightDeclared = true
                )

                musicRepo.saveUploadedSong(uploadedEntity)
                showNotification("✓ Obra '$title' registrada exitosamente")
                withContext(Dispatchers.Main) {
                    onSuccess()
                }

                // Asynchronous Cloud Publishing to Firebase so ALL users worldwide can see and stream it
                val currentUser = activeUser.value
                viewModelScope.launch(Dispatchers.IO) {
                    val result = FirebaseMusicSyncManager.publishSongToGlobalCloud(
                        uploadedSong = uploadedEntity,
                        audioFile = localAudioFile,
                        pdfFile = localPdfPath?.let { File(it) },
                        coverFile = localCoverPath?.let { File(it) },
                        uploaderEmail = currentUser?.email,
                        uploaderName = currentUser?.displayName
                    )
                    if (result.isSuccess) {
                        showNotification("🌍 '$title' ahora es visible para todos los usuarios en el feed")
                    }
                }
            } catch (e: Exception) {
                showNotification("Error al procesar los archivos: ${e.message}")
            }
        }
    }

    fun deleteUploadedSong(uploaded: UploadedSongEntity) {
        viewModelScope.launch {
            musicRepo.deleteUploadedSong(uploaded)
            showNotification("✕ Obra musical eliminada")
        }
    }
}
