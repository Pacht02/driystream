package com.example.service

import android.util.Log
import com.example.data.model.UserEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object GlobalUserSyncClient {
    private const val TAG = "GlobalUserSync"
    private const val APP_KEY = "driystream_cloud_v1"
    private const val BASE_URL = "https://keyvalue.immanuel.co/api/KeyVal"

    private val client = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(4, TimeUnit.SECONDS)
        .build()

    fun cleanKey(raw: String): String {
        return raw.trim().removePrefix("@").lowercase().filter { it.isLetterOrDigit() || it == '_' }
    }

    /**
     * Checks if a username is already taken across ALL devices worldwide.
     */
    suspend fun isUsernameTakenGlobal(username: String): Boolean = withContext(Dispatchers.IO) {
        val clean = cleanKey(username)
        if (clean.length < 3) return@withContext false

        try {
            val request = Request.Builder()
                .url("$BASE_URL/GetValue/$APP_KEY/u_$clean")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val rawBody = response.body?.string()?.trim()?.removeSurrounding("\"") ?: ""
                    val isTaken = rawBody.isNotBlank() && rawBody != "null" && rawBody != "\"\""
                    if (isTaken) {
                        Log.d(TAG, "Username '$clean' is globally TAKEN on cloud store: $rawBody")
                        return@withContext true
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error checking global username: ${e.message}")
        }
        false
    }

    /**
     * Checks if a phone number is already registered across ALL devices.
     */
    suspend fun isPhoneRegisteredGlobal(phoneNumber: String): Boolean = withContext(Dispatchers.IO) {
        val cleanDigits = phoneNumber.filter { it.isDigit() }
        if (cleanDigits.length < 6) return@withContext false

        try {
            val request = Request.Builder()
                .url("$BASE_URL/GetValue/$APP_KEY/p_$cleanDigits")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val rawBody = response.body?.string()?.trim()?.removeSurrounding("\"") ?: ""
                    return@withContext rawBody.isNotBlank() && rawBody != "null" && rawBody != "\"\""
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error checking global phone: ${e.message}")
        }
        false
    }

    /**
     * Saves user account to the global cloud database so ANY device (Celular A, B, C) can see it.
     * Uses lightweight URL-encoded delimited values to guarantee 100% IIS compatibility.
     */
    suspend fun saveUserGlobal(user: UserEntity): Boolean = withContext(Dispatchers.IO) {
        val clean = cleanKey(user.username)
        val cleanPhone = user.phoneNumber.filter { it.isDigit() }.ifBlank { user.phoneNumber.trim() }

        try {
            // Compact serialized payload: phone|password|firstName|lastName
            val payload = "$cleanPhone|${user.passwordHash}|${user.firstName}|${user.lastName}"
            val encodedVal = URLEncoder.encode(payload, "UTF-8")

            // 1. Save user object by username
            val reqUser = Request.Builder()
                .url("$BASE_URL/UpdateValue/$APP_KEY/u_$clean/$encodedVal")
                .post(RequestBody.create(null, ByteArray(0)))
                .build()

            val success = client.newCall(reqUser).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                Log.d(TAG, "Cloud save response for '$clean': ${resp.code} $body")
                resp.isSuccessful
            }

            // 2. Save phone-to-username index
            if (cleanPhone.isNotBlank()) {
                val reqPhone = Request.Builder()
                    .url("$BASE_URL/UpdateValue/$APP_KEY/p_$cleanPhone/$clean")
                    .post(RequestBody.create(null, ByteArray(0)))
                    .build()
                client.newCall(reqPhone).execute().close()
            }

            Log.d(TAG, "User '$clean' successfully published to cloud store: $success")
            success
        } catch (e: Exception) {
            Log.e(TAG, "Error saving global user: ${e.message}", e)
            false
        }
    }

    /**
     * Retrieves user from global cloud database by username or phone number.
     */
    suspend fun getUserGlobal(usernameOrPhone: String): UserEntity? = withContext(Dispatchers.IO) {
        val clean = cleanKey(usernameOrPhone)
        val cleanPhone = usernameOrPhone.filter { it.isDigit() }

        var targetUsername = clean

        // If identifier looks like a phone number, resolve username index first
        if (clean.all { it.isDigit() || it == '+' } && cleanPhone.isNotBlank()) {
            try {
                val req = Request.Builder()
                    .url("$BASE_URL/GetValue/$APP_KEY/p_$cleanPhone")
                    .get()
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val body = resp.body?.string()?.trim()?.removeSurrounding("\"") ?: ""
                        if (body.isNotBlank() && body != "null" && body != "\"\"") {
                            targetUsername = cleanKey(body)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error resolving phone to username: ${e.message}")
            }
        }

        try {
            val req = Request.Builder()
                .url("$BASE_URL/GetValue/$APP_KEY/u_$targetUsername")
                .get()
                .build()

            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val rawBody = resp.body?.string()?.trim()?.removeSurrounding("\"") ?: ""
                    if (rawBody.isNotBlank() && rawBody != "null" && rawBody != "\"\"") {
                        val decoded = try { URLDecoder.decode(rawBody, "UTF-8") } catch (e: Exception) { rawBody }
                        val parts = decoded.split("|")
                        val phone = parts.getOrNull(0) ?: ""
                        val password = parts.getOrNull(1) ?: ""
                        val fName = parts.getOrNull(2) ?: ""
                        val lName = parts.getOrNull(3) ?: ""
                        val dName = "$fName $lName".trim().ifBlank { targetUsername }

                        return@withContext UserEntity(
                            id = targetUsername,
                            displayName = dName,
                            username = targetUsername,
                            firstName = fName,
                            lastName = lName,
                            phoneNumber = phone,
                            passwordHash = password,
                            isOnboarded = true,
                            createdAt = System.currentTimeMillis(),
                            email = "$targetUsername@driystream.com",
                            photoUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80"
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error fetching global user: ${e.message}")
        }
        null
    }
}
