package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Strict DriyStream Palette
val DriyBackground = Color(0xFF121212)      // Deep Black
val DriySurface = Color(0xFF212121)         // Dark Gray (Containers, Bottom Bar, Mini Player)
val DriySurfaceVariant = Color(0xFF2A2A2A)  // Slightly lighter container
val DriyGold = Color(0xFFE6B800)             // Golden Accent (Play/Pause, active progress bar)
val DriyGoldLight = Color(0xFFFFD54F)        // Lighter Gold highlight
val DriyTextPrimary = Color(0xFFEDEDED)     // Off-White (Titles, Songs, Artists)
val DriyTextSecondary = Color(0xFFA0A0A0)   // Light Gray (Icons, Subtitles, Secondary info)
val DriyDivider = Color(0xFF2C2C2C)
val DriyError = Color(0xFFCF6679)
