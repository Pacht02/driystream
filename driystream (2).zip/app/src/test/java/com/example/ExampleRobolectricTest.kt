package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.seed.CatalogSeed
import com.example.service.DynamicIslandDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context verifies DriyStream name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("DriyStream", appName)
    }

    @Test
    fun `catalog seed contains at least 8 genres and songs with audio`() {
        assertTrue(CatalogSeed.genres.size >= 8)
        assertTrue(CatalogSeed.artists.isNotEmpty())
        assertTrue(CatalogSeed.defaultSongs.isNotEmpty())
        assertTrue(CatalogSeed.defaultSongs.all { it.audioUrl.isNotBlank() })
    }

    @Test
    fun `dynamic island detector runs without crashing`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        // In Robolectric test runner it should safely return a boolean
        val result = DynamicIslandDetector.isNativeDynamicIslandPresent(context)
        // Standard Robolectric environment has no OEM dynamic island
        assertFalse(result)
    }
}
