package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.SongEntity
import com.example.data.model.UploadedSongEntity
import com.example.service.PlayerState
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriySurfaceVariant
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary

@Composable
fun UploadMusicScreen(
    uploadedSongs: List<UploadedSongEntity>,
    playerState: PlayerState,
    onUploadSong: (
        title: String,
        composer: String,
        authorshipPercentage: String,
        artist: String,
        genre: String,
        approxDuration: String,
        releaseDate: String,
        audioUri: Uri,
        audioFileName: String,
        pdfUri: Uri?,
        pdfFileName: String?,
        coverUri: Uri?,
        onSuccess: () -> Unit
    ) -> Unit,
    onPlayUploadedSong: (UploadedSongEntity) -> Unit,
    onDeleteUploadedSong: (UploadedSongEntity) -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Formulario de Subida, 1: Mis Obras Subidas

    // Form fields
    var title by remember { mutableStateOf("") }
    var composer by remember { mutableStateOf("") }
    var authorshipPercentage by remember { mutableStateOf("100%") }
    var artist by remember { mutableStateOf("") }
    var selectedGenre by remember { mutableStateOf("Pop") }
    var customGenre by remember { mutableStateOf("") }
    var approxDuration by remember { mutableStateOf("03:30") }
    var releaseDate by remember { mutableStateOf("2026") }

    // Files
    var selectedAudioUri by remember { mutableStateOf<Uri?>(null) }
    var audioFileName by remember { mutableStateOf<String?>(null) }
    var audioFileSize by remember { mutableStateOf<String?>(null) }

    var selectedPdfUri by remember { mutableStateOf<Uri?>(null) }
    var pdfFileName by remember { mutableStateOf<String?>(null) }
    var pdfFileSize by remember { mutableStateOf<String?>(null) }

    var selectedCoverUri by remember { mutableStateOf<Uri?>(null) }

    var isLegalCopyrightAccepted by remember { mutableStateOf(true) }
    var isUploading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var songToDelete by remember { mutableStateOf<UploadedSongEntity?>(null) }

    // Helper to query file name and size from content Uri
    fun queryFileInfo(uri: Uri): Pair<String, String> {
        var name = "archivo"
        var sizeStr = ""
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) name = cursor.getString(nameIndex)
                    if (sizeIndex != -1) {
                        val sizeBytes = cursor.getLong(sizeIndex)
                        val sizeMb = sizeBytes / (1024.0 * 1024.0)
                        sizeStr = String.format("%.2f MB", sizeMb)
                    }
                }
            }
        } catch (_: Exception) {}
        return Pair(name, sizeStr)
    }

    // Launchers
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedAudioUri = uri
            val (name, size) = queryFileInfo(uri)
            audioFileName = name
            audioFileSize = size
        }
    }

    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedPdfUri = uri
            val (name, size) = queryFileInfo(uri)
            pdfFileName = name
            pdfFileSize = size
        }
    }

    val coverPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedCoverUri = uri
        }
    }

    val genresList = listOf("Pop", "Rock", "Reggaetón", "Trap / Hip-Hop", "Electrónica", "R&B / Soul", "Acústico", "Balada", "Indie", "Clásica")

    Surface(
        color = DriyBackground,
        modifier = Modifier
            .fillMaxSize()
            .testTag("upload_music_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(DriyGold.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudUpload,
                        contentDescription = null,
                        tint = DriyGold,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = "Sube tu Música",
                        color = DriyTextPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Registro oficial de obras y streaming para artistas",
                        color = DriyTextSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Navigation Tabs (Subir Obra / Mis Obras)
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = DriySurface,
                contentColor = DriyGold,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = DriyGold
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            text = "Registrar Obra",
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == 0) DriyGold else DriyTextSecondary
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            text = "Mis Obras (${uploadedSongs.size})",
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == 1) DriyGold else DriyTextSecondary
                        )
                    }
                )
            }

            // Tab 0: Upload & Legal Registration Form
            if (selectedTab == 0) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 16.dp)
                        .padding(bottom = 90.dp)
                ) {
                    // Legal Banner
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DriySurface),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, DriyGold.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.VerifiedUser,
                                contentDescription = null,
                                tint = DriyGold,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Protección de Propiedad Intelectual: Registra tus derechos de autor, compositor y partituras en alta calidad.",
                                color = DriyTextSecondary,
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // 1. TÍTULO DE LA OBRA
                    Text(
                        text = "1. TÍTULO DE LA OBRA *",
                        color = DriyGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        placeholder = { Text("Ej: Amanecer en el Valle, Fuego Lento...", color = DriyTextSecondary, fontSize = 13.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = DriySurface,
                            unfocusedContainerColor = DriySurface,
                            focusedBorderColor = DriyGold,
                            unfocusedBorderColor = DriyDivider,
                            focusedTextColor = DriyTextPrimary,
                            unfocusedTextColor = DriyTextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("upload_title_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // 2. AUTOR O COMPOSITOR & PORCENTAJE DE AUTORÍA
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(modifier = Modifier.weight(1.3f)) {
                            Text(
                                text = "2. AUTOR O COMPOSITOR *",
                                color = DriyGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = composer,
                                onValueChange = { composer = it },
                                placeholder = { Text("Nombre legal", color = DriyTextSecondary, fontSize = 13.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = DriySurface,
                                    unfocusedContainerColor = DriySurface,
                                    focusedBorderColor = DriyGold,
                                    unfocusedBorderColor = DriyDivider,
                                    focusedTextColor = DriyTextPrimary,
                                    unfocusedTextColor = DriyTextPrimary
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("upload_composer_input")
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "% AUTORÍA *",
                                color = DriyGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = authorshipPercentage,
                                onValueChange = { authorshipPercentage = it },
                                placeholder = { Text("100%", color = DriyTextSecondary, fontSize = 13.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = DriySurface,
                                    unfocusedContainerColor = DriySurface,
                                    focusedBorderColor = DriyGold,
                                    unfocusedBorderColor = DriyDivider,
                                    focusedTextColor = DriyTextPrimary,
                                    unfocusedTextColor = DriyTextPrimary
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("upload_percentage_input")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 3. NOMBRE DEL ARTISTA O BANDA
                    Text(
                        text = "3. NOMBRE DEL ARTISTA O BANDA *",
                        color = DriyGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = artist,
                        onValueChange = { artist = it },
                        placeholder = { Text("Nombre artístico con el que se publica", color = DriyTextSecondary, fontSize = 13.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = DriySurface,
                            unfocusedContainerColor = DriySurface,
                            focusedBorderColor = DriyGold,
                            unfocusedBorderColor = DriyDivider,
                            focusedTextColor = DriyTextPrimary,
                            unfocusedTextColor = DriyTextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("upload_artist_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // 4. GÉNERO MUSICAL
                    Text(
                        text = "4. GÉNERO MUSICAL",
                        color = DriyGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(genresList) { g ->
                            val isSelected = selectedGenre == g
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedGenre = g },
                                label = { Text(g, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = DriyGold,
                                    selectedLabelColor = DriyBackground,
                                    containerColor = DriySurface,
                                    labelColor = DriyTextPrimary
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    borderColor = DriyDivider,
                                    selectedBorderColor = DriyGold,
                                    enabled = true,
                                    selected = isSelected
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 5. DURACIÓN APROXIMADA & AÑO DE LANZAMIENTO
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "5. DURACIÓN (MM:SS) *",
                                color = DriyGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = approxDuration,
                                onValueChange = { approxDuration = it },
                                placeholder = { Text("03:30", color = DriyTextSecondary, fontSize = 13.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = DriySurface,
                                    unfocusedContainerColor = DriySurface,
                                    focusedBorderColor = DriyGold,
                                    unfocusedBorderColor = DriyDivider,
                                    focusedTextColor = DriyTextPrimary,
                                    unfocusedTextColor = DriyTextPrimary
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("upload_duration_input")
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "AÑO / FECHA *",
                                color = DriyGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = releaseDate,
                                onValueChange = { releaseDate = it },
                                placeholder = { Text("2026", color = DriyTextSecondary, fontSize = 13.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = DriySurface,
                                    unfocusedContainerColor = DriySurface,
                                    focusedBorderColor = DriyGold,
                                    unfocusedBorderColor = DriyDivider,
                                    focusedTextColor = DriyTextPrimary,
                                    unfocusedTextColor = DriyTextPrimary
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("upload_date_input")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    HorizontalDivider(color = DriyDivider)
                    Spacer(modifier = Modifier.height(16.dp))

                    // 6. ARCHIVO DE AUDIO DIGITAL (WAV / MP3 / ZIP)
                    Text(
                        text = "6. ARCHIVO DE AUDIO DIGITAL (WAV / MP3 / ZIP) *",
                        color = DriyGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Formatos soportados: WAV (alta calidad master), MP3 o ZIP de la sesión musical",
                        color = DriyTextSecondary,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedAudioUri != null) DriySurfaceVariant else DriySurface
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (selectedAudioUri != null) DriyGold else DriyDivider,
                                RoundedCornerShape(14.dp)
                            )
                            .clickable { audioPickerLauncher.launch("*/*") }
                            .testTag("upload_audio_picker_btn")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (selectedAudioUri != null) DriyGold else DriySurface),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Audiotrack,
                                    contentDescription = null,
                                    tint = if (selectedAudioUri != null) DriyBackground else DriyGold,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                if (selectedAudioUri != null) {
                                    Text(
                                        text = audioFileName ?: "Audio seleccionado",
                                        color = DriyTextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Listo para procesar • ${audioFileSize ?: ""}",
                                        color = DriyGold,
                                        fontSize = 12.sp
                                    )
                                } else {
                                    Text(
                                        text = "Seleccionar archivo de audio",
                                        color = DriyTextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Toca para explorar tus archivos WAV / MP3 / ZIP",
                                        color = DriyTextSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            if (selectedAudioUri != null) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Audio cargado",
                                    tint = DriyGold,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 7. LETRA O PARTITURA (DOCUMENTO PDF LEGAL)
                    Text(
                        text = "7. LETRA O PARTITURA (DOCUMENTO EN PDF)",
                        color = DriyGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Documento en PDF con la letra escrita y/o la partitura musical para registro legal de propiedad intelectual",
                        color = DriyTextSecondary,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedPdfUri != null) DriySurfaceVariant else DriySurface
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (selectedPdfUri != null) DriyGold else DriyDivider,
                                RoundedCornerShape(14.dp)
                            )
                            .clickable { pdfPickerLauncher.launch("application/pdf") }
                            .testTag("upload_pdf_picker_btn")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (selectedPdfUri != null) Color(0xFFEF5350).copy(alpha = 0.2f) else DriySurface),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PictureAsPdf,
                                    contentDescription = null,
                                    tint = if (selectedPdfUri != null) Color(0xFFEF5350) else DriyTextSecondary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                if (selectedPdfUri != null) {
                                    Text(
                                        text = pdfFileName ?: "Documento PDF",
                                        color = DriyTextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Letra / Partitura adjunta • ${pdfFileSize ?: ""}",
                                        color = DriyGold,
                                        fontSize = 12.sp
                                    )
                                } else {
                                    Text(
                                        text = "Adjuntar Letra o Partitura (PDF)",
                                        color = DriyTextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Opcional pero recomendado para respaldo legal de autoría",
                                        color = DriyTextSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            if (selectedPdfUri != null) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "PDF cargado",
                                    tint = DriyGold,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 8. PORTADA DEL SINGLE (OPCIONAL)
                    Text(
                        text = "8. PORTADA DEL SINGLE O ÁLBUM (OPCIONAL)",
                        color = DriyGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = DriySurface),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, DriyDivider, RoundedCornerShape(14.dp))
                            .clickable {
                                coverPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                            .testTag("upload_cover_picker_btn")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (selectedCoverUri != null) {
                                AsyncImage(
                                    model = selectedCoverUri,
                                    contentDescription = "Carátula",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(50.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(50.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(DriySurfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Image,
                                        contentDescription = null,
                                        tint = DriyTextSecondary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (selectedCoverUri != null) "Carátula personalizada lista" else "Elegir portada de galería",
                                    color = DriyTextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Formato cuadrado 1:1 recomendado",
                                    color = DriyTextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // 9. DECLARACIÓN LEGAL
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isLegalCopyrightAccepted = !isLegalCopyrightAccepted },
                        verticalAlignment = Alignment.Top
                    ) {
                        Checkbox(
                            checked = isLegalCopyrightAccepted,
                            onCheckedChange = { isLegalCopyrightAccepted = it },
                            colors = CheckboxDefaults.colors(
                                checkedColor = DriyGold,
                                checkmarkColor = DriyBackground,
                                uncheckedColor = DriyTextSecondary
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Declaro bajo juramento que soy el legítimo autor, compositor o titular de los derechos de autor de esta obra musical, y autorizo su procesamiento y streaming en la plataforma.",
                            color = DriyTextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = errorMessage ?: "",
                            color = Color(0xFFEF5350),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // SUBMIT BUTTON
                    Button(
                        onClick = {
                            if (title.isBlank()) {
                                errorMessage = "Por favor introduce el título de tu obra"
                                return@Button
                            }
                            if (composer.isBlank()) {
                                errorMessage = "Por favor indica el nombre del autor o compositor"
                                return@Button
                            }
                            if (artist.isBlank()) {
                                errorMessage = "Por favor indica el nombre del artista o banda"
                                return@Button
                            }
                            if (selectedAudioUri == null) {
                                errorMessage = "Debes seleccionar tu archivo de audio (WAV, MP3 o ZIP)"
                                return@Button
                            }
                            if (!isLegalCopyrightAccepted) {
                                errorMessage = "Debes aceptar la declaración de derechos de autor"
                                return@Button
                            }

                            errorMessage = null
                            isUploading = true

                            onUploadSong(
                                title,
                                composer,
                                authorshipPercentage,
                                artist,
                                selectedGenre,
                                approxDuration,
                                releaseDate,
                                selectedAudioUri!!,
                                audioFileName ?: "audio_track.mp3",
                                selectedPdfUri,
                                pdfFileName,
                                selectedCoverUri
                            ) {
                                isUploading = false
                                // Reset fields and navigate to list
                                title = ""
                                composer = ""
                                artist = ""
                                selectedAudioUri = null
                                audioFileName = null
                                selectedPdfUri = null
                                pdfFileName = null
                                selectedCoverUri = null
                                selectedTab = 1
                            }
                        },
                        enabled = !isUploading,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = DriyGold,
                            contentColor = DriyBackground
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("submit_upload_work_btn")
                    ) {
                        if (isUploading) {
                            CircularProgressIndicator(
                                color = DriyBackground,
                                modifier = Modifier.size(24.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Procesando y registrando obra...", fontWeight = FontWeight.Bold)
                        } else {
                            Icon(
                                imageVector = Icons.Default.CloudUpload,
                                contentDescription = null,
                                tint = DriyBackground,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Subir y Registrar Obra Musical",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
            // Tab 1: Uploaded Songs List
            else {
                if (uploadedSongs.isEmpty()) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = null,
                                tint = DriyTextSecondary,
                                modifier = Modifier.size(60.dp)
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Aún no has registrado música",
                                color = DriyTextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Usa el formulario de registro para subir tus temas en WAV, MP3 o ZIP y proteger tus derechos de autor.",
                                color = DriyTextSecondary,
                                fontSize = 13.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(18.dp))
                            Button(
                                onClick = { selectedTab = 0 },
                                colors = ButtonDefaults.buttonColors(containerColor = DriyGold, contentColor = DriyBackground),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Registrar mi primera canción", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 90.dp)
                    ) {
                        items(uploadedSongs, key = { it.id }) { item ->
                            UploadedSongCard(
                                uploaded = item,
                                isPlaying = playerState.isPlaying && playerState.currentSong?.id == item.id,
                                onPlay = { onPlayUploadedSong(item) },
                                onDelete = { songToDelete = item }
                            )
                        }
                    }
                }
            }
        }
    }

    // Delete Confirmation Dialog
    if (songToDelete != null) {
        AlertDialog(
            onDismissRequest = { songToDelete = null },
            containerColor = DriySurface,
            title = { Text("Eliminar obra registrada", color = DriyTextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "¿Deseas eliminar '${songToDelete?.title}' de tus canciones subidas? Se removerá del reproductor y catálogo local.",
                    color = DriyTextSecondary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        songToDelete?.let { onDeleteUploadedSong(it) }
                        songToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF5350))
                ) {
                    Text("Eliminar", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { songToDelete = null }) {
                    Text("Cancelar", color = DriyTextSecondary)
                }
            }
        )
    }
}

@Composable
fun UploadedSongCard(
    uploaded: UploadedSongEntity,
    isPlaying: Boolean,
    onPlay: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DriySurface),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DriyGold.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Cover
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(DriySurfaceVariant)
                ) {
                    AsyncImage(
                        model = uploaded.coverUrl ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80",
                        contentDescription = uploaded.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = uploaded.title,
                        color = DriyTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${uploaded.artist} • ${uploaded.genre}",
                        color = DriyTextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Autor: ${uploaded.composer} (${uploaded.authorshipPercentage})",
                        color = DriyGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Play / Pause Button
                IconButton(
                    onClick = onPlay,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(DriyGold)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Reproducir",
                        tint = DriyBackground,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = DriyDivider)
            Spacer(modifier = Modifier.height(8.dp))

            // Badges row: Format, Year, PDF indicator, and Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Audio Format Badge
                    Surface(
                        color = DriyGold.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = uploaded.audioFormatBadge,
                            color = DriyGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    // Duration Badge
                    Surface(
                        color = DriySurfaceVariant,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = uploaded.approxDuration,
                            color = DriyTextSecondary,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    // PDF Legal Badge
                    if (uploaded.pdfDocPath != null) {
                        Surface(
                            color = Color(0xFFEF5350).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PictureAsPdf,
                                    contentDescription = null,
                                    tint = Color(0xFFEF5350),
                                    modifier = Modifier.size(10.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "PDF LEGAL",
                                    color = Color(0xFFEF5350),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Eliminar",
                        tint = DriyTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
