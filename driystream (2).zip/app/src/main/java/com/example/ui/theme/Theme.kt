package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DriyColorScheme = darkColorScheme(
    primary = DriyGold,
    onPrimary = DriyBackground,
    primaryContainer = DriySurfaceVariant,
    onPrimaryContainer = DriyGold,
    secondary = DriyGold,
    onSecondary = DriyBackground,
    secondaryContainer = DriySurfaceVariant,
    onSecondaryContainer = DriyTextPrimary,
    tertiary = DriyGoldLight,
    onTertiary = DriyBackground,
    background = DriyBackground,
    onBackground = DriyTextPrimary,
    surface = DriySurface,
    onSurface = DriyTextPrimary,
    surfaceVariant = DriySurfaceVariant,
    onSurfaceVariant = DriyTextSecondary,
    outline = DriyDivider,
    error = DriyError,
    onError = Color.White
)

@Composable
fun DriyStreamTheme(
    content: @Composable () -> Unit
) {
    // DriyStream enforces its signature dark theme palette
    MaterialTheme(
        colorScheme = DriyColorScheme,
        typography = Typography,
        content = content
    )
}
