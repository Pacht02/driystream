package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Artist
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriySurfaceVariant
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary

@Composable
fun OnboardingArtistScreen(
    artists: List<Artist>,
    selectedArtistNames: Set<String>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onToggleArtist: (String) -> Unit,
    onFinish: () -> Unit
) {
    val canFinish = selectedArtistNames.size >= 4

    Surface(
        color = DriyBackground, // #121212
        modifier = Modifier
            .fillMaxSize()
            .testTag("onboarding_artist_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 24.dp)
        ) {
            // Header
            Text(
                text = "PASO 2 DE 2",
                color = DriyGold,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Elige tus cantantes favoritos",
                color = DriyTextPrimary,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Selecciona al menos 4 artistas. Puedes usar el buscador universal para encontrar artistas de cualquier género.",
                color = DriyTextSecondary,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Universal Search Bar with magnifying glass
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = {
                    Text("Buscar cantante de cualquier género...", color = DriyTextSecondary, fontSize = 14.sp)
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Buscar",
                        tint = DriyGold,
                        modifier = Modifier.size(22.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Limpiar",
                                tint = DriyTextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DriySurface,
                    unfocusedContainerColor = DriySurface,
                    focusedBorderColor = DriyGold,
                    unfocusedBorderColor = DriyDivider,
                    focusedTextColor = DriyTextPrimary,
                    unfocusedTextColor = DriyTextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("onboarding_artist_search")
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Counter Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(DriySurfaceVariant)
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "${selectedArtistNames.size} de 4 seleccionados",
                    color = if (canFinish) DriyGold else DriyTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (canFinish) {
                    Spacer(modifier = Modifier.size(6.dp))
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = DriyGold,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Artists List
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(artists) { artist ->
                    val isSelected = selectedArtistNames.contains(artist.name)
                    ArtistRowItem(
                        artist = artist,
                        isSelected = isSelected,
                        onClick = { onToggleArtist(artist.name) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Finish Onboarding Button (minimum 4 validated)
            Button(
                onClick = onFinish,
                enabled = canFinish,
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = DriyGold,
                    contentColor = DriyBackground,
                    disabledContainerColor = DriySurfaceVariant,
                    disabledContentColor = DriyTextSecondary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("artist_finish_button")
            ) {
                Text(
                    text = if (canFinish) "Comenzar a escuchar en DriyStream" else "Elige al menos 4 cantantes",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun ArtistRowItem(
    artist: Artist,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) DriySurfaceVariant else DriySurface
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) DriyGold else DriyDivider,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable { onClick() }
            .testTag("artist_item_${artist.id}")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Artist Avatar
            AsyncImage(
                model = artist.imageUrl,
                contentDescription = artist.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
            )

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = artist.name,
                    color = if (isSelected) DriyGold else DriyTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${artist.genre.uppercase()} • ${artist.followers}",
                    color = DriyTextSecondary,
                    fontSize = 12.sp
                )
            }

            // Selection Checkbox Badge
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) DriyGold else Color.Transparent)
                    .border(
                        1.5.dp,
                        if (isSelected) DriyGold else DriyTextSecondary,
                        CircleShape
                    )
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Seleccionado",
                        tint = DriyBackground,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
