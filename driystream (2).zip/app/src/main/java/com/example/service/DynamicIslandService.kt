package com.example.service

import android.animation.ValueAnimator
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.CountDownTimer
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class DynamicIslandService : Service() {
    private var windowManager: WindowManager? = null
    private var islandRootView: LinearLayout? = null
    private var isExpanded: Boolean = false

    // Views inside island
    private var minimizedContainer: LinearLayout? = null
    private var expandedContainer: LinearLayout? = null
    private var songTitleTv: TextView? = null
    private var artistTv: TextView? = null
    private var playPauseBtn: ImageView? = null
    private var visualizerBar1: View? = null
    private var visualizerBar2: View? = null
    private var visualizerBar3: View? = null
    private var visualizerAnimator: ValueAnimator? = null

    // 5-minute inactivity timer when paused
    private var inactivityTimer: CountDownTimer? = null
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        private const val TAG = "DynamicIslandService"
        const val ACTION_SHOW = "com.example.ACTION_SHOW_ISLAND"
        const val ACTION_HIDE = "com.example.ACTION_HIDE_ISLAND"
        const val ACTION_UPDATE = "com.example.ACTION_UPDATE_ISLAND"

        const val EXTRA_TITLE = "extra_island_title"
        const val EXTRA_ARTIST = "extra_island_artist"
        const val EXTRA_IS_PLAYING = "extra_island_is_playing"

        private const val INACTIVITY_TIMEOUT_MS = 5 * 60 * 1000L // 5 minutes

        fun show(context: Context, title: String, artist: String, isPlaying: Boolean) {
            // Check hardware detection first
            if (DynamicIslandDetector.isNativeDynamicIslandPresent(context)) {
                Log.d(TAG, "Native dynamic island present on device. Skipping custom overlay.")
                return
            }

            // Check overlay permission
            if (!Settings.canDrawOverlays(context)) {
                Log.w(TAG, "SYSTEM_ALERT_WINDOW permission not granted.")
                return
            }

            val intent = Intent(context, DynamicIslandService::class.java).apply {
                action = ACTION_SHOW
                putExtra(EXTRA_TITLE, title)
                putExtra(EXTRA_ARTIST, artist)
                putExtra(EXTRA_IS_PLAYING, isPlaying)
            }
            context.startService(intent)
        }

        fun hide(context: Context) {
            val intent = Intent(context, DynamicIslandService::class.java).apply {
                action = ACTION_HIDE
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            when (it.action) {
                ACTION_SHOW -> {
                    val title = it.getStringExtra(EXTRA_TITLE) ?: "DriyStream"
                    val artist = it.getStringExtra(EXTRA_ARTIST) ?: "Música"
                    val isPlaying = it.getBooleanExtra(EXTRA_IS_PLAYING, true)
                    showOrUpdateIsland(title, artist, isPlaying)
                }
                ACTION_HIDE -> {
                    removeIslandView()
                }
                ACTION_UPDATE -> {
                    val isPlaying = it.getBooleanExtra(EXTRA_IS_PLAYING, true)
                    updatePlaybackState(isPlaying)
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun showOrUpdateIsland(title: String, artist: String, isPlaying: Boolean) {
        if (!Settings.canDrawOverlays(this)) return

        if (islandRootView == null) {
            createIslandView()
        }

        songTitleTv?.text = title
        artistTv?.text = artist
        updatePlaybackState(isPlaying)
    }

    private fun createIslandView() {
        if (islandRootView != null) return

        val dpToPx = { dp: Int ->
            TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp.toFloat(),
                resources.displayMetrics
            ).toInt()
        }

        // WindowManager LayoutParams:
        // Positioned STRICTLY top-center, margin ~1 cm (36dp) from top edge
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dpToPx(38) // ~1 cm from top edge
            x = 0
        }

        // Root container: Deep Black #121212 pill with subtle border
        islandRootView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dpToPx(12), dpToPx(8), dpToPx(12), dpToPx(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#121212"))
                cornerRadius = dpToPx(24).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#2A2A2A"))
            }
            elevation = dpToPx(8).toFloat()

            setOnClickListener {
                toggleExpansion()
            }
        }

        // --- Minimized Container ---
        // Requirement: Only music icon + animated waveform. NO search icon!
        minimizedContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

            // Music note icon
            val musicIcon = ImageView(this@DynamicIslandService).apply {
                setImageResource(android.R.drawable.ic_media_play)
                setColorFilter(Color.parseColor("#E6B800")) // DriyGold
                layoutParams = LinearLayout.LayoutParams(dpToPx(16), dpToPx(16)).apply {
                    marginEnd = dpToPx(10)
                }
            }
            addView(musicIcon)

            // Equalizer Bars (Waveform animation)
            val barsLayout = LinearLayout(this@DynamicIslandService).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.BOTTOM
                layoutParams = LinearLayout.LayoutParams(dpToPx(24), dpToPx(16))

                visualizerBar1 = View(this@DynamicIslandService).apply {
                    background = GradientDrawable().apply {
                        setColor(Color.parseColor("#E6B800"))
                        cornerRadius = dpToPx(2).toFloat()
                    }
                    layoutParams = LinearLayout.LayoutParams(dpToPx(4), dpToPx(8)).apply {
                        marginEnd = dpToPx(3)
                    }
                }
                visualizerBar2 = View(this@DynamicIslandService).apply {
                    background = GradientDrawable().apply {
                        setColor(Color.parseColor("#E6B800"))
                        cornerRadius = dpToPx(2).toFloat()
                    }
                    layoutParams = LinearLayout.LayoutParams(dpToPx(4), dpToPx(14)).apply {
                        marginEnd = dpToPx(3)
                    }
                }
                visualizerBar3 = View(this@DynamicIslandService).apply {
                    background = GradientDrawable().apply {
                        setColor(Color.parseColor("#E6B800"))
                        cornerRadius = dpToPx(2).toFloat()
                    }
                    layoutParams = LinearLayout.LayoutParams(dpToPx(4), dpToPx(10))
                }

                addView(visualizerBar1)
                addView(visualizerBar2)
                addView(visualizerBar3)
            }
            addView(barsLayout)
        }
        islandRootView?.addView(minimizedContainer)

        // --- Expanded Container ---
        // Reveals slightly: Previous, Play/Pause, Next, Title, Artist
        expandedContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

            // Text column
            val textLayout = LinearLayout(this@DynamicIslandService).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(dpToPx(140), LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    marginEnd = dpToPx(8)
                }

                songTitleTv = TextView(this@DynamicIslandService).apply {
                    setTextColor(Color.parseColor("#EDEDED")) // Blanco Roto
                    textSize = 12f
                    isSingleLine = true
                    text = "DriyStream"
                }
                artistTv = TextView(this@DynamicIslandService).apply {
                    setTextColor(Color.parseColor("#A0A0A0")) // Gris Claro
                    textSize = 10f
                    isSingleLine = true
                    text = "Reproduciendo"
                }

                addView(songTitleTv)
                addView(artistTv)
            }
            addView(textLayout)

            // Previous Button
            val prevBtn = ImageView(this@DynamicIslandService).apply {
                setImageResource(android.R.drawable.ic_media_previous)
                setColorFilter(Color.parseColor("#EDEDED"))
                layoutParams = LinearLayout.LayoutParams(dpToPx(28), dpToPx(28)).apply {
                    marginEnd = dpToPx(6)
                }
                setOnClickListener {
                    DriyAudioPlayer.playPrevious()
                }
            }
            addView(prevBtn)

            // Play/Pause Button (Gold Accent #E6B800)
            playPauseBtn = ImageView(this@DynamicIslandService).apply {
                setImageResource(android.R.drawable.ic_media_pause)
                setColorFilter(Color.parseColor("#121212")) // Dark icon on gold circle
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#E6B800"))
                    shape = GradientDrawable.OVAL
                }
                setPadding(dpToPx(6), dpToPx(6), dpToPx(6), dpToPx(6))
                layoutParams = LinearLayout.LayoutParams(dpToPx(32), dpToPx(32)).apply {
                    marginEnd = dpToPx(6)
                }
                setOnClickListener {
                    DriyAudioPlayer.togglePlayPause()
                }
            }
            addView(playPauseBtn)

            // Next Button
            val nextBtn = ImageView(this@DynamicIslandService).apply {
                setImageResource(android.R.drawable.ic_media_next)
                setColorFilter(Color.parseColor("#EDEDED"))
                layoutParams = LinearLayout.LayoutParams(dpToPx(28), dpToPx(28))
                setOnClickListener {
                    DriyAudioPlayer.playNext()
                }
            }
            addView(nextBtn)
        }
        islandRootView?.addView(expandedContainer)

        try {
            windowManager?.addView(islandRootView, params)
            startVisualizerAnimation()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to attach floating overlay", e)
        }
    }

    private fun toggleExpansion() {
        isExpanded = !isExpanded
        if (isExpanded) {
            minimizedContainer?.visibility = View.GONE
            expandedContainer?.visibility = View.VISIBLE
        } else {
            expandedContainer?.visibility = View.GONE
            minimizedContainer?.visibility = View.VISIBLE
        }
    }

    private fun updatePlaybackState(isPlaying: Boolean) {
        if (isPlaying) {
            cancelInactivityTimer()
            playPauseBtn?.setImageResource(android.R.drawable.ic_media_pause)
            startVisualizerAnimation()
        } else {
            playPauseBtn?.setImageResource(android.R.drawable.ic_media_play)
            pauseVisualizerAnimation()
            startInactivityTimer()
        }
    }

    private fun startVisualizerAnimation() {
        if (visualizerAnimator?.isRunning == true) return
        visualizerAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { anim ->
                val fraction = anim.animatedFraction
                val dpToPx = { dp: Int -> (dp * resources.displayMetrics.density).toInt() }
                visualizerBar1?.layoutParams?.height = dpToPx((6 + fraction * 8).toInt())
                visualizerBar1?.requestLayout()
                visualizerBar2?.layoutParams?.height = dpToPx((14 - fraction * 7).toInt())
                visualizerBar2?.requestLayout()
                visualizerBar3?.layoutParams?.height = dpToPx((8 + fraction * 6).toInt())
                visualizerBar3?.requestLayout()
            }
            start()
        }
    }

    private fun pauseVisualizerAnimation() {
        visualizerAnimator?.cancel()
        visualizerAnimator = null
    }

    /**
     * Requirement: If music is paused from the island or player, start a 5-minute inactivity timer.
     * If 5 minutes pass without resuming music, the island automatically disappears.
     */
    private fun startInactivityTimer() {
        cancelInactivityTimer()
        inactivityTimer = object : CountDownTimer(INACTIVITY_TIMEOUT_MS, 10000) {
            override fun onTick(millisUntilFinished: Long) {
                // Counting down 5 minutes...
            }

            override fun onFinish() {
                Log.d(TAG, "5-minute inactivity reached. Dismissing Dynamic Island overlay.")
                removeIslandView()
            }
        }.start()
    }

    private fun cancelInactivityTimer() {
        inactivityTimer?.cancel()
        inactivityTimer = null
    }

    /**
     * Requirement: Screen rotation must reposition the island centered at the top.
     */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        recenterIsland()
    }

    private fun recenterIsland() {
        val view = islandRootView ?: return
        val wm = windowManager ?: return
        try {
            val params = view.layoutParams as? WindowManager.LayoutParams ?: return
            params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            params.x = 0
            val dpToPx = (38 * resources.displayMetrics.density).toInt()
            params.y = dpToPx
            wm.updateViewLayout(view, params)
        } catch (e: Exception) {
            Log.e(TAG, "Error recentering island", e)
        }
    }

    private fun removeIslandView() {
        cancelInactivityTimer()
        pauseVisualizerAnimation()
        islandRootView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing island view", e)
            }
        }
        islandRootView = null
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        removeIslandView()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
