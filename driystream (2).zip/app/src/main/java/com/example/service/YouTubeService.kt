package com.example.service

import android.util.Log
import com.example.data.model.SongEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.regex.Pattern

object YouTubeService {
    private const val TAG = "YouTubeService"

    /**
     * Search YouTube for songs/videos matching query.
     * Supports both YouTube Data API v3 (if apiKey is supplied) and
     * high-speed scraping of YouTube results with fallback to suggest queries.
     */
    suspend fun searchYouTube(query: String, apiKey: String? = null): List<SongEntity> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()

        // 1. Try YouTube Data API v3 if apiKey is valid
        if (!apiKey.isNullOrBlank()) {
            val apiResults = searchWithYouTubeDataApi(query, apiKey)
            if (apiResults.isNotEmpty()) return@withContext apiResults
        }

        // 2. High-speed direct search
        val directResults = searchDirectYouTube(query)
        if (directResults.isNotEmpty()) return@withContext directResults

        // 3. Fallback to suggest queries
        return@withContext searchSuggestQueries(query)
    }

    private fun searchWithYouTubeDataApi(query: String, apiKey: String): List<SongEntity> {
        try {
            val encodedQuery = URLEncoder.encode(query, "UTF-8")
            val urlString = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=15&q=$encodedQuery&key=$apiKey"
            val connection = URL(urlString).openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 8000
            connection.readTimeout = 8000

            if (connection.responseCode == 200) {
                val json = connection.inputStream.bufferedReader().use { it.readText() }
                val root = JSONObject(json)
                val items = root.optJSONArray("items") ?: return emptyList()
                val list = mutableListOf<SongEntity>()

                for (i in 0 until items.length()) {
                    val item = items.getJSONObject(i)
                    val idObj = item.optJSONObject("id") ?: continue
                    val videoId = idObj.optString("videoId")
                    if (videoId.isNullOrBlank()) continue

                    val snippet = item.optJSONObject("snippet") ?: continue
                    val rawTitle = snippet.optString("title", "Desconocido")
                    if (isLikelyLongMixOrAlbum(rawTitle, 210)) continue
                    val channelTitle = snippet.optString("channelTitle", "YouTube")
                    val thumbs = snippet.optJSONObject("thumbnails")
                    val highThumb = thumbs?.optJSONObject("high")?.optString("url")
                        ?: "https://i.ytimg.com/vi/$videoId/hqdefault.jpg"

                    list.add(
                        SongEntity(
                            id = videoId,
                            title = cleanTitle(rawTitle),
                            artist = channelTitle,
                            album = "YouTube Music",
                            genre = "YouTube",
                            durationSeconds = 210,
                            audioUrl = "https://www.youtube.com/watch?v=$videoId",
                            coverUrl = highThumb,
                            isDownloaded = false,
                            localFilePath = null,
                            isFavorite = false,
                            playCount = 0
                        )
                    )
                }
                return list
            }
        } catch (e: Exception) {
            Log.w(TAG, "YouTube Data API search failed: ${e.message}")
        }
        return emptyList()
    }

    private fun searchDirectYouTube(query: String): List<SongEntity> {
        try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val searchUrl = "https://www.youtube.com/results?search_query=$encoded"
            val conn = URL(searchUrl).openConnection() as HttpURLConnection
            conn.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            )
            conn.connectTimeout = 7000
            conn.readTimeout = 7000

            if (conn.responseCode == 200) {
                val html = conn.inputStream.bufferedReader().use { it.readText() }
                val pattern = Pattern.compile("ytInitialData\\s*=\\s*(\\{.+?\\});<\\/script>")
                val matcher = pattern.matcher(html)
                if (matcher.find()) {
                    val jsonStr = matcher.group(1) ?: return emptyList()
                    val root = JSONObject(jsonStr)
                    val contents = root.optJSONObject("contents")
                        ?.optJSONObject("twoColumnSearchResultsRenderer")
                        ?.optJSONObject("primaryContents")
                        ?.optJSONObject("sectionListRenderer")
                        ?.optJSONArray("contents") ?: return emptyList()

                    val resultList = mutableListOf<SongEntity>()

                    for (i in 0 until contents.length()) {
                        val section = contents.optJSONObject(i) ?: continue
                        val itemSection = section.optJSONObject("itemSectionRenderer") ?: continue
                        val items = itemSection.optJSONArray("contents") ?: continue

                        for (j in 0 until items.length()) {
                            val item = items.optJSONObject(j) ?: continue
                            val videoRenderer = item.optJSONObject("videoRenderer") ?: continue
                            val videoId = videoRenderer.optString("videoId")
                            if (videoId.isNullOrBlank()) continue

                            val title = videoRenderer.optJSONObject("title")
                                ?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: "Canción"
                            val channel = videoRenderer.optJSONObject("ownerText")
                                ?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: "YouTube"

                            val lengthText = videoRenderer.optJSONObject("lengthText")?.optString("simpleText") ?: "3:30"
                            val durationSec = parseDurationToSeconds(lengthText)

                            if (isLikelyLongMixOrAlbum(title, durationSec)) {
                                continue
                            }

                            resultList.add(
                                SongEntity(
                                    id = videoId,
                                    title = cleanTitle(title),
                                    artist = channel,
                                    album = "YouTube Music",
                                    genre = "YouTube",
                                    durationSeconds = durationSec,
                                    audioUrl = "https://www.youtube.com/watch?v=$videoId",
                                    coverUrl = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg",
                                    isDownloaded = false,
                                    localFilePath = null,
                                    isFavorite = false,
                                    playCount = 0
                                )
                            )

                            if (resultList.size >= 15) break
                        }
                        if (resultList.isNotEmpty()) break
                    }

                    if (resultList.isNotEmpty()) {
                        return resultList
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Direct YouTube search failed: ${e.message}")
        }
        return emptyList()
    }

    private fun isLikelyLongMixOrAlbum(title: String, durationSec: Int): Boolean {
        // Enforce true single-song length (~2 to 6 minutes)
        if (durationSec > 390 || durationSec < 60) return true
        val lower = title.lowercase()
        val mixKeywords = listOf(
            "1 hora", "1 hour", "1hr", "2 horas", "2 hours", "3 horas", "10 horas",
            "mix", "completo", "full album", "álbum completo", "album completo",
            "disco completo", "enganchado", "compilation", "sesion", "sesión",
            "todos los exitos", "grandes exitos", "top canciones"
        )
        return mixKeywords.any { lower.contains(it) }
    }

    private fun searchSuggestQueries(query: String): List<SongEntity> {
        try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&q=$encoded"
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            conn.connectTimeout = 4000
            conn.readTimeout = 4000

            if (conn.responseCode == 200) {
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                val array = JSONArray(text)
                if (array.length() > 1) {
                    val suggestions = array.optJSONArray(1) ?: return emptyList()
                    val list = mutableListOf<SongEntity>()
                    for (i in 0 until suggestions.length().coerceAtMost(8)) {
                        val title = suggestions.optString(i)
                        list.add(
                            SongEntity(
                                id = "suggest_${System.currentTimeMillis()}_$i",
                                title = title,
                                artist = "Buscar en YouTube",
                                album = "YouTube Suggest",
                                genre = "YouTube",
                                durationSeconds = 180,
                                audioUrl = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(title, "UTF-8"),
                                coverUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80",
                                isDownloaded = false,
                                localFilePath = null,
                                isFavorite = false,
                                playCount = 0
                            )
                        )
                    }
                    return list
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Suggest search failed: ${e.message}")
        }
        return emptyList()
    }

    private fun cleanTitle(title: String): String {
        return title
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
    }

    private fun parseDurationToSeconds(text: String): Int {
        val parts = text.split(":")
        return when (parts.size) {
            2 -> (parts[0].toIntOrNull() ?: 0) * 60 + (parts[1].toIntOrNull() ?: 0)
            3 -> (parts[0].toIntOrNull() ?: 0) * 3600 + (parts[1].toIntOrNull() ?: 0) * 60 + (parts[2].toIntOrNull() ?: 0)
            else -> 210
        }
    }
}
