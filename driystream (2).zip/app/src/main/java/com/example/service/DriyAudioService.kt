package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.os.IBinder
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import coil.ImageLoader
import coil.request.ImageRequest
import com.example.MainActivity
import com.example.R
import com.example.data.model.SongEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DriyAudioService : Service() {
    private var mediaSession: MediaSessionCompat? = null
    private var currentSongTitle: String = "DriyStream"
    private var currentArtist: String = "Reproduciendo"
    private var currentAlbum: String = "DriyStream Music"
    private var currentCoverUrl: String? = null
    private var currentCoverBitmap: Bitmap? = null
    private var currentDurationMs: Long = 0L
    private var currentPositionMs: Long = 0L
    private var isPlaying: Boolean = false

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    companion object {
        const val CHANNEL_ID = "driystream_playback_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_PLAY = "com.example.ACTION_PLAY"
        const val ACTION_PAUSE = "com.example.ACTION_PAUSE"
        const val ACTION_NEXT = "com.example.ACTION_NEXT"
        const val ACTION_PREV = "com.example.ACTION_PREV"
        const val ACTION_UPDATE_PLAYBACK = "com.example.ACTION_UPDATE_PLAYBACK"
        const val ACTION_START = "com.example.ACTION_START"
        const val ACTION_STOP = "com.example.ACTION_STOP"

        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_ARTIST = "extra_artist"
        const val EXTRA_ALBUM = "extra_album"
        const val EXTRA_COVER_URL = "extra_cover_url"
        const val EXTRA_DURATION = "extra_duration"
        const val EXTRA_POSITION = "extra_position"
        const val EXTRA_IS_PLAYING = "extra_is_playing"

        fun startService(context: Context, song: SongEntity) {
            val intent = Intent(context, DriyAudioService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_TITLE, song.title)
                putExtra(EXTRA_ARTIST, song.artist)
                putExtra(EXTRA_ALBUM, song.album)
                putExtra(EXTRA_COVER_URL, song.coverUrl)
                putExtra(EXTRA_DURATION, song.durationSeconds * 1000L)
                putExtra(EXTRA_POSITION, 0L)
                putExtra(EXTRA_IS_PLAYING, true)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun updatePlayback(context: Context, isPlaying: Boolean, positionMs: Long = 0L, durationMs: Long = 0L) {
            val intent = Intent(context, DriyAudioService::class.java).apply {
                action = ACTION_UPDATE_PLAYBACK
                putExtra(EXTRA_IS_PLAYING, isPlaying)
                if (positionMs > 0) putExtra(EXTRA_POSITION, positionMs)
                if (durationMs > 0) putExtra(EXTRA_DURATION, durationMs)
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        initMediaSession()
    }

    private fun initMediaSession() {
        mediaSession = MediaSessionCompat(this, "DriyStreamMediaSession").apply {
            setFlags(
                MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or
                MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS
            )
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() {
                    DriyAudioPlayer.togglePlayPause()
                }

                override fun onPause() {
                    DriyAudioPlayer.togglePlayPause()
                }

                override fun onSkipToNext() {
                    DriyAudioPlayer.playNext()
                }

                override fun onSkipToPrevious() {
                    DriyAudioPlayer.playPrevious()
                }

                override fun onSeekTo(pos: Long) {
                    DriyAudioPlayer.seekTo(pos)
                }

                override fun onStop() {
                    DriyAudioPlayer.stop()
                }
            })
            isActive = true
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            when (it.action) {
                ACTION_START -> {
                    currentSongTitle = it.getStringExtra(EXTRA_TITLE) ?: currentSongTitle
                    currentArtist = it.getStringExtra(EXTRA_ARTIST) ?: currentArtist
                    currentAlbum = it.getStringExtra(EXTRA_ALBUM) ?: currentAlbum
                    currentDurationMs = it.getLongExtra(EXTRA_DURATION, currentDurationMs)
                    currentPositionMs = it.getLongExtra(EXTRA_POSITION, 0L)
                    val newCoverUrl = it.getStringExtra(EXTRA_COVER_URL)
                    isPlaying = it.getBooleanExtra(EXTRA_IS_PLAYING, true)

                    if (newCoverUrl != currentCoverUrl) {
                        currentCoverUrl = newCoverUrl
                        loadArtworkAndRefresh(newCoverUrl)
                    }

                    updateMediaSessionState(isPlaying, currentPositionMs)
                    updateMediaSessionMetadata()
                    startInForeground()
                }
                ACTION_UPDATE_PLAYBACK -> {
                    isPlaying = it.getBooleanExtra(EXTRA_IS_PLAYING, isPlaying)
                    val pos = it.getLongExtra(EXTRA_POSITION, -1L)
                    if (pos >= 0) currentPositionMs = pos
                    val dur = it.getLongExtra(EXTRA_DURATION, -1L)
                    if (dur > 0) currentDurationMs = dur

                    updateMediaSessionState(isPlaying, currentPositionMs)
                    val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    notificationManager.notify(NOTIFICATION_ID, buildNotification())
                }
                ACTION_PLAY, ACTION_PAUSE -> {
                    DriyAudioPlayer.togglePlayPause()
                }
                ACTION_NEXT -> {
                    DriyAudioPlayer.playNext()
                }
                ACTION_PREV -> {
                    DriyAudioPlayer.playPrevious()
                }
                ACTION_STOP -> {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }
        return START_STICKY
    }

    private fun startInForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun loadArtworkAndRefresh(url: String?) {
        if (url.isNullOrBlank()) {
            currentCoverBitmap = null
            updateMediaSessionMetadata()
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, buildNotification())
            return
        }

        serviceScope.launch {
            val bitmap = withContext(Dispatchers.IO) {
                try {
                    val loader = ImageLoader(this@DriyAudioService)
                    val request = ImageRequest.Builder(this@DriyAudioService)
                        .data(url)
                        .allowHardware(false)
                        .build()
                    val result = loader.execute(request)
                    (result.drawable as? BitmapDrawable)?.bitmap
                } catch (e: Exception) {
                    null
                }
            }
            currentCoverBitmap = bitmap
            updateMediaSessionMetadata()
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, buildNotification())
        }
    }

    private fun updateMediaSessionState(playing: Boolean, position: Long) {
        val state = if (playing) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED
        val playbackState = PlaybackStateCompat.Builder()
            .setActions(
                PlaybackStateCompat.ACTION_PLAY or
                PlaybackStateCompat.ACTION_PAUSE or
                PlaybackStateCompat.ACTION_PLAY_PAUSE or
                PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
                PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or
                PlaybackStateCompat.ACTION_SEEK_TO or
                PlaybackStateCompat.ACTION_STOP
            )
            .setState(state, position, 1.0f)
            .build()
        mediaSession?.setPlaybackState(playbackState)
    }

    private fun updateMediaSessionMetadata() {
        val builder = MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, currentSongTitle)
            .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, currentArtist)
            .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, currentAlbum)
            .putString(MediaMetadataCompat.METADATA_KEY_DISPLAY_TITLE, currentSongTitle)
            .putString(MediaMetadataCompat.METADATA_KEY_DISPLAY_SUBTITLE, currentArtist)
            .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, currentDurationMs)

        currentCoverBitmap?.let { bmp ->
            builder.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, bmp)
            builder.putBitmap(MediaMetadataCompat.METADATA_KEY_ART, bmp)
            builder.putBitmap(MediaMetadataCompat.METADATA_KEY_DISPLAY_ICON, bmp)
        }

        mediaSession?.setMetadata(builder.build())
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val prevIntent = Intent(this, DriyAudioService::class.java).apply { action = ACTION_PREV }
        val prevPendingIntent = PendingIntent.getService(this, 1, prevIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val playPauseIntent = Intent(this, DriyAudioService::class.java).apply {
            action = if (isPlaying) ACTION_PAUSE else ACTION_PLAY
        }
        val playPausePendingIntent = PendingIntent.getService(this, 2, playPauseIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val nextIntent = Intent(this, DriyAudioService::class.java).apply { action = ACTION_NEXT }
        val nextPendingIntent = PendingIntent.getService(this, 3, nextIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val playPauseIcon = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play

        val sessionToken = mediaSession?.sessionToken

        val mediaStyle = androidx.media.app.NotificationCompat.MediaStyle()
            .setShowActionsInCompactView(0, 1, 2)
        if (sessionToken != null) {
            mediaStyle.setMediaSession(sessionToken)
        }

        val notificationBuilder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(currentSongTitle)
            .setContentText(currentArtist)
            .setSubText("DriyStream")
            .setContentIntent(contentPendingIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setOngoing(isPlaying)
            .setShowWhen(false)
            .addAction(android.R.drawable.ic_media_previous, "Anterior", prevPendingIntent)
            .addAction(playPauseIcon, if (isPlaying) "Pausar" else "Reproducir", playPausePendingIntent)
            .addAction(android.R.drawable.ic_media_next, "Siguiente", nextPendingIntent)
            .setStyle(mediaStyle)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            notificationBuilder.setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
        }

        currentCoverBitmap?.let { bmp ->
            notificationBuilder.setLargeIcon(bmp)
        }

        return notificationBuilder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "DriyStream Reproducción",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Controles de reproducción multimedia en segundo plano"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        mediaSession?.isActive = false
        mediaSession?.release()
        mediaSession = null
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
