package com.example.service

import android.content.Context
import android.os.Build
import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader

object DynamicIslandDetector {
    private const val TAG = "DynamicIslandDetector"

    /**
     * Checks if the device has a native dynamic island or notch capsule notification system
     * (e.g. Redmi / Xiaomi HyperOS Dynamic Island, Realme Mini Capsule, Honor Magic Capsule,
     * OnePlus / Oppo Aqua Dynamics, Tecno/Infinix Dynamic Port, or Android 13+ System Media Controls).
     */
    fun isNativeDynamicIslandPresent(context: Context): Boolean {
        try {
            val brand = Build.BRAND.lowercase()
            val manufacturer = Build.MANUFACTURER.lowercase()
            val model = Build.MODEL.lowercase()
            val device = Build.DEVICE.lowercase()
            val product = Build.PRODUCT.lowercase()

            // 1. Check known Xiaomi / Redmi / POCO devices with HyperOS dynamic island
            if (brand == "xiaomi" || brand == "redmi" || brand == "poco" || manufacturer == "xiaomi") {
                val miuiVersion = getSystemProperty("ro.miui.ui.version.name")
                val miuiIncremental = getSystemProperty("ro.build.version.incremental")
                val hasIsland = getSystemProperty("ro.miui.has_island") == "1" ||
                                getSystemProperty("sys.miui.island") == "true"
                if (hasIsland || miuiVersion.contains("hyper", ignoreCase = true) || miuiIncremental.contains("OS", ignoreCase = true)) {
                    Log.d(TAG, "HyperOS native dynamic island detected")
                    return true
                }
                if (model.contains("note 13") || model.contains("note 14") || model.contains("13 pro") || model.contains("14") || model.contains("k70") || model.contains("k60")) {
                    Log.d(TAG, "Xiaomi / Redmi model with native capsule: $model")
                    return true
                }
            }

            // 2. Check Realme Mini Capsule
            if (brand == "realme" || manufacturer == "realme") {
                val realmeCapsule = getSystemProperty("ro.realme.mini_capsule")
                val realmeUi = getSystemProperty("ro.build.version.realmeui")
                if (realmeCapsule == "1" || realmeCapsule == "true" || realmeUi.isNotEmpty()) {
                    Log.d(TAG, "Realme Mini Capsule detected")
                    return true
                }
                return true
            }

            // 3. Check Honor MagicOS Smart Capsule
            if (brand == "honor" || manufacturer == "honor") {
                return true
            }

            // 4. Check OnePlus / OPPO Aqua Dynamics / Live Alerts
            if (brand == "oneplus" || brand == "oppo" || manufacturer == "oneplus" || manufacturer == "oppo") {
                val colorOs = getSystemProperty("ro.build.version.opporom")
                if (colorOs.isNotEmpty() || Build.VERSION.SDK_INT >= 34) {
                    return true
                }
            }

            // 5. Check Tecno / Infinix / Itel Dynamic Port
            if (brand == "tecno" || brand == "infinix" || brand == "itel") {
                return true
            }

            // 6. Generic check for native live activity / capsule property
            val genericCapsule = getSystemProperty("sys.systemui.dynamic_island")
            if (genericCapsule == "1" || genericCapsule == "true") {
                return true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking native dynamic island", e)
        }
        return false
    }

    private fun getSystemProperty(propName: String): String {
        return try {
            val process = Runtime.getRuntime().exec("getprop $propName")
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val line = reader.readLine() ?: ""
            reader.close()
            process.destroy()
            line.trim()
        } catch (e: Exception) {
            ""
        }
    }
}
