package com.example.service

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.data.model.SongEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.sin

data class PlayerState(
    val currentSong: SongEntity? = null,
    val isPlaying: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isBuffering: Boolean = false,
    val isShuffle: Boolean = false,
    val isRepeat: Boolean = false,
    val queue: List<SongEntity> = emptyList(),
    val isNativeIslandDetected: Boolean = false,
    val isOverlayPermitted: Boolean = false
)

object DriyAudioPlayer {
    private const val TAG = "DriyAudioPlayer"

    private var mediaPlayer: MediaPlayer? = null
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private val handler = Handler(Looper.getMainLooper())

    private val _playerState = MutableStateFlow(PlayerState())
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()

    private var appContext: Context? = null
    private var isAppForeground: Boolean = true

    // Runnable to tick current playback position
    private val progressRunnable = object : Runnable {
        override fun run() {
            val player = mediaPlayer
            val currentSong = _playerState.value.currentSong
            if (player != null) {
                try {
                    if (player.isPlaying) {
                        val duration = player.duration.toLong().takeIf { it > 0 } ?: _playerState.value.durationMs
                        _playerState.value = _playerState.value.copy(
                            currentPositionMs = player.currentPosition.toLong(),
                            durationMs = duration
                        )
                    }
                } catch (e: Exception) {
                    // Ignore transient state
                }
            } else if (currentSong?.genre == "YouTube") {
                if (_playerState.value.isPlaying) {
                    val newPos = (_playerState.value.currentPositionMs + 500L).coerceAtMost(_playerState.value.durationMs)
                    _playerState.value = _playerState.value.copy(currentPositionMs = newPos)
                    if (newPos >= _playerState.value.durationMs && _playerState.value.durationMs > 0) {
                        playNext()
                        return
                    }
                }
            }
            if (_playerState.value.isPlaying) {
                handler.postDelayed(this, 500)
            }
        }
    }

    fun isNetworkAvailable(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val activeNetwork = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun init(context: Context) {
        appContext = context.applicationContext
        YouTubeAudioPlayer.init(context)
        val hasNative = DynamicIslandDetector.isNativeDynamicIslandPresent(context)
        _playerState.value = _playerState.value.copy(isNativeIslandDetected = hasNative)
    }

    fun setAppForegroundState(isForeground: Boolean) {
        isAppForeground = isForeground
        appContext?.let { ctx ->
            updateOverlayService(ctx)
        }
    }

    fun isAppInForeground(): Boolean = isAppForeground

    fun playSong(song: SongEntity, newQueue: List<SongEntity> = emptyList()) {
        val ctx = appContext ?: return
        val queue = if (newQueue.isNotEmpty()) newQueue else {
            if (_playerState.value.queue.none { it.id == song.id }) {
                _playerState.value.queue + song
            } else {
                _playerState.value.queue
            }
        }

        stopSynthesizer()
        releasePlayer()

        // Ensure media audio volume is unmuted and audible
        val audioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
        audioManager?.let { am ->
            try {
                val currentVol = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                if (currentVol == 0) {
                    val maxVol = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                    am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (maxVol * 0.8).toInt(), 0)
                }
            } catch (e: Exception) {
                // ignore
            }
        }

        // 1. YouTube tracks: ALWAYS stream the REAL song via YouTubeAudioPlayer!
        // Whether downloaded, favorite, or in a playlist, play the authentic artist song.
        if (song.genre == "YouTube" || song.audioUrl.contains("youtube.com") || song.audioUrl.contains("youtu.be")) {
            val videoId = if (song.audioUrl.contains("v=")) {
                song.audioUrl.substringAfter("v=").substringBefore("&").substringBefore("?")
            } else if (song.audioUrl.contains("youtu.be/")) {
                song.audioUrl.substringAfter("youtu.be/").substringBefore("?").substringBefore("&")
            } else {
                song.id
            }
            YouTubeAudioPlayer.play(videoId)
            _playerState.value = _playerState.value.copy(
                currentSong = song,
                isPlaying = true,
                isBuffering = false,
                currentPositionMs = 0L,
                durationMs = song.durationSeconds * 1000L,
                queue = queue
            )
            DriyAudioService.startService(ctx, song)
            handler.post(progressRunnable)
            updateOverlayService(ctx)
            return
        }

        // 2. Direct audio tracks: check for local real MP3 or remote stream
        val localFile = song.localFilePath?.let { File(it) }
        val hasRealLocalAudio = song.isDownloaded && localFile != null && localFile.exists() && localFile.length() > 5000

        YouTubeAudioPlayer.stop()

        _playerState.value = _playerState.value.copy(
            currentSong = song,
            isPlaying = true,
            isBuffering = true,
            currentPositionMs = 0L,
            durationMs = song.durationSeconds * 1000L,
            queue = queue
        )

        DriyAudioService.startService(ctx, song)

        try {
            val sourceUri = if (hasRealLocalAudio) {
                Uri.fromFile(localFile)
            } else {
                Uri.parse(song.audioUrl)
            }

            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(ctx, sourceUri)
                setOnPreparedListener { mp ->
                    mp.start()
                    _playerState.value = _playerState.value.copy(
                        isPlaying = true,
                        isBuffering = false,
                        durationMs = mp.duration.toLong().takeIf { it > 0 } ?: (song.durationSeconds * 1000L)
                    )
                    handler.post(progressRunnable)
                    updateOverlayService(ctx)
                }
                setOnCompletionListener {
                    onSongCompleted()
                }
                setOnErrorListener { _, what, extra ->
                    Log.w(TAG, "MediaPlayer error ($what, $extra)")
                    _playerState.value = _playerState.value.copy(isPlaying = false, isBuffering = false)
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize media player: ${e.message}", e)
            _playerState.value = _playerState.value.copy(isPlaying = false, isBuffering = false)
        }
    }

    fun togglePlayPause() {
        val ctx = appContext ?: return
        val currentSong = _playerState.value.currentSong ?: return
        val isCurrentlyPlaying = _playerState.value.isPlaying

        // Prioritize native mediaPlayer if active (offline downloaded songs or direct streams)
        if (mediaPlayer != null) {
            mediaPlayer?.let { player ->
                if (isCurrentlyPlaying) {
                    player.pause()
                    _playerState.value = _playerState.value.copy(isPlaying = false)
                    handler.removeCallbacks(progressRunnable)
                } else {
                    player.start()
                    _playerState.value = _playerState.value.copy(isPlaying = true)
                    handler.post(progressRunnable)
                }
            }
            DriyAudioService.updatePlayback(ctx, _playerState.value.isPlaying, _playerState.value.currentPositionMs, _playerState.value.durationMs)
            updateOverlayService(ctx)
            return
        }

        if (currentSong.genre == "YouTube" || currentSong.audioUrl.contains("youtube")) {
            if (isCurrentlyPlaying) {
                YouTubeAudioPlayer.pause()
                _playerState.value = _playerState.value.copy(isPlaying = false)
                handler.removeCallbacks(progressRunnable)
            } else {
                YouTubeAudioPlayer.resume()
                _playerState.value = _playerState.value.copy(isPlaying = true)
                handler.post(progressRunnable)
            }
            DriyAudioService.updatePlayback(ctx, _playerState.value.isPlaying, _playerState.value.currentPositionMs, _playerState.value.durationMs)
            updateOverlayService(ctx)
            return
        }

        if (isCurrentlyPlaying) {
            _playerState.value = _playerState.value.copy(isPlaying = false)
            handler.removeCallbacks(progressRunnable)
        } else {
            playSong(currentSong)
            return
        }

        DriyAudioService.updatePlayback(ctx, _playerState.value.isPlaying, _playerState.value.currentPositionMs, _playerState.value.durationMs)
        updateOverlayService(ctx)
    }

    fun setCustomIslandMode(mode: String) {
        val ctx = appContext ?: return
        val prefs = ctx.getSharedPreferences("driystream_audio_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("island_mode", mode).apply()
        updateOverlayService(ctx)
    }

    fun getCustomIslandMode(): String {
        val ctx = appContext ?: return "AUTO"
        val prefs = ctx.getSharedPreferences("driystream_audio_prefs", Context.MODE_PRIVATE)
        return prefs.getString("island_mode", "AUTO") ?: "AUTO"
    }

    fun seekTo(positionMs: Long) {
        val currentSong = _playerState.value.currentSong
        val ctx = appContext
        if (mediaPlayer != null) {
            try {
                mediaPlayer?.seekTo(positionMs.toInt())
            } catch (e: Exception) {
                Log.e(TAG, "Seek error", e)
            }
            _playerState.value = _playerState.value.copy(currentPositionMs = positionMs)
            ctx?.let { DriyAudioService.updatePlayback(it, _playerState.value.isPlaying, positionMs, _playerState.value.durationMs) }
            return
        }

        if (currentSong?.genre == "YouTube" || currentSong?.audioUrl?.contains("youtube") == true) {
            YouTubeAudioPlayer.seekTo(positionMs / 1000f)
            _playerState.value = _playerState.value.copy(currentPositionMs = positionMs)
            ctx?.let { DriyAudioService.updatePlayback(it, _playerState.value.isPlaying, positionMs, _playerState.value.durationMs) }
            return
        }

        _playerState.value = _playerState.value.copy(currentPositionMs = positionMs)
        ctx?.let { DriyAudioService.updatePlayback(it, _playerState.value.isPlaying, positionMs, _playerState.value.durationMs) }
    }

    private val playerScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var isFetchingSimilar = false

    private val similarArtistsMap = mapOf(
        "two feet" to listOf("The Weeknd", "Chase Atlantic", "Arctic Monkeys", "Dennis Lloyd", "The Neighbourhood", "grandson"),
        "the weeknd" to listOf("Two Feet", "Dua Lipa", "Post Malone", "Joji", "Bruno Mars", "Chase Atlantic"),
        "arctic monkeys" to listOf("Two Feet", "The Strokes", "The Neighbourhood", "Cage The Elephant", "Franz Ferdinand"),
        "chase atlantic" to listOf("The Neighbourhood", "Two Feet", "Arctic Monkeys", "Lil Peep"),
        "the neighbourhood" to listOf("Two Feet", "Chase Atlantic", "Arctic Monkeys", "Lorde"),
        "bad bunny" to listOf("Feid", "Rauw Alejandro", "Karol G", "Jhayco", "Myke Towers", "Mora"),
        "feid" to listOf("Bad Bunny", "Ryan Castro", "Blessd", "Karol G", "Young Miko"),
        "karol g" to listOf("Shakira", "Becky G", "Natti Natasha", "Feid", "Bad Bunny"),
        "dua lipa" to listOf("The Weeknd", "Miley Cyrus", "Doja Cat", "Olivia Rodrigo", "Taylor Swift"),
        "taylor swift" to listOf("Olivia Rodrigo", "Sabrina Carpenter", "Lana Del Rey", "Gracie Abrams"),
        "billie eilish" to listOf("Lorde", "Lana Del Rey", "Girl in Red", "Finneas", "The Neighbourhood"),
        "imagine dragons" to listOf("OneRepublic", "Coldplay", "Fall Out Boy", "The Script"),
        "coldplay" to listOf("Imagine Dragons", "Keane", "The Killers", "U2"),
        "drake" to listOf("Travis Scott", "Kendrick Lamar", "21 Savage", "The Weeknd", "Future"),
        "travis scott" to listOf("Drake", "Kendrick Lamar", "Don Toliver", "Playboi Carti"),
        "kendrick lamar" to listOf("J. Cole", "Drake", "Travis Scott", "Tyler, the Creator"),
        "avicii" to listOf("Calvin Harris", "Kygo", "David Guetta", "Alesso", "Martin Garrix"),
        "calvin harris" to listOf("Avicii", "David Guetta", "Alesso", "Swedish House Mafia"),
        "daft punk" to listOf("Justice", "The Chemical Brothers", "Deadmau5", "Empire of the Sun"),
        "bruno mars" to listOf("The Weeknd", "Silk Sonic", "Anderson .Paak", "Michael Jackson")
    )

    fun onSongCompleted() {
        val state = _playerState.value
        val currentSong = state.currentSong
        if (state.isRepeat && currentSong != null) {
            playSong(currentSong, state.queue)
            return
        }

        val queue = state.queue
        val currentIndex = queue.indexOfFirst { it.id == currentSong?.id }

        // If there's a next song in the active queue, play it
        if (currentIndex in 0 until queue.size - 1) {
            val nextSong = queue[currentIndex + 1]
            playSong(nextSong, queue)
            return
        }

        // If queue reached the end (or single track played from search),
        // trigger Smart Autoplay with real similar songs from the internet!
        if (currentSong != null) {
            triggerDynamicAutoplay(currentSong)
        } else {
            playNext()
        }
    }

    fun playNext() {
        val state = _playerState.value
        val queue = state.queue
        val currentSong = state.currentSong

        if (queue.isEmpty() && currentSong != null) {
            triggerDynamicAutoplay(currentSong)
            return
        }
        if (queue.isEmpty()) return

        val currentIndex = queue.indexOfFirst { it.id == currentSong?.id }
        if (state.isShuffle) {
            val nextIndex = queue.indices.random()
            playSong(queue[nextIndex], queue)
        } else if (currentIndex in 0 until queue.size - 1) {
            playSong(queue[currentIndex + 1], queue)
        } else if (currentSong != null) {
            // End of queue: discover and continue playing similar songs
            triggerDynamicAutoplay(currentSong)
        } else {
            playSong(queue.first(), queue)
        }
    }

    fun triggerDynamicAutoplay(finishedSong: SongEntity) {
        if (isFetchingSimilar) return
        isFetchingSimilar = true
        _playerState.value = _playerState.value.copy(isBuffering = true)

        playerScope.launch {
            try {
                val similarSongs = findSimilarSongsOnline(finishedSong)
                val currentQueueIds = _playerState.value.queue.map { it.id }.toSet()
                val freshSongs = similarSongs.filter { it.id != finishedSong.id && !currentQueueIds.contains(it.id) }

                val songToPlay = when {
                    freshSongs.isNotEmpty() -> freshSongs.first()
                    similarSongs.isNotEmpty() -> similarSongs.firstOrNull { it.id != finishedSong.id } ?: similarSongs.first()
                    else -> null
                }

                if (songToPlay != null) {
                    val appendList = if (freshSongs.isNotEmpty()) freshSongs else similarSongs
                    val updatedQueue = (_playerState.value.queue + appendList).distinctBy { it.id }
                    playSong(songToPlay, updatedQueue)
                } else {
                    val q = _playerState.value.queue
                    if (q.isNotEmpty()) playSong(q.first(), q)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Autoplay recommendation error: ${e.message}")
            } finally {
                isFetchingSimilar = false
                _playerState.value = _playerState.value.copy(isBuffering = false)
            }
        }
    }

    private suspend fun findSimilarSongsOnline(song: SongEntity): List<SongEntity> = withContext(Dispatchers.IO) {
        val artistLower = song.artist.trim().lowercase()
        val titleClean = song.title.trim()

        var relatedList: List<String> = emptyList()
        for ((key, list) in similarArtistsMap) {
            if (artistLower.contains(key) || key.contains(artistLower)) {
                relatedList = list
                break
            }
        }

        val queries = mutableListOf<String>()
        if (relatedList.isNotEmpty()) {
            val pickedArtist = relatedList.random()
            queries.add("$pickedArtist audio")
            queries.add("$pickedArtist popular")
        }
        queries.add("${song.artist} audio")
        queries.add("$titleClean audio")
        queries.add("${song.artist} radio")

        for (q in queries) {
            try {
                val results = YouTubeService.searchYouTube(q)
                    .filter { it.id != song.id && it.durationSeconds in 60..480 }
                if (results.isNotEmpty()) {
                    return@withContext results.take(6)
                }
            } catch (e: Exception) {
                // continue to next query
            }
        }
        emptyList()
    }

    fun playPrevious() {
        val state = _playerState.value
        val queue = state.queue
        if (queue.isEmpty()) return

        val currentIndex = queue.indexOfFirst { it.id == state.currentSong?.id }
        val prevIndex = if (currentIndex <= 0) queue.size - 1 else currentIndex - 1
        playSong(queue[prevIndex], queue)
    }

    fun toggleShuffle() {
        _playerState.value = _playerState.value.copy(isShuffle = !_playerState.value.isShuffle)
    }

    fun toggleRepeat() {
        _playerState.value = _playerState.value.copy(isRepeat = !_playerState.value.isRepeat)
    }

    fun addToQueueNext(song: SongEntity) {
        val state = _playerState.value
        val currentSong = state.currentSong
        if (currentSong == null) {
            playSong(song, listOf(song))
            return
        }

        val queue = state.queue.toMutableList()
        queue.removeAll { it.id == song.id }

        val currentIndex = queue.indexOfFirst { it.id == currentSong.id }
        val insertIndex = if (currentIndex >= 0) currentIndex + 1 else 0
        queue.add(insertIndex.coerceAtMost(queue.size), song)

        _playerState.value = _playerState.value.copy(queue = queue)
    }

    fun addToQueueEnd(song: SongEntity) {
        val state = _playerState.value
        if (state.currentSong == null) {
            playSong(song, listOf(song))
            return
        }
        val queue = state.queue.toMutableList()
        queue.removeAll { it.id == song.id }
        queue.add(song)
        _playerState.value = _playerState.value.copy(queue = queue)
    }

    fun removeFromQueue(songId: String) {
        val state = _playerState.value
        val queue = state.queue.filter { it.id != songId }
        _playerState.value = _playerState.value.copy(queue = queue)
    }

    fun clearQueue() {
        val state = _playerState.value
        val current = state.currentSong
        _playerState.value = _playerState.value.copy(queue = if (current != null) listOf(current) else emptyList())
    }

    fun stop() {
        val ctx = appContext
        stopSynthesizer()
        releasePlayer()
        YouTubeAudioPlayer.stop()
        _playerState.value = _playerState.value.copy(isPlaying = false, currentPositionMs = 0L)
        ctx?.let {
            DriyAudioService.updatePlayback(it, false, 0L, _playerState.value.durationMs)
            updateOverlayService(it)
        }
    }

    private fun updateOverlayService(context: Context) {
        val state = _playerState.value
        val song = state.currentSong
        val mode = getCustomIslandMode()

        val shouldShowOverlay = when (mode) {
            "FORCE_OVERLAY" -> song != null && !isAppForeground
            "FORCE_NATIVE" -> false
            "DISABLED" -> false
            else -> song != null && !isAppForeground && !state.isNativeIslandDetected // AUTO
        }

        if (shouldShowOverlay) {
            DynamicIslandService.show(context, song?.title ?: "", song?.artist ?: "", state.isPlaying)
        } else {
            DynamicIslandService.hide(context)
        }
    }

    private fun releasePlayer() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            // ignore
        }
        mediaPlayer = null
        handler.removeCallbacks(progressRunnable)
    }

    private fun stopSynthesizer() {
        // Synthesizer removed to guarantee only authentic songs play
    }
}
