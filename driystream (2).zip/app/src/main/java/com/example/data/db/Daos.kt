package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.FolderEntity
import com.example.data.model.FolderSongCrossRef
import com.example.data.model.SongEntity
import com.example.data.model.UploadedSongEntity
import com.example.data.model.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users LIMIT 1")
    fun getActiveUserFlow(): Flow<UserEntity?>

    @Query("SELECT * FROM users LIMIT 1")
    suspend fun getActiveUser(): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET favoriteGenres = :genres WHERE id = :userId")
    suspend fun updateFavoriteGenres(userId: String, genres: List<String>)

    @Query("UPDATE users SET favoriteArtists = :artists, isOnboarded = :isOnboarded WHERE id = :userId")
    suspend fun updateFavoriteArtistsAndOnboarding(userId: String, artists: List<String>, isOnboarded: Boolean)

    @Query("UPDATE users SET displayName = :displayName WHERE id = :userId")
    suspend fun updateDisplayName(userId: String, displayName: String)

    @Query("UPDATE users SET photoUrl = :photoUrl WHERE id = :userId")
    suspend fun updatePhotoUrl(userId: String, photoUrl: String)

    @Query("SELECT * FROM users WHERE LOWER(username) = LOWER(:username) LIMIT 1")
    suspend fun getUserByUsername(username: String): UserEntity?

    @Query("SELECT * FROM users WHERE phoneNumber = :phoneNumber LIMIT 1")
    suspend fun getUserByPhoneNumber(phoneNumber: String): UserEntity?

    @Query("SELECT * FROM users WHERE (LOWER(username) = LOWER(:identifier) OR phoneNumber = :identifier) LIMIT 1")
    suspend fun findUserByIdentifier(identifier: String): UserEntity?

    @Query("SELECT * FROM users")
    suspend fun getAllRegisteredUsers(): List<UserEntity>

    @Query("DELETE FROM users")
    suspend fun clearAllUsers()
}

@Dao
interface SongDao {
    @Query("SELECT * FROM songs")
    fun getAllSongs(): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE isFavorite = 1 ORDER BY title ASC")
    fun getFavoriteSongs(): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE isDownloaded = 1 ORDER BY title ASC")
    fun getDownloadedSongs(): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE genre = :genre")
    fun getSongsByGenre(genre: String): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE artist IN (:artists)")
    fun getSongsByArtists(artists: List<String>): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE title LIKE '%' || :query || '%' OR artist LIKE '%' || :query || '%' OR genre LIKE '%' || :query || '%'")
    fun searchSongs(query: String): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE id = :id LIMIT 1")
    suspend fun getSongById(id: String): SongEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSongs(songs: List<SongEntity>)

    @Query("DELETE FROM songs WHERE audioUrl LIKE '%soundhelix%'")
    suspend fun deleteSoundHelixSongs()

    @Update
    suspend fun updateSong(song: SongEntity)

    @Query("UPDATE songs SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavorite(id: String, isFavorite: Boolean)

    @Query("UPDATE songs SET isDownloaded = :isDownloaded, localFilePath = :localPath WHERE id = :id")
    suspend fun updateDownloadStatus(id: String, isDownloaded: Boolean, localPath: String?)

    @Query("UPDATE songs SET playCount = playCount + 1, lastPlayedAt = :timestamp WHERE id = :id")
    suspend fun recordPlay(id: String, timestamp: Long)

    @Query("SELECT COUNT(*) FROM songs")
    suspend fun getSongCount(): Int
}

@Dao
interface FolderDao {
    @Query("SELECT * FROM folders ORDER BY isDefault DESC, createdAt ASC")
    fun getAllFolders(): Flow<List<FolderEntity>>

    @Query("SELECT * FROM folders WHERE id = :id LIMIT 1")
    suspend fun getFolderById(id: String): FolderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolder(folder: FolderEntity)

    @Query("UPDATE folders SET name = :newName WHERE id = :folderId")
    suspend fun updateFolderName(folderId: String, newName: String)

    @Query("DELETE FROM folders WHERE id = :folderId AND isDefault = 0")
    suspend fun deleteFolder(folderId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addSongToFolder(crossRef: FolderSongCrossRef)

    @Query("DELETE FROM folder_songs WHERE folderId = :folderId AND songId = :songId")
    suspend fun removeSongFromFolder(folderId: String, songId: String)

    @Query("DELETE FROM folder_songs WHERE folderId = :folderId")
    suspend fun deleteSongsInFolder(folderId: String)

    @Query("SELECT s.* FROM songs s INNER JOIN folder_songs fs ON s.id = fs.songId WHERE fs.folderId = :folderId ORDER BY fs.addedAt DESC")
    fun getSongsInFolder(folderId: String): Flow<List<SongEntity>>

    @Query("SELECT folderId FROM folder_songs WHERE songId = :songId")
    fun getFolderIdsForSong(songId: String): Flow<List<String>>

    @Query("SELECT folderId FROM folder_songs WHERE songId = :songId")
    suspend fun getFolderIdsForSongOnce(songId: String): List<String>

    @Query("SELECT COUNT(*) FROM folder_songs WHERE folderId = :folderId")
    suspend fun getSongCountInFolder(folderId: String): Int

    @Query("SELECT s.coverUrl FROM songs s INNER JOIN folder_songs fs ON s.id = fs.songId WHERE fs.folderId = :folderId ORDER BY fs.addedAt DESC LIMIT 1")
    suspend fun getLatestSongCoverInFolder(folderId: String): String?
}

@Dao
interface UploadedSongDao {
    @Query("SELECT * FROM uploaded_songs ORDER BY createdAt DESC")
    fun getAllUploadedSongs(): Flow<List<UploadedSongEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUploadedSong(song: UploadedSongEntity)

    @Delete
    suspend fun deleteUploadedSong(song: UploadedSongEntity)

    @Query("DELETE FROM uploaded_songs WHERE id = :id")
    suspend fun deleteUploadedSongById(id: String)
}
