package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.db.DriyDatabase
import com.example.data.model.UserEntity
import com.example.service.FirebaseUserManager
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class UserRepository(private val context: Context) {
    private val database = DriyDatabase.getInstance(context)
    private val userDao = database.userDao()
    private val firebaseUserManager = FirebaseUserManager(context)
    private val prefs: SharedPreferences = context.getSharedPreferences("driystream_auth_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_ACTIVE_USER_ID = "active_user_id"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
    }

    val activeUserFlow: Flow<UserEntity?> = userDao.getActiveUserFlow()

    suspend fun getActiveUser(): UserEntity? = withContext(Dispatchers.IO) {
        val currentUserId = prefs.getString(KEY_ACTIVE_USER_ID, null)
        if (currentUserId != null) {
            userDao.getUserById(currentUserId)
                ?: userDao.getUserByUsername(currentUserId)
                ?: userDao.getActiveUser()
        } else {
            userDao.getActiveUser()
        }
    }

    fun isUserLoggedIn(): Boolean {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    }

    /**
     * Checks if a username is already taken in Firebase Firestore or locally
     */
    suspend fun isUsernameTaken(username: String): Boolean = withContext(Dispatchers.IO) {
        firebaseUserManager.isUsernameTaken(username)
    }

    /**
     * Checks if a phone number is already registered
     */
    suspend fun isPhoneRegistered(phoneNumber: String): Boolean = withContext(Dispatchers.IO) {
        firebaseUserManager.findExistingAccount("", phoneNumber) != null
    }

    /**
     * Looks up an existing account by username or phone number in Firebase Firestore and Room
     */
    suspend fun findExistingAccount(username: String, phoneNumber: String): UserEntity? = withContext(Dispatchers.IO) {
        firebaseUserManager.findExistingAccount(username, phoneNumber)
    }

    /**
     * Registers a new user with name, username, password and phone number in Firebase Firestore and Room
     */
    suspend fun registerUserWithPhone(
        firstName: String,
        lastName: String,
        username: String,
        password: String,
        phoneNumber: String
    ): UserEntity = withContext(Dispatchers.IO) {
        firebaseUserManager.registerUser(
            firstName = firstName,
            lastName = lastName,
            username = username,
            password = password,
            phoneNumber = phoneNumber
        )
    }

    /**
     * Logs in using username, password, and phone number against Firebase Firestore and Room
     */
    suspend fun loginWithUserAndPhone(
        username: String,
        password: String,
        phoneNumber: String
    ): Result<UserEntity> = withContext(Dispatchers.IO) {
        firebaseUserManager.loginUser(
            username = username,
            password = password,
            phoneNumber = phoneNumber
        )
    }

    suspend fun saveSelectedGenres(userId: String, genres: List<String>) = withContext(Dispatchers.IO) {
        userDao.updateFavoriteGenres(userId, genres)
        try {
            FirebaseFirestore.getInstance().collection("driystream_users")
                .document(userId)
                .update("favoriteGenres", genres)
                .await()
        } catch (e: Exception) {
            // offline fallback
        }
    }

    suspend fun completeOnboarding(userId: String, artists: List<String>) = withContext(Dispatchers.IO) {
        userDao.updateFavoriteArtistsAndOnboarding(userId, artists, isOnboarded = true)
        try {
            FirebaseFirestore.getInstance().collection("driystream_users")
                .document(userId)
                .update(mapOf("favoriteArtists" to artists, "isOnboarded" to true))
                .await()
        } catch (e: Exception) {
            // offline fallback
        }
    }

    suspend fun updateDisplayName(userId: String, displayName: String) = withContext(Dispatchers.IO) {
        userDao.updateDisplayName(userId, displayName)
        try {
            FirebaseFirestore.getInstance().collection("driystream_users")
                .document(userId)
                .update("displayName", displayName)
                .await()
        } catch (e: Exception) {
            // offline fallback
        }
    }

    suspend fun updatePhotoUrl(userId: String, photoUrl: String) = withContext(Dispatchers.IO) {
        userDao.updatePhotoUrl(userId, photoUrl)
        try {
            FirebaseFirestore.getInstance().collection("driystream_users")
                .document(userId)
                .update("photoUrl", photoUrl)
                .await()
        } catch (e: Exception) {
            // offline fallback
        }
    }

    suspend fun signInWithGoogle(
        googleId: String = "google_user_1029",
        name: String = "Usuario",
        email: String = "usuario@driystream.com",
        photoUrl: String = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80"
    ): UserEntity = withContext(Dispatchers.IO) {
        val existing = userDao.getUserById(googleId)
        val user = existing ?: UserEntity(
            id = googleId,
            displayName = name,
            email = email,
            photoUrl = photoUrl,
            username = email.substringBefore("@"),
            createdAt = System.currentTimeMillis()
        )
        userDao.insertUser(user)
        prefs.edit()
            .putString(KEY_ACTIVE_USER_ID, user.id)
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .apply()
        user
    }

    suspend fun signOut() = withContext(Dispatchers.IO) {
        prefs.edit().clear().apply()
        userDao.clearAllUsers()
    }
}
