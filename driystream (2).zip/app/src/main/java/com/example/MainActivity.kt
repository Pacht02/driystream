package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.SongEntity
import com.example.ui.DriyViewModel
import com.example.ui.Screen
import com.example.ui.components.DriyBottomNavBar
import com.example.ui.components.FolderSelectionBottomSheet
import com.example.ui.components.FullPlayerModal
import com.example.ui.components.MiniPlayer
import com.example.ui.components.QueueModal
import com.example.ui.components.QueueNotificationBanner
import com.example.ui.components.SongActionBottomSheet
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.OnboardingArtistScreen
import com.example.ui.screens.OnboardingGenreScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.UploadMusicScreen
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyStreamTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DriyStreamTheme {
                DriyStreamAppRoot()
            }
        }
    }
}

@Composable
fun DriyStreamAppRoot(viewModel: DriyViewModel = viewModel()) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val isFullPlayerVisible by viewModel.isFullPlayerVisible.collectAsStateWithLifecycle()
    val playerState by viewModel.playerState.collectAsStateWithLifecycle()
    val activeUser by viewModel.activeUser.collectAsStateWithLifecycle()
    val allSongs by viewModel.allSongs.collectAsStateWithLifecycle()
    val downloadedSongs by viewModel.downloadedSongs.collectAsStateWithLifecycle()
    val favoriteSongs by viewModel.favoriteSongs.collectAsStateWithLifecycle()
    val selectedGenres by viewModel.selectedGenres.collectAsStateWithLifecycle()
    val selectedArtists by viewModel.selectedArtists.collectAsStateWithLifecycle()
    val artistSearchQuery by viewModel.artistSearchQuery.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val autocompleteSuggestions by viewModel.searchAutocompleteSuggestions.collectAsStateWithLifecycle()
    val downloadProgress by viewModel.downloadProgress.collectAsStateWithLifecycle()
    val isAuthenticating by viewModel.isAuthenticating.collectAsStateWithLifecycle()
    val favoriteArtistsSongs by viewModel.favoriteArtistsSongs.collectAsStateWithLifecycle()
    val isLoadingArtistSongs by viewModel.isLoadingArtistSongs.collectAsStateWithLifecycle()
    val islandMode by viewModel.islandMode.collectAsStateWithLifecycle()
    val isQueueVisible by viewModel.isQueueVisible.collectAsStateWithLifecycle()
    val activeSongForOptions by viewModel.activeSongForOptions.collectAsStateWithLifecycle()
    val queueNotification by viewModel.queueNotification.collectAsStateWithLifecycle()
    val allFolders by viewModel.allFolders.collectAsStateWithLifecycle()
    val foldersWithStats by viewModel.foldersWithStats.collectAsStateWithLifecycle()
    val activeSongForFolderSelection by viewModel.activeSongForFolderSelection.collectAsStateWithLifecycle()
    val selectedSongFolderIds by viewModel.selectedSongFolderIds.collectAsStateWithLifecycle()
    val activeFolder by viewModel.activeFolder.collectAsStateWithLifecycle()
    val activeFolderSongs by viewModel.activeFolderSongs.collectAsStateWithLifecycle()
    val uploadedSongs by viewModel.uploadedSongs.collectAsStateWithLifecycle()
    val globalCommunitySongs by viewModel.globalCommunitySongs.collectAsStateWithLifecycle()

    // Request POST_NOTIFICATIONS on Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* permission handled */ }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // Handle Back Press
    BackHandler(enabled = isFullPlayerVisible || currentScreen != Screen.Home && currentScreen != Screen.Login) {
        if (isFullPlayerVisible) {
            viewModel.setFullPlayerVisible(false)
        } else {
            when (currentScreen) {
                Screen.Search, Screen.Library, Screen.UploadMusic, Screen.Profile -> viewModel.navigateTo(Screen.Home)
                Screen.OnboardingArtist -> viewModel.navigateTo(Screen.OnboardingGenre)
                else -> { /* stay */ }
            }
        }
    }

    val isMainTabScreen = currentScreen in listOf(Screen.Home, Screen.Search, Screen.Library, Screen.UploadMusic, Screen.Profile)

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = DriyBackground,
            bottomBar = {
                if (isMainTabScreen) {
                    Column(modifier = Modifier.background(DriyBackground)) {
                        if (playerState.currentSong != null) {
                            MiniPlayer(
                                playerState = playerState,
                                onTogglePlayPause = { viewModel.togglePlayPause() },
                                onSkipNext = { viewModel.playNext() },
                                onClickMiniPlayer = { viewModel.setFullPlayerVisible(true) }
                            )
                        }
                        DriyBottomNavBar(
                            currentScreen = currentScreen,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Crossfade(targetState = currentScreen, label = "screen_transition") { screen ->
                    when (screen) {
                        Screen.Login -> {
                            LoginScreen(
                                isAuthenticating = isAuthenticating,
                                onCheckUsernameTaken = { username -> viewModel.checkUsernameTaken(username) },
                                onCheckPhoneTaken = { phone -> viewModel.findExistingAccount("", phone) != null },
                                onValidateLoginCredentials = { username, password, phone ->
                                    viewModel.validateLoginCredentials(username, password, phone)
                                },
                                onRegisterUser = { firstName, lastName, username, password, phone, onSuccess, onError ->
                                    viewModel.registerUserWithPhone(
                                        firstName = firstName,
                                        lastName = lastName,
                                        username = username,
                                        password = password,
                                        phoneNumber = phone,
                                        onSuccess = onSuccess,
                                        onError = onError
                                    )
                                },
                                onLoginUser = { username, password, phone, onSuccess, onError ->
                                    viewModel.loginWithUserAndPhone(
                                        username = username,
                                        password = password,
                                        phoneNumber = phone,
                                        onSuccess = onSuccess,
                                        onError = onError
                                    )
                                }
                            )
                        }

                        Screen.OnboardingGenre -> {
                            OnboardingGenreScreen(
                                genres = viewModel.getGenres(),
                                selectedGenreIds = selectedGenres,
                                onToggleGenre = { viewModel.toggleGenreSelection(it) },
                                onContinue = { viewModel.submitGenres() }
                            )
                        }

                        Screen.OnboardingArtist -> {
                            OnboardingArtistScreen(
                                artists = viewModel.getArtistsForOnboarding(),
                                selectedArtistNames = selectedArtists,
                                searchQuery = artistSearchQuery,
                                onSearchQueryChange = { viewModel.setArtistSearchQuery(it) },
                                onToggleArtist = { viewModel.toggleArtistSelection(it) },
                                onFinish = { viewModel.completeOnboarding() }
                            )
                        }

                        Screen.Home -> {
                            HomeScreen(
                                user = activeUser,
                                allSongs = allSongs,
                                favoriteArtistsSongs = favoriteArtistsSongs,
                                isLoadingArtistSongs = isLoadingArtistSongs,
                                searchQuery = searchQuery,
                                autocompleteSuggestions = autocompleteSuggestions,
                                playerState = playerState,
                                downloadProgress = downloadProgress,
                                onSearchQueryChange = { viewModel.setSearchQuery(it) },
                                onPlaySong = { song, queue -> viewModel.playSong(song, queue) },
                                onToggleFavorite = { viewModel.toggleFavorite(it) },
                                onDownloadSong = { viewModel.downloadSong(it) },
                                onOpenSongOptions = { viewModel.openSongOptions(it) },
                                uploadedSongs = uploadedSongs,
                                globalCommunitySongs = globalCommunitySongs
                            )
                        }

                        Screen.Search -> {
                            SearchScreen(
                                allSongs = allSongs,
                                genres = viewModel.getGenres(),
                                playerState = playerState,
                                downloadProgress = downloadProgress,
                                onPlaySong = { song, queue -> viewModel.playSong(song, queue) },
                                onToggleFavorite = { viewModel.toggleFavorite(it) },
                                onDownloadSong = { viewModel.downloadSong(it) },
                                onOpenSongOptions = { viewModel.openSongOptions(it) }
                            )
                        }

                        Screen.Library -> {
                            LibraryScreen(
                                downloadedSongs = downloadedSongs,
                                allSongs = allSongs,
                                foldersWithStats = foldersWithStats,
                                activeFolder = activeFolder,
                                activeFolderSongs = activeFolderSongs,
                                playerState = playerState,
                                downloadProgress = downloadProgress,
                                onPlaySong = { song, queue -> viewModel.playSong(song, queue) },
                                onToggleFavorite = { viewModel.toggleFavorite(it) },
                                onDownloadSong = { viewModel.downloadSong(it) },
                                onOpenSongOptions = { viewModel.openSongOptions(it) },
                                onOpenFolderDetail = { folder -> viewModel.openFolderDetail(folder) },
                                onCloseFolderDetail = { viewModel.closeFolderDetail() },
                                onCreateFolder = { name -> viewModel.createFolderAndAddSong(name, null) },
                                onRenameFolder = { id, newName -> viewModel.renameFolder(id, newName) },
                                onDeleteFolder = { folder -> viewModel.deleteFolder(folder) },
                                onRemoveSongFromFolder = { folderId, songId -> viewModel.removeSongFromCurrentFolder(folderId, songId) }
                            )
                        }

                        Screen.UploadMusic -> {
                            UploadMusicScreen(
                                uploadedSongs = uploadedSongs,
                                playerState = playerState,
                                onUploadSong = { title, composer, authorshipPercentage, artist, genre, approxDuration, releaseDate, audioUri, audioFileName, pdfUri, pdfFileName, coverUri, onSuccess ->
                                    viewModel.uploadMusicWork(
                                        title = title,
                                        composer = composer,
                                        authorshipPercentage = authorshipPercentage,
                                        artist = artist,
                                        genre = genre,
                                        approxDuration = approxDuration,
                                        releaseDate = releaseDate,
                                        audioUri = audioUri,
                                        audioFileName = audioFileName,
                                        pdfUri = pdfUri,
                                        pdfFileName = pdfFileName,
                                        coverUri = coverUri,
                                        onSuccess = onSuccess
                                    )
                                },
                                onPlayUploadedSong = { uploaded ->
                                    val durationParts = uploaded.approxDuration.split(":")
                                    val durationSec = if (durationParts.size == 2) {
                                        (durationParts[0].toIntOrNull() ?: 3) * 60 + (durationParts[1].toIntOrNull() ?: 30)
                                    } else {
                                        uploaded.approxDuration.toIntOrNull() ?: 210
                                    }
                                    val song = SongEntity(
                                        id = uploaded.id,
                                        title = uploaded.title,
                                        artist = uploaded.artist,
                                        genre = uploaded.genre,
                                        album = "Obra Registrada (${uploaded.releaseDate})",
                                        coverUrl = uploaded.coverUrl ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80",
                                        audioUrl = uploaded.audioFilePath,
                                        durationSeconds = durationSec,
                                        isDownloaded = true,
                                        localFilePath = uploaded.audioFilePath
                                    )
                                    viewModel.playSong(song)
                                },
                                onDeleteUploadedSong = { uploaded ->
                                    viewModel.deleteUploadedSong(uploaded)
                                }
                            )
                        }

                        Screen.Profile -> {
                            ProfileScreen(
                                user = activeUser,
                                isNativeIslandDetected = viewModel.isNativeIslandDetected,
                                islandMode = islandMode,
                                onSetIslandMode = { mode -> viewModel.setIslandMode(mode) },
                                hasOverlayPermission = viewModel.canDrawOverlays(),
                                onRequestOverlayPermission = { viewModel.openOverlaySettings(context) },
                                onUpdateDisplayName = { newName -> viewModel.updateDisplayName(newName) },
                                onUpdatePhotoUri = { uri -> viewModel.saveAndSetProfileImage(uri) },
                                onUpdatePresetPhoto = { url -> viewModel.updatePhotoUrl(url) },
                                onSignOut = { viewModel.signOut() }
                            )
                        }
                    }
                }
            }
        }

        // Full Player Modal
        FullPlayerModal(
            visible = isFullPlayerVisible,
            playerState = playerState,
            downloadProgress = playerState.currentSong?.let { downloadProgress[it.id] },
            onDismiss = { viewModel.setFullPlayerVisible(false) },
            onTogglePlayPause = { viewModel.togglePlayPause() },
            onNext = { viewModel.playNext() },
            onPrev = { viewModel.playPrevious() },
            onSeekTo = { viewModel.seekTo(it) },
            onToggleShuffle = { viewModel.toggleShuffle() },
            onToggleRepeat = { viewModel.toggleRepeat() },
            onToggleFavorite = { viewModel.toggleFavorite(it) },
            onDownload = { viewModel.downloadSong(it) },
            onOpenQueue = { viewModel.setQueueVisible(true) }
        )

        // Queue Modal BottomSheet
        QueueModal(
            visible = isQueueVisible,
            playerState = playerState,
            onDismiss = { viewModel.setQueueVisible(false) },
            onPlaySong = { song -> viewModel.playSong(song, playerState.queue) },
            onRemoveFromQueue = { songId -> viewModel.removeFromQueue(songId) },
            onClearQueue = { viewModel.clearQueue() }
        )

        // Song Options Action Sheet
        SongActionBottomSheet(
            song = activeSongForOptions,
            onDismiss = { viewModel.dismissSongOptions() },
            onPlayNow = { song -> viewModel.playSong(song) },
            onPlayNext = { song -> viewModel.addToQueueNext(song) },
            onAddToQueueEnd = { song -> viewModel.addToQueueEnd(song) },
            onToggleFavorite = { song -> viewModel.toggleFavorite(song) },
            onDownload = { song -> viewModel.downloadSong(song) }
        )

        // Folder Selection Bottom Sheet (opened when clicking heart on any song)
        FolderSelectionBottomSheet(
            song = activeSongForFolderSelection,
            folders = allFolders,
            selectedFolderIds = selectedSongFolderIds,
            onDismiss = { viewModel.dismissFolderSelector() },
            onToggleFolder = { folder ->
                activeSongForFolderSelection?.let { song ->
                    viewModel.toggleSongInFolder(folder, song)
                }
            },
            onCreateFolder = { folderName ->
                viewModel.createFolderAndAddSong(folderName, activeSongForFolderSelection)
            }
        )

        // Floating Queue Feedback Banner
        QueueNotificationBanner(
            message = queueNotification,
            onDismiss = { viewModel.dismissQueueNotification() },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = if (playerState.currentSong != null) 140.dp else 80.dp)
        )
    }
}
