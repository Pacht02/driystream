package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.SongEntity
import com.example.data.model.UploadedSongEntity
import com.example.data.model.UserEntity
import com.example.service.PlayerState
import com.example.ui.components.PredictiveSearchDropdown
import com.example.ui.components.SongItemRow
import com.example.ui.theme.DriyBackground
import com.example.ui.theme.DriyDivider
import com.example.ui.theme.DriyGold
import com.example.ui.theme.DriySurface
import com.example.ui.theme.DriySurfaceVariant
import com.example.ui.theme.DriyTextPrimary
import com.example.ui.theme.DriyTextSecondary

@Composable
fun HomeScreen(
    user: UserEntity?,
    allSongs: List<SongEntity>,
    favoriteArtistsSongs: List<SongEntity> = emptyList(),
    isLoadingArtistSongs: Boolean = false,
    searchQuery: String,
    autocompleteSuggestions: List<SongEntity>,
    playerState: PlayerState,
    downloadProgress: Map<String, Float>,
    onSearchQueryChange: (String) -> Unit,
    onPlaySong: (SongEntity, List<SongEntity>) -> Unit,
    onToggleFavorite: (SongEntity) -> Unit,
    onDownloadSong: (SongEntity) -> Unit,
    onOpenSongOptions: (SongEntity) -> Unit = {},
    uploadedSongs: List<UploadedSongEntity> = emptyList(),
    globalCommunitySongs: List<SongEntity> = emptyList()
) {
    val selectedArtists = user?.favoriteArtists ?: emptyList()
    var selectedArtistFilter by remember { mutableStateOf<String?>(null) }

    // Real songs fetched from the user's chosen favorite artists!
    val realArtistSongs = if (favoriteArtistsSongs.isNotEmpty()) {
        favoriteArtistsSongs
    } else {
        allSongs.filter { song -> selectedArtists.any { it.equals(song.artist, ignoreCase = true) } }
    }

    val recommendedSongs = realArtistSongs.ifEmpty { allSongs }

    val displayedSongs = if (selectedArtistFilter != null) {
        val filtered = realArtistSongs.filter { it.artist.contains(selectedArtistFilter!!, ignoreCase = true) }
        if (filtered.isNotEmpty()) filtered else allSongs.filter { it.artist.contains(selectedArtistFilter!!, ignoreCase = true) }
    } else {
        if (realArtistSongs.isNotEmpty()) realArtistSongs else allSongs
    }

    Surface(
        color = DriyBackground, // #121212
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen")
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Top Section with Predictive Search Bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DriyBackground)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Greeting and user avatar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Hola, ${user?.displayName?.split(" ")?.firstOrNull() ?: "Oyente"}",
                            color = DriyTextPrimary, // #EDEDED
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Música adaptada a tu gusto",
                            color = DriyTextSecondary, // #A0A0A0
                            fontSize = 12.sp
                        )
                    }

                    // Avatar
                    AsyncImage(
                        model = user?.photoUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80",
                        contentDescription = "Perfil",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Predictive Search Bar with magnifying glass
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = {
                        Text("Buscar canciones o cantantes...", color = DriyTextSecondary, fontSize = 14.sp)
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Buscar",
                            tint = DriyGold, // Oro Dorado
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Limpiar",
                                    tint = DriyTextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DriySurface, // #212121
                        unfocusedContainerColor = DriySurface,
                        focusedBorderColor = DriyGold, // #E6B800
                        unfocusedBorderColor = DriyDivider,
                        focusedTextColor = DriyTextPrimary,
                        unfocusedTextColor = DriyTextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_predictive_search_bar")
                )
            }

            // Autocomplete suggestions dropdown (instant playback on tap)
            PredictiveSearchDropdown(
                suggestions = autocompleteSuggestions,
                onSelectSong = { song ->
                    onPlaySong(song, allSongs)
                    onSearchQueryChange("")
                }
            )

            // Main Feed
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                // Section: Hecho para ti (Carrusel de tus artistas elegidos)
                item {
                    SectionHeader(
                        title = "Hecho para ti",
                        subtitle = if (selectedArtists.isNotEmpty()) "Basado en ${selectedArtists.take(3).joinToString(", ")}" else "Grandes éxitos para ti"
                    )

                    if (isLoadingArtistSongs && realArtistSongs.isEmpty()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 20.dp)
                        ) {
                            CircularProgressIndicator(
                                strokeWidth = 2.dp,
                                color = DriyGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Obteniendo las canciones de tus artistas...",
                                color = DriyTextSecondary,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier.padding(top = 10.dp, bottom = 18.dp)
                        ) {
                            items(recommendedSongs) { song ->
                                FeaturedSongCard(
                                    song = song,
                                    isPlaying = playerState.currentSong?.id == song.id && playerState.isPlaying,
                                    onPlay = { onPlaySong(song, recommendedSongs) }
                                )
                            }
                        }
                    }
                }

                // Section: Escucha a estos nuevos artistas, te encantará (Obras subidas y artistas emergentes)
                item {
                    SectionHeader(
                        title = "Escucha a estos nuevos artistas, te encantará",
                        subtitle = if (uploadedSongs.isNotEmpty() || globalCommunitySongs.isNotEmpty()) {
                            "Canciones de nuestra comunidad global de artistas y creadores"
                        } else {
                            "Nuevos talentos independientes recomendados para ti"
                        }
                    )

                    val communityEmergingSongs = remember(uploadedSongs, globalCommunitySongs) {
                        val userSongsList = uploadedSongs.map { up ->
                            val durationParts = up.approxDuration.split(":")
                            val durationSec = if (durationParts.size == 2) {
                                (durationParts[0].toIntOrNull() ?: 3) * 60 + (durationParts[1].toIntOrNull() ?: 30)
                            } else {
                                up.approxDuration.toIntOrNull() ?: 210
                            }
                            SongEntity(
                                id = up.id,
                                title = up.title,
                                artist = up.artist,
                                genre = up.genre,
                                album = "Obra Registrada (${up.releaseDate})",
                                coverUrl = up.coverUrl ?: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80",
                                audioUrl = up.audioFilePath,
                                durationSeconds = durationSec,
                                isDownloaded = true,
                                localFilePath = up.audioFilePath
                            )
                        }

                        // Other users' songs from global cloud (Firestore)
                        val otherUsersCloudSongs = globalCommunitySongs.filter { cloudSong ->
                            userSongsList.none { it.id == cloudSong.id }
                        }

                        val sampleEmergingSongs = listOf(
                            SongEntity(
                                id = "emerging_1",
                                title = "Amanecer Índigo",
                                artist = "Sofía Del Valle",
                                genre = "Indie Pop",
                                album = "Sesión Acústica 2026",
                                coverUrl = "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=500&q=80",
                                audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3",
                                durationSeconds = 224,
                                isDownloaded = false
                            ),
                            SongEntity(
                                id = "emerging_2",
                                title = "Frecuencia Cero",
                                artist = "Mateo & Los Ecos",
                                genre = "Synthwave",
                                album = "Sencillo Original",
                                coverUrl = "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=500&q=80",
                                audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3",
                                durationSeconds = 248,
                                isDownloaded = false
                            ),
                            SongEntity(
                                id = "emerging_3",
                                title = "Noches de Neón",
                                artist = "Lucas Prado",
                                genre = "R&B Urbano",
                                album = "Estudio Independiente",
                                coverUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&q=80",
                                audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3",
                                durationSeconds = 210,
                                isDownloaded = false
                            )
                        )

                        val combined = userSongsList + otherUsersCloudSongs
                        if (combined.size < 4) combined + sampleEmergingSongs else combined
                    }

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.padding(top = 10.dp, bottom = 18.dp)
                    ) {
                        items(communityEmergingSongs) { song ->
                            NewArtistFeaturedCard(
                                song = song,
                                isUserUpload = uploadedSongs.any { it.id == song.id } || globalCommunitySongs.any { it.id == song.id },
                                isPlaying = playerState.currentSong?.id == song.id && playerState.isPlaying,
                                onPlay = { onPlaySong(song, communityEmergingSongs) }
                            )
                        }
                    }
                }

                // Section: Artistas que sigues
                if (selectedArtists.isNotEmpty()) {
                    item {
                        SectionHeader(
                            title = "Tus artistas preferidos",
                            subtitle = if (selectedArtistFilter != null) "Filtrando por $selectedArtistFilter (toca de nuevo para ver todos)" else "Toca un artista para ver sus canciones"
                        )
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(top = 10.dp, bottom = 18.dp)
                        ) {
                            items(selectedArtists) { artistName ->
                                ArtistBadge(
                                    artistName = artistName,
                                    isSelected = selectedArtistFilter == artistName,
                                    onClick = {
                                        selectedArtistFilter = if (selectedArtistFilter == artistName) null else artistName
                                    }
                                )
                            }
                        }
                    }
                }

                // Section: Canciones recomendadas
                item {
                    val sectionTitle = if (selectedArtistFilter != null) {
                        "Canciones de $selectedArtistFilter"
                    } else if (realArtistSongs.isNotEmpty()) {
                        "Éxitos de tus artistas favoritos"
                    } else {
                        "Recomendaciones de DriyStream"
                    }

                    val sectionSubtitle = if (selectedArtistFilter != null) {
                        "Música real del artista lista para reproducir"
                    } else if (realArtistSongs.isNotEmpty()) {
                        "Canciones reales de ${selectedArtists.take(4).joinToString(", ")}"
                    } else {
                        "Música en alta fidelidad lista para sonar"
                    }

                    SectionHeader(
                        title = sectionTitle,
                        subtitle = sectionSubtitle
                    )
                }

                items(displayedSongs) { song ->
                    SongItemRow(
                        song = song,
                        isPlaying = playerState.isPlaying,
                        isCurrentSong = playerState.currentSong?.id == song.id,
                        downloadProgress = downloadProgress[song.id],
                        onPlay = { onPlaySong(song, displayedSongs) },
                        onToggleFavorite = { onToggleFavorite(song) },
                        onDownload = { onDownloadSong(song) },
                        onOptionsClick = { onOpenSongOptions(song) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String, subtitle: String) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Text(
            text = title,
            color = DriyTextPrimary, // #EDEDED
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = subtitle,
            color = DriyTextSecondary, // #A0A0A0
            fontSize = 12.sp
        )
    }
}

@Composable
private fun FeaturedSongCard(
    song: SongEntity,
    isPlaying: Boolean,
    onPlay: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DriySurface), // #212121
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .width(150.dp)
            .clickable { onPlay() }
            .testTag("featured_song_${song.id}")
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .clip(RoundedCornerShape(10.dp))
            ) {
                AsyncImage(
                    model = song.coverUrl,
                    contentDescription = song.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Quick Play button in Gold #E6B800
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(DriyGold)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Reproducir",
                        tint = DriyBackground,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = song.title,
                color = DriyTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = song.artist,
                color = DriyTextSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ArtistBadge(
    artistName: String,
    isSelected: Boolean = false,
    onClick: () -> Unit = {}
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (isSelected) DriyGold else DriySurfaceVariant)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Verified,
            contentDescription = null,
            tint = if (isSelected) DriyBackground else DriyGold,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = artistName,
            color = if (isSelected) DriyBackground else DriyTextPrimary,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
fun NewArtistFeaturedCard(
    song: SongEntity,
    isUserUpload: Boolean,
    isPlaying: Boolean,
    onPlay: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DriySurface),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .width(160.dp)
            .clickable { onPlay() }
            .border(
                1.dp,
                if (isUserUpload) DriyGold else DriyDivider,
                RoundedCornerShape(16.dp)
            )
            .testTag("new_artist_card_${song.id}")
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(DriySurfaceVariant)
            ) {
                AsyncImage(
                    model = song.coverUrl,
                    contentDescription = song.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Top badge
                Surface(
                    color = if (isUserUpload) DriyGold else DriySurface.copy(alpha = 0.85f),
                    shape = RoundedCornerShape(topStart = 12.dp, bottomEnd = 8.dp),
                    modifier = Modifier.align(Alignment.TopStart)
                ) {
                    Text(
                        text = if (isUserUpload) "★ CREADOR" else "NUEVO ARTISTA",
                        color = if (isUserUpload) DriyBackground else DriyGold,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }

                // Play icon
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(if (isPlaying) DriyGold else DriySurface.copy(alpha = 0.9f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Reproducir",
                        tint = if (isPlaying) DriyBackground else DriyGold,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = song.title,
                color = DriyTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = song.artist,
                    color = DriyTextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (isUserUpload) {
                    Spacer(modifier = Modifier.width(3.dp))
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = "Verificado",
                        tint = DriyGold,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = song.genre,
                color = DriyGold,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
